"""Intensity effects: pulse, blackout, full on, sparkle, flicker."""

import numpy as np

from ..registry import Param, register_effect
from ..shapes import frac, hash01, sine01, smoothstep


@register_effect(
    "pulse", "Pulse", {"intensity"},
    params=[
        Param("style", 0, label="Style", choices=(("breathe", "Breathe"), ("hit", "Hit")),
              description="Breathe rises and falls smoothly; Hit snaps on and decays"),
        Param("low", 0.1, min=0.0, max=1.0, label="Low"),
        Param("high", 1.0, min=0.0, max=1.0, label="High"),
        Param("decay", 5.0, min=0.5, max=30.0, label="Decay", description="How fast a hit dies away"),
    ],
    description="Breathing or beat-hit intensity",
    speed=(2.0, 'BEATS'), icon='IPO_EASE_IN_OUT')
def pulse(idx, n, t, p):
    ph = p.phase(idx, n, t)
    v = np.exp(-p.decay * frac(ph)) if int(p.style) == 1 else sine01(ph + 0.5)
    return {"intensity": p.low + (p.high - p.low) * v}


@register_effect(
    "blackout", "Blackout", {"intensity"},
    description="Everything in the group to black. Use fades for a slow fade-out",
    uses_speed=False, icon='HIDE_ON')
def blackout(idx, n, t, p):
    return {"intensity": 0.0}


@register_effect(
    "full_on", "Full on", {"intensity"},
    params=[Param("level", 1.0, min=0.0, max=1.0, label="Level")],
    description="Every head at a fixed level",
    uses_speed=False, icon='LIGHT_SUN')
def full_on(idx, n, t, p):
    return {"intensity": p.level}


@register_effect(
    "sparkle", "Sparkle", {"intensity"},
    params=[
        Param("density", 0.15, min=0.0, max=1.0, label="Density", description="Share of heads that fire each cycle"),
        Param("decay", 6.0, min=0.5, max=40.0, label="Decay", description="How fast each sparkle dies away"),
        Param("floor", 0.0, min=0.0, max=1.0, label="Floor", description="Level between sparkles"),
    ],
    description="Random heads flash and fade, like glitter",
    speed=(8.0, 'HZ'), icon='SHADERFX')
def sparkle(idx, n, t, p):
    slot = np.floor(t)
    fire = hash01(slot, idx, seed=p.seed) < p.density
    # Each sparkle starts at a random point in its slot so they don't all land together
    start = hash01(slot, idx, seed=p.seed + 101) * 0.5
    age = frac(t) - start
    v = np.where(fire & (age >= 0), np.exp(-p.decay * np.maximum(age, 0)), 0.0)
    return {"intensity": p.floor + (1.0 - p.floor) * v}


@register_effect(
    "flicker", "Flicker", {"intensity"},
    params=[
        Param("low", 0.35, min=0.0, max=1.0, label="Low"),
        Param("high", 1.0, min=0.0, max=1.0, label="High"),
        Param("jitter", 0.0, min=0.0, max=1.0, label="Jitter", description="Hard frame-to-frame noise on top"),
    ],
    description="Smooth random flicker, from candle to faulty fixture",
    speed=(6.0, 'HZ'), icon='FORCE_TURBULENCE')
def flicker(idx, n, t, p):
    k = np.floor(t)
    a, b = hash01(k, idx, seed=p.seed), hash01(k + 1, idx, seed=p.seed)
    v = a + (b - a) * smoothstep(frac(t))
    if p.jitter > 0:
        fk = np.floor(t / max(p.frame_step, 1e-6))
        v = v * (1 - p.jitter) + hash01(fk, idx, seed=p.seed + 7) * p.jitter
    return {"intensity": p.low + (p.high - p.low) * v}
