"""Colour effects beyond the basic fade."""

from ..registry import Param, register_effect
from ..shapes import hsv_to_rgb, triangle01


@register_effect(
    "rainbow", "Rainbow", {"color"},
    params=[
        Param("saturation", 1.0, min=0.0, max=1.0, label="Saturation"),
        Param("brightness", 1.0, min=0.0, max=1.0, label="Brightness"),
        Param("hue_range", 1.0, min=0.05, max=1.0, label="Hue range",
              description="How much of the colour wheel to use. Below 1 it swings back and forth"),
        Param("hue_offset", 0.0, min=0.0, max=1.0, label="Start hue"),
    ],
    description="Cycle round the colour wheel, spread across the group",
    speed=(8.0, 'BEATS'), spread=1.0, icon='COLOR')
def rainbow(idx, n, t, p):
    ph = p.phase(idx, n, t)
    if p.hue_range < 1.0:
        # Ping-pong across a slice of the wheel so the ends don't jump
        h = p.hue_offset + p.hue_range * triangle01(ph)
    else:
        h = p.hue_offset + ph
    return {"color": hsv_to_rgb(h, p.saturation, p.brightness)}
