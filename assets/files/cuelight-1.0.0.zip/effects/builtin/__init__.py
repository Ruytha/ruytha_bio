# Importing a module registers its effects. Add new effect modules here.
# Order sets the order in the Add Effect menu.
from . import basic, intensity, color, motion  # noqa: F401
