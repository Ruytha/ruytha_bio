"""Pan and tilt: fan, sweep, circle, figure-8.

A hanging head points straight down at tilt 0, where pan alone barely moves
the beam. So the paths run around a centre tilt (30 degrees by default) where
pan and tilt act like two axes on the floor.
"""

import numpy as np

from ..registry import Param, register_effect
from ..shapes import WAVES, frac, sine01, spread_positions

TWO_PI = 2 * np.pi


def _centre_params(size_pan=25.0, size_tilt=15.0):
    return [
        Param("center_pan", 0.0, min=-270.0, max=270.0, label="Centre pan"),
        Param("center_tilt", 30.0, min=-135.0, max=135.0, label="Centre tilt"),
        Param("size_pan", size_pan, min=0.0, max=180.0, label="Pan size", description="Degrees either side of centre"),
        Param("size_tilt", size_tilt, min=0.0, max=135.0, label="Tilt size", description="Degrees either side of centre"),
    ]


@register_effect(
    "fan", "Fan", {"pan", "tilt"},
    params=[
        Param("axis", 0, label="Axis", choices=(("pan", "Pan"), ("tilt", "Tilt"))),
        Param("motion", 0, label="Motion",
              choices=(("breathe", "In and out"), ("out", "Fan out"), ("in", "Fan in"), ("hold", "Hold"))),
        Param("width", 40.0, min=0.0, max=180.0, label="Width", description="Degrees the outer heads reach"),
        Param("center", 0.0, min=-270.0, max=270.0, label="Centre"),
    ],
    description="Spread heads apart from the middle of the group, and back",
    speed=(4.0, 'BEATS'), icon='MOD_ARRAY')
def fan(idx, n, t, p):
    pos = spread_positions(idx, n)
    m = int(p.motion)
    amount = {0: sine01(t), 1: frac(t), 2: 1.0 - frac(t), 3: 1.0}[m]
    return {("pan", "tilt")[int(p.axis)]: p.center + p.width * pos * amount}


@register_effect(
    "sweep", "Sweep", {"pan", "tilt"},
    params=[
        Param("axis", 0, label="Axis", choices=(("pan", "Pan"), ("tilt", "Tilt"), ("both", "Diagonal"))),
        Param("shape", 0, label="Shape", choices=(("sine", "Smooth"), ("triangle", "Linear"))),
    ] + _centre_params(40.0, 20.0),
    description="Swing beams side to side, up and down, or diagonally",
    speed=(4.0, 'BEATS'), icon='ARROW_LEFTRIGHT')
def sweep(idx, n, t, p):
    v = WAVES[int(p.shape)](p.phase(idx, n, t)) * 2.0 - 1.0
    axis = int(p.axis)
    out = {}
    if axis in (0, 2):
        out["pan"] = p.center_pan + p.size_pan * v
    if axis in (1, 2):
        out["tilt"] = p.center_tilt + p.size_tilt * v
    return out


@register_effect(
    "circle", "Circle", {"pan", "tilt"},
    params=[Param("clockwise", True, label="Clockwise")] + _centre_params(),
    description="Trace circles with the beams",
    speed=(4.0, 'BEATS'), icon='MESH_CIRCLE')
def circle(idx, n, t, p):
    a = TWO_PI * p.phase(idx, n, t) * (1.0 if p.clockwise else -1.0)
    return {"pan": p.center_pan + p.size_pan * np.sin(a),
            "tilt": p.center_tilt + p.size_tilt * np.cos(a)}


@register_effect(
    "figure8", "Figure 8", {"pan", "tilt"},
    params=_centre_params(30.0, 12.0),
    description="Trace a sideways figure 8",
    speed=(8.0, 'BEATS'), icon='CON_FOLLOWPATH')
def figure8(idx, n, t, p):
    a = TWO_PI * p.phase(idx, n, t)
    return {"pan": p.center_pan + p.size_pan * np.sin(a),
            "tilt": p.center_tilt + p.size_tilt * np.sin(2 * a)}
