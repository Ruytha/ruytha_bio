import numpy as np

from ..registry import Param, register_effect
from ..shapes import WAVES, cycle_colors, frac, hash01


@register_effect(
    "chase", "Chase", {"intensity"},
    params=[
        Param("width", 1, min=1, max=64, label="Lit at once", description="Heads lit at the same time"),
        Param("tail", 0.0, min=0.0, max=1.0, label="Tail", description="Fade trailing heads, as a share of the group"),
        Param("bounce", False, label="Bounce", description="Run back and forth instead of wrapping"),
        Param("floor", 0.0, min=0.0, max=1.0, label="Floor", description="Level of unlit heads"),
    ],
    description="Step light across the group, one or more heads at a time",
    speed=(4.0, 'BEATS'), icon='FORWARD')
def chase(idx, n, t, p):
    if p.bounce and n > 1:
        span = 2 * (n - 1)
        s = np.floor(frac(t) * span)
        pos = np.where(s <= n - 1, s, span - s)
        d = np.abs(pos - idx)
    else:
        pos = np.floor(frac(t) * n)
        d = (pos - idx) % n  # how many steps ago the chase passed this head
    width = max(int(p.width), 1)
    lit = (d < width).astype(float)
    if p.tail > 0:
        tail_len = max(p.tail * n, 1e-6)
        lit = np.maximum(lit, np.clip(1.0 - (d - width + 1) / tail_len, 0.0, 1.0))
    return {"intensity": p.floor + (1.0 - p.floor) * lit}


_TARGETS = (("intensity", "Intensity"), ("pan", "Pan"), ("tilt", "Tilt"), ("zoom", "Zoom"))


@register_effect(
    "wave", "Wave", {"intensity", "pan", "tilt", "zoom"},
    params=[
        Param("target", 0, label="Moves", choices=_TARGETS,
              description="Channel the wave drives"),
        Param("shape", 0, label="Shape",
              choices=(("sine", "Sine"), ("triangle", "Triangle"), ("saw", "Saw"), ("square", "Square"))),
        Param("low", 0.0, label="Low", description="Value at the bottom of the wave (degrees for pan/tilt)"),
        Param("high", 1.0, label="High", description="Value at the top of the wave (degrees for pan/tilt)"),
    ],
    description="A sine (or other) wave rolling through intensity, pan, tilt or zoom",
    speed=(4.0, 'BEATS'), spread=1.0, icon='IPO_SINE',
    # Sensible ranges when the target changes
    presets={"target": {"pan": {"low": -45.0, "high": 45.0}, "tilt": {"low": -30.0, "high": 30.0},
                        "intensity": {"low": 0.0, "high": 1.0}, "zoom": {"low": 0.0, "high": 1.0}}})
def wave(idx, n, t, p):
    v = WAVES[int(p.shape)](p.phase(idx, n, t))
    return {_TARGETS[int(p.target)][0]: p.low + (p.high - p.low) * v}



@register_effect(
    "strobe", "Strobe", {"intensity"},
    params=[
        Param("duty", 0.2, min=0.02, max=0.9, label="Flash length", description="Share of each cycle the flash is on"),
        Param("chance", 1.0, min=0.0, max=1.0, label="Chance", description="Chance each head fires on a given flash"),
        Param("level", 1.0, min=0.0, max=1.0, label="Level"),
    ],
    description="Flashes at a rate in Hz or locked to the beat",
    speed=(10.0, 'HZ'), icon='LIGHT_SUN')
def strobe(idx, n, t, p):
    ph = p.phase(idx, n, t)
    if p.frame_step >= 0.5:
        # Faster than the frame rate can show: alternate frames instead of aliasing
        on = (np.round(ph / p.frame_step) % 2 == 0).astype(float)
    else:
        on = (frac(ph) < max(p.duty, p.frame_step * 1.01)).astype(float)
    if p.chance < 1.0:
        on *= hash01(np.floor(ph), idx, seed=p.seed) < p.chance
    return {"intensity": on * p.level}


@register_effect(
    "color_fade", "Colour fade", {"color"},
    params=[
        Param("hold", 0.25, min=0.0, max=1.0, label="Hold", description="Share of each step spent on a colour before fading"),
    ],
    description="Fade through two or more colours",
    colors=((1.0, 0.05, 0.1), (0.1, 0.2, 1.0)),
    speed=(8.0, 'BEATS'), icon='COLOR')
def color_fade(idx, n, t, p):
    return {"color": cycle_colors(p.colors, p.phase(idx, n, t), p.hold)}
