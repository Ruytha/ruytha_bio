import bpy

from . import builtin  # noqa: F401  (fills the registry)
from .registry import REGISTRY, Param, register_effect  # noqa: F401


def register():
    from . import ops
    for c in ops.classes:
        bpy.utils.register_class(c)


def unregister():
    from . import ops
    for c in reversed(ops.classes):
        bpy.utils.unregister_class(c)
