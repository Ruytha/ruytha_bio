"""Small vectorised helpers shared by effects."""

import numpy as np


def frac(x):
    return x - np.floor(x)


def phase(idx, n, t, spread):
    """Cycle position per head. spread = 1 puts one full cycle across the group,
    with higher indices lagging so motion runs from index 0 upwards."""
    return t - spread * idx / max(n, 1)


def sine01(ph):
    return 0.5 - 0.5 * np.cos(2 * np.pi * ph)


def triangle01(ph):
    return 1.0 - np.abs(2.0 * frac(ph) - 1.0)


def saw01(ph):
    return frac(ph)


def square01(ph, duty=0.5):
    return (frac(ph) < duty).astype(float)


WAVES = {0: sine01, 1: triangle01, 2: saw01, 3: square01}


def smoothstep(x):
    x = np.clip(x, 0.0, 1.0)
    return x * x * (3 - 2 * x)


def hash01(*parts, seed=0):
    """Deterministic pseudo-random 0..1 per element, stable across frames and machines."""
    h = np.float64(seed) * 37.719 + 0.5
    for i, a in enumerate(parts):
        h = h + np.asarray(a, dtype=np.float64) * (12.9898 + 61.7 * i)
    return frac(np.sin(h) * 43758.5453)


def hsv_to_rgb(h, s, v):
    """Vectorised HSV -> RGB. h wraps; returns (n, 3)."""
    h = frac(np.atleast_1d(np.asarray(h, dtype=float))) * 6.0
    s = np.broadcast_to(s, h.shape).astype(float)
    v = np.broadcast_to(v, h.shape).astype(float)
    i = np.floor(h).astype(int) % 6
    f = h - np.floor(h)
    p, q, t = v * (1 - s), v * (1 - s * f), v * (1 - s * (1 - f))
    r = np.choose(i, [v, q, p, p, t, v])
    g = np.choose(i, [t, v, v, q, p, p])
    b = np.choose(i, [p, p, t, v, v, q])
    return np.stack([r, g, b], axis=1)


def spread_positions(idx, n):
    """-1 .. 1 across the group, for effects that fan out from the middle."""
    return np.zeros_like(idx) if n <= 1 else idx / (n - 1) * 2.0 - 1.0


def cycle_colors(colors, x, hold=0.0):
    """Walk a colour list as x goes 0 -> 1, fading between neighbours.

    hold: fraction of each step spent holding the colour before fading.
    """
    k = len(colors)
    if k == 0:
        return np.ones((np.size(x), 3))
    if k == 1:
        return np.broadcast_to(colors[0], (np.size(x), 3)).copy()
    pos = frac(np.atleast_1d(x)) * k
    i0 = np.floor(pos).astype(int) % k
    f = pos - np.floor(pos)
    if hold > 0:
        f = np.clip((f - hold) / max(1.0 - hold, 1e-6), 0.0, 1.0)
    f = smoothstep(f)[:, None]
    return colors[i0] * (1 - f) + colors[(i0 + 1) % k] * f
