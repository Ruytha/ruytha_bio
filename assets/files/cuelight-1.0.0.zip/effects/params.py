"""Effect parameters live as ID properties ("p_<name>") on each effect item,
typed and ranged from the effect's Param schema. A new effect never needs a
new RNA property."""

import numpy as np

from . import registry
from .shapes import phase


def ensure(effect, etype, reset=False):
    """Create missing parameter properties (or all of them with reset)."""
    for prm in etype.params:
        key = prm.key
        if reset or key not in effect:
            effect[key] = prm.default
        if prm.choices is None and not isinstance(prm.default, bool):
            ui = {"description": prm.description}
            if prm.min is not None:
                ui["min"] = prm.min
            if prm.max is not None:
                ui["max"] = prm.max
            if prm.step is not None:
                ui["step"] = prm.step
            effect.id_properties_ui(key).update(**ui)


def apply_defaults(effect, etype):
    """Common settings a fresh effect of this type should start with."""
    effect.speed, effect.speed_unit = etype.speed
    effect.phase_spread = etype.spread
    effect.colors.clear()
    for c in etype.colors:
        effect.colors.add().color = c
    ensure(effect, etype, reset=True)


class Params:
    """What an effect function receives as p."""

    __slots__ = ("_values", "spread", "colors", "seed", "frame_step", "seconds", "frame")

    def __init__(self, effect, etype, frame_step, seconds, frame):
        self._values = {prm.name: effect.get(prm.key, prm.default) for prm in etype.params}
        self.spread = effect.phase_spread
        self.colors = (np.array([c.color[:] for c in effect.colors], dtype=float)
                       if len(effect.colors) else np.array(etype.colors or ((1.0, 1.0, 1.0),), dtype=float))
        self.seed = effect.seed
        self.frame_step = frame_step
        self.seconds = seconds
        self.frame = frame

    def __getattr__(self, name):
        try:
            return self._values[name]
        except KeyError:
            raise AttributeError(name) from None

    def phase(self, idx, n, t):
        return phase(idx, n, t, self.spread)


def choice_id(effect, etype, name):
    prm = etype.param(name)
    i = int(effect.get(prm.key, prm.default))
    return prm.choices[max(0, min(i, len(prm.choices) - 1))][0]


def set_choice(effect, etype, name, index):
    prm = etype.param(name)
    effect[prm.key] = int(index)
    for k, v in etype.presets.get(name, {}).get(prm.choices[index][0], {}).items():
        effect[etype.param(k).key] = v


def get_type(effect):
    return registry.get(effect.effect_type)
