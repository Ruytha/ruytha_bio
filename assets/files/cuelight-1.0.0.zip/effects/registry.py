"""Effect registry.

An effect is one function plus one decorator:

    @register_effect("chase", "Chase", channels={"intensity"},
                     params=[Param("width", 1, min=1, max=64, label="Lit at once")])
    def chase(idx, n, t, p):
        ...
        return {"intensity": values}

Arguments:
    idx  float ndarray, each head's position in the group after direction is
         applied (0 .. n-1). Heads mirrored by centre-out share an index.
    n    number of distinct positions.
    t    cycles elapsed (float). Speed, BPM and audio modulation are already
         applied, so one full pass of the effect is t going from k to k + 1.
    p    parameters: every Param by name, plus spread, colors (k x 3 ndarray),
         seed, frame_step (one frame in cycles), seconds (since the effect
         started) and phase(idx, n, t), a helper for spread-offset phase.

Return a dict of channel -> value. Values are scalars or arrays of len(idx)
(len(idx) x 3 for "color"). Channels you don't return pass through untouched.
An optional "alpha" array (0..1) scales the layer per head.

Channels: intensity (0..1), color (RGB 0..1), pan, tilt (degrees), zoom (0..1),
strobe (Hz).
"""

from dataclasses import dataclass, field

CHANNELS = ("intensity", "color", "pan", "tilt", "zoom", "strobe")


@dataclass
class Param:
    name: str
    default: object
    min: float = None
    max: float = None
    label: str = None
    description: str = ""
    choices: tuple = None   # ((id, label), ...) stored as the index
    step: float = None

    @property
    def key(self):
        return "p_" + self.name


@dataclass
class EffectType:
    id: str
    label: str
    fn: object
    channels: frozenset
    params: tuple = ()
    description: str = ""
    colors: tuple = ()          # default colours; non-empty means the effect uses the colour list
    speed: tuple = (4.0, 'BEATS')  # default (speed, unit)
    spread: float = 0.0         # default phase spread
    icon: str = 'LIGHT'
    uses_speed: bool = True
    order: int = 0
    presets: dict = field(default_factory=dict)  # {choice param: {choice id: {param: value}}}

    def param(self, name):
        return next((p for p in self.params if p.name == name), None)


REGISTRY = {}


def register_effect(id, label, channels, params=(), description="", colors=(), speed=(4.0, 'BEATS'),
                    spread=0.0, icon='LIGHT', uses_speed=True, presets=None):
    unknown = set(channels) - set(CHANNELS)
    if unknown:
        raise ValueError("unknown channels %s in effect %r" % (unknown, id))

    def wrap(fn):
        REGISTRY[id] = EffectType(id, label, fn, frozenset(channels), tuple(params), description,
                                  tuple(tuple(c) for c in colors), speed, spread, icon, uses_speed,
                                  order=len(REGISTRY), presets=presets or {})
        return fn
    return wrap


def get(id):
    return REGISTRY.get(id)


def enum_items():
    return [(e.id, e.label, e.description, e.icon, i) for i, e in enumerate(REGISTRY.values())]
