import uuid

import bpy
from bpy.props import EnumProperty, IntProperty, StringProperty

from ..engine import live, timing
from . import params, registry

_type_items_cache = []


def _type_items(self, context):
    _type_items_cache[:] = registry.enum_items()
    return _type_items_cache


def _settings(context):
    return context.scene.cuelight


def active_effect(context):
    s = _settings(context)
    return s.effects[s.active_effect] if 0 <= s.active_effect < len(s.effects) else None


def add_effect(scene, effect_type, group, start=None, end=None, name=None, **values):
    """Add an effect layer on top of the stack.

    values: any common setting (speed, blend, opacity...) or effect parameter
    by name, plus colors=[(r, g, b), ...].
    """
    s = scene.cuelight
    et = registry.get(effect_type)
    if et is None:
        raise KeyError("unknown effect %r" % effect_type)
    e = s.effects.add()
    e.uid = uuid.uuid4().hex[:12]
    e.effect_type = effect_type
    params.apply_defaults(e, et)
    e.group = group or ""
    e.name = name or et.label
    if start is None:
        start = scene.frame_current
    if end is None:
        # Eight bars: long enough to hear the effect, short enough to stack a show
        bar = timing.frames_per_beat(scene, s) * s.beats_per_bar
        end = start + int(round(8 * bar)) - 1
    e.frame_start, e.frame_end = int(start), int(end)
    colors = values.pop("colors", None)
    if colors is not None:
        e.colors.clear()
        for c in colors:
            e.colors.add().color = c[:3]
    for k, v in values.items():
        prm = et.param(k)
        if prm is not None:
            e[prm.key] = v
        else:
            setattr(e, k, v)
    s.active_effect = len(s.effects) - 1
    live.refresh(scene)
    return e


def copy_effect(src, dst):
    for prop in src.bl_rna.properties:
        k = prop.identifier
        if k in {"rna_type", "colors", "modulators", "uid", "type_enum"} or prop.is_readonly:
            continue
        setattr(dst, k, getattr(src, k))
    for k in src.keys():
        if k.startswith("p_"):
            dst[k] = src[k]
    et = registry.get(src.effect_type)
    if et is not None:
        params.ensure(dst, et)  # restores slider ranges
    dst.colors.clear()
    for c in src.colors:
        dst.colors.add().color = c.color
    dst.modulators.clear()
    for m in src.modulators:
        n = dst.modulators.add()
        for prop in m.bl_rna.properties:
            k = prop.identifier
            if k not in {"rna_type", "target_enum"} and not prop.is_readonly:
                setattr(n, k, getattr(m, k))


class CUELIGHT_OT_effect_add(bpy.types.Operator):
    bl_idname = "cuelight.effect_add"
    bl_label = "Add effect"
    bl_description = "Add an effect layer on the active group, starting at the playhead"
    bl_options = {'REGISTER', 'UNDO'}

    effect_type: EnumProperty(name="Effect", items=_type_items)

    def execute(self, context):
        s = _settings(context)
        g = s.groups[s.active_group].name if 0 <= s.active_group < len(s.groups) else ""
        add_effect(context.scene, self.effect_type, g)
        if not g:
            self.report({'WARNING'}, "No group yet. Pick one for the effect to play on")
        return {'FINISHED'}


class CUELIGHT_OT_effect_remove(bpy.types.Operator):
    bl_idname = "cuelight.effect_remove"
    bl_label = "Remove effect"
    bl_description = "Remove the selected effect layer"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return active_effect(context) is not None

    def execute(self, context):
        s = _settings(context)
        uid = s.effects[s.active_effect].uid
        for c in s.cues:
            for i in reversed([i for i, r in enumerate(c.effects) if r.uid == uid]):
                c.effects.remove(i)
        s.effects.remove(s.active_effect)
        s.active_effect = max(0, min(s.active_effect, len(s.effects) - 1))
        live.refresh(context.scene)
        return {'FINISHED'}


class CUELIGHT_OT_effect_duplicate(bpy.types.Operator):
    bl_idname = "cuelight.effect_duplicate"
    bl_label = "Duplicate effect"
    bl_description = "Copy the selected effect layer, placed above it"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return active_effect(context) is not None

    def execute(self, context):
        s = _settings(context)
        i = s.active_effect
        src = s.effects[i]
        dst = s.effects.add()
        copy_effect(src, dst)
        dst.uid = uuid.uuid4().hex[:12]
        dst.name = src.name + " copy"
        for c in s.cues:  # the copy plays wherever the original does
            if any(r.uid == src.uid for r in c.effects):
                c.effects.add().uid = dst.uid
        s.effects.move(len(s.effects) - 1, i + 1)
        s.active_effect = i + 1
        live.refresh(context.scene)
        return {'FINISHED'}


class CUELIGHT_OT_effect_move(bpy.types.Operator):
    bl_idname = "cuelight.effect_move"
    bl_label = "Move effect"
    bl_description = "Move the layer up (later in the stack, on top) or down"
    bl_options = {'REGISTER', 'UNDO'}

    direction: EnumProperty(items=(('UP', "Up", ""), ('DOWN', "Down", "")))

    @classmethod
    def poll(cls, context):
        return len(_settings(context).effects) > 1

    def execute(self, context):
        s = _settings(context)
        i = s.active_effect
        # The list draws top layer first, so "up" moves towards the end of the stack
        j = i + 1 if self.direction == 'UP' else i - 1
        if 0 <= j < len(s.effects):
            s.effects.move(i, j)
            s.active_effect = j
            live.refresh(context.scene)
        return {'FINISHED'}


class CUELIGHT_OT_effect_frame(bpy.types.Operator):
    bl_idname = "cuelight.effect_frame"
    bl_label = "Set from playhead"
    bl_description = "Set the effect's start or end to the current frame"
    bl_options = {'REGISTER', 'UNDO'}

    which: EnumProperty(items=(('START', "Start", ""), ('END', "End", "")))

    @classmethod
    def poll(cls, context):
        return active_effect(context) is not None

    def execute(self, context):
        e = active_effect(context)
        if self.which == 'START':
            e.frame_start = context.scene.frame_current
        else:
            e.frame_end = context.scene.frame_current
        return {'FINISHED'}


class CUELIGHT_OT_param_choice(bpy.types.Operator):
    bl_idname = "cuelight.param_choice"
    bl_label = "Choose"
    bl_description = "Pick this option"
    bl_options = {'REGISTER', 'UNDO', 'INTERNAL'}

    name: StringProperty()
    index: IntProperty()

    def execute(self, context):
        e = active_effect(context)
        et = e and params.get_type(e)
        if et is None or et.param(self.name) is None:
            return {'CANCELLED'}
        params.set_choice(e, et, self.name, self.index)
        live.refresh(context.scene)
        return {'FINISHED'}


class CUELIGHT_OT_color_add(bpy.types.Operator):
    bl_idname = "cuelight.color_add"
    bl_label = "Add colour"
    bl_description = "Add a colour to the effect"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return active_effect(context) is not None

    def execute(self, context):
        e = active_effect(context)
        c = e.colors.add()
        c.color = e.colors[-2].color if len(e.colors) > 1 else (1.0, 1.0, 1.0)
        e.active_color = len(e.colors) - 1
        live.refresh(context.scene)
        return {'FINISHED'}


class CUELIGHT_OT_color_remove(bpy.types.Operator):
    bl_idname = "cuelight.color_remove"
    bl_label = "Remove colour"
    bl_description = "Remove this colour"
    bl_options = {'REGISTER', 'UNDO'}

    index: IntProperty()

    @classmethod
    def poll(cls, context):
        e = active_effect(context)
        return e is not None and len(e.colors) > 1

    def execute(self, context):
        e = active_effect(context)
        e.colors.remove(self.index)
        live.refresh(context.scene)
        return {'FINISHED'}


class CUELIGHT_OT_refresh(bpy.types.Operator):
    bl_idname = "cuelight.refresh"
    bl_label = "Refresh"
    bl_description = "Re-run the effects for the current frame"

    def execute(self, context):
        live.refresh(context.scene)
        return {'FINISHED'}


classes = (
    CUELIGHT_OT_effect_add,
    CUELIGHT_OT_effect_remove,
    CUELIGHT_OT_effect_duplicate,
    CUELIGHT_OT_effect_move,
    CUELIGHT_OT_effect_frame,
    CUELIGHT_OT_param_choice,
    CUELIGHT_OT_color_add,
    CUELIGHT_OT_color_remove,
    CUELIGHT_OT_refresh,
)
