"""Draws effect lanes over the Timeline and Dope Sheet.

Ruytha Studios style: monochrome chrome (#0a0a0a lanes, #1c1c1c bars,
#4a4a4a lines, white for the selected layer). The only colour is the effect's
own colours, as a thin strip along the bottom of each bar.
"""

import math

import blf
import bpy
import gpu
from gpu_extras.batch import batch_for_shader

from ..cues import core as cues
from . import geometry

LANE_BG = (0.039, 0.039, 0.039, 0.6)
BAR = (0.11, 0.11, 0.11, 0.95)
BAR_ACTIVE = (0.15, 0.15, 0.15, 0.97)
LINE = (0.29, 0.29, 0.29, 1.0)
WHITE = (0.98, 0.98, 0.98, 1.0)
TEXT = (0.83, 0.83, 0.83, 1.0)
DIM_TEXT = (0.64, 0.64, 0.64, 1.0)
BAR_LINE = (0.29, 0.29, 0.29, 0.75)
BEAT_LINE = (0.29, 0.29, 0.29, 0.3)
CUE_LINE = (0.98, 0.98, 0.98, 0.85)


class _Painter:
    """Collects flat triangles per colour, then draws each colour in one batch."""

    def __init__(self):
        self.tris = {}

    def rect(self, x0, y0, x1, y1, color):
        if x1 <= x0 or y1 <= y0:
            return
        self.tris.setdefault(tuple(color), []).extend(
            [(x0, y0), (x1, y0), (x1, y1), (x0, y0), (x1, y1), (x0, y1)])

    def tri(self, a, b, c, color):
        self.tris.setdefault(tuple(color), []).extend([a, b, c])

    def frame(self, x0, y0, x1, y1, color, w=1.0):
        self.rect(x0, y0, x1, y0 + w, color)
        self.rect(x0, y1 - w, x1, y1, color)
        self.rect(x0, y0, x0 + w, y1, color)
        self.rect(x1 - w, y0, x1, y1, color)

    def flush(self):
        shader = gpu.shader.from_builtin('UNIFORM_COLOR')
        for color, verts in self.tris.items():
            batch = batch_for_shader(shader, 'TRIS', {"pos": verts})
            shader.bind()
            shader.uniform_float("color", color)
            batch.draw(shader)
        self.tris.clear()


def _faded(color, alpha):
    return (color[0], color[1], color[2], color[3] * alpha)


def visible(context):
    space = context.space_data
    if space is None or space.type != 'DOPESHEET_EDITOR' or space.mode not in {'TIMELINE', 'DOPESHEET'}:
        return False
    s = getattr(context.scene, "cuelight", None)
    return s is not None and s.show_lanes and len(s.effects) > 0


def layout_for(context):
    """(lanes, frame map, ui scale) for the region being drawn or clicked."""
    region = context.region
    scene = context.scene
    fmap = geometry.FrameMap.from_view2d(region.view2d)
    scale = context.preferences.system.ui_scale
    lanes = geometry.lanes(scene.cuelight.effects, fmap, region.height, scale,
                           has_markers=len(scene.timeline_markers) > 0)
    return lanes, fmap, scale


def draw():
    context = bpy.context
    if not visible(context):
        return
    scene = context.scene
    s = scene.cuelight
    region = context.region
    lanes, fmap, scale = layout_for(context)
    if not lanes:
        # The default Timeline is too short for even one lane: say how to get them
        if region.height >= 40 * scale:
            blf.size(0, 11 * scale)
            blf.color(0, *DIM_TEXT)
            blf.position(0, 8 * scale, region.height - 40 * scale, 0)
            blf.draw(0, "Drag the Timeline taller to see Cuelight's effect lanes")
        return
    top = max(ln.y1 for ln in lanes)
    bottom = min(ln.y0 for ln in lanes)
    gate = cues.gate(scene, scene.frame_current)

    p = _Painter()
    gpu.state.blend_set('ALPHA')

    for ln in lanes:
        p.rect(0, ln.y0, region.width, ln.y1, LANE_BG)
    for x, is_bar in geometry.grid_lines(scene, fmap, 0, region.width):
        p.rect(x, bottom, x + 1, top, BAR_LINE if is_bar else BEAT_LINE)

    labels = []
    for ln in lanes:
        e = s.effects[ln.index]
        active = ln.index == s.active_effect
        alpha = 1.0 if e.enabled else 0.35
        if gate is not None and gate.get(e.uid, 0.0) <= 0.0:
            alpha *= 0.5  # not in the cue playing now
        x0, x1 = max(ln.x0, -10), min(ln.x1, region.width + 10)
        if x1 < 0 or x0 > region.width:
            continue
        p.rect(x0, ln.y0, x1, ln.y1, _faded(BAR_ACTIVE if active else BAR, alpha))

        # Colour strip: the effect's own colours along the bottom edge
        if len(e.colors):
            w = (ln.x1 - ln.x0) / len(e.colors)
            for k, c in enumerate(e.colors):
                p.rect(max(ln.x0 + k * w, x0), ln.y0, min(ln.x0 + (k + 1) * w, x1), ln.y0 + 2 * scale,
                       (c.color[0], c.color[1], c.color[2], alpha))

        # Fade ramps cut the bar's top corners
        fi, fo = geometry.fade_frames(scene, e)
        if fi > 0:
            xf = fmap.x(e.frame_start + fi)
            p.tri((ln.x0, ln.y1), (xf, ln.y1), (ln.x0, ln.y0), LANE_BG)
            _line(p, ln.x0, ln.y0, xf, ln.y1, _faded(DIM_TEXT, alpha), scale)
        if fo > 0:
            xf = fmap.x(e.frame_end + 1 - fo)
            p.tri((xf, ln.y1), (ln.x1, ln.y1), (ln.x1, ln.y0), LANE_BG)
            _line(p, xf, ln.y1, ln.x1, ln.y0, _faded(DIM_TEXT, alpha), scale)

        p.frame(x0, ln.y0, x1, ln.y1, WHITE if active else _faded(LINE, alpha), 1.0 if not active else 1.5)
        if active:
            hs = 3 * scale
            for hx in geometry.fade_handles(scene, e, ln, fmap, scale):
                p.rect(hx - hs, ln.y1 - 2 * hs, hx + hs, ln.y1, WHITE)
        labels.append((ln, e, alpha))

    for c in s.cues:
        x = fmap.x(c.frame)
        if 0 <= x <= region.width:
            p.rect(x, bottom, x + 1, top + 4 * scale, CUE_LINE)

    p.flush()

    font = 0
    blf.size(font, 11 * scale)
    blf.enable(font, blf.CLIPPING)
    for ln, e, alpha in labels:
        if ln.y1 - ln.y0 < 10 * scale:
            continue  # too thin for text
        x0, x1 = max(ln.x0, 0), min(ln.x1, region.width)
        blf.clipping(font, x0 + 2, ln.y0, x1 - 4, ln.y1)
        ty = ln.y0 + (ln.y1 - ln.y0 - 8 * scale) / 2
        blf.position(font, x0 + 6 * scale, ty, 0)
        blf.color(font, *_faded(TEXT, alpha))
        blf.draw(font, e.name)
        w = blf.dimensions(font, e.name)[0]
        blf.position(font, x0 + 6 * scale + w + 8 * scale, ty, 0)
        blf.color(font, *_faded(DIM_TEXT, alpha * 0.8))
        blf.draw(font, e.group)
    blf.disable(font, blf.CLIPPING)
    for c in s.cues:
        x = fmap.x(c.frame)
        if 0 <= x <= region.width:
            blf.position(font, x + 4 * scale, top + 2 * scale, 0)
            blf.color(font, *CUE_LINE)
            blf.draw(font, cues.MARK + c.name)
    gpu.state.blend_set('NONE')


def _line(p, x0, y0, x1, y1, color, scale):
    """A diagonal line as a thin quad."""
    dx, dy = x1 - x0, y1 - y0
    n = math.hypot(dx, dy) or 1.0
    ox, oy = -dy / n * 0.6 * scale, dx / n * 0.6 * scale
    a, b, c, d = (x0 - ox, y0 - oy), (x1 - ox, y1 - oy), (x1 + ox, y1 + oy), (x0 + ox, y0 + oy)
    p.tri(a, b, c, color)
    p.tri(a, c, d, color)


_handle = None


def register():
    global _handle
    _handle = bpy.types.SpaceDopeSheetEditor.draw_handler_add(draw, (), 'WINDOW', 'POST_PIXEL')


def unregister():
    global _handle
    if _handle is not None:
        bpy.types.SpaceDopeSheetEditor.draw_handler_remove(_handle, 'WINDOW')
        _handle = None
