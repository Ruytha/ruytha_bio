"""Mouse on the lanes: click to select, drag to move, trim or fade, right-click
for a menu. Anywhere off a bar, the click passes straight through to Blender."""

import bpy
from bpy.props import EnumProperty

from ..engine import live
from . import draw, geometry


def _snap_mode(event):
    if event.ctrl:
        return 'NONE'
    return 'BAR' if event.shift else 'BEAT'


def _redraw(context):
    for area in context.screen.areas if context.screen else ():
        if area.type == 'DOPESHEET_EDITOR':
            area.tag_redraw()


class CUELIGHT_OT_lane_click(bpy.types.Operator):
    bl_idname = "cuelight.lane_click"
    bl_label = "Edit effect lane"
    bl_description = ("Click a lane to select its layer. Drag to move, drag an end to trim, drag a top "
                      "corner handle to fade. Snaps to beats; Shift snaps to bars, Ctrl turns snapping off")
    bl_options = {'UNDO', 'INTERNAL'}

    def invoke(self, context, event):
        if not draw.visible(context):
            return {'PASS_THROUGH'}
        lanes, fmap, scale = draw.layout_for(context)
        ln, part = geometry.hit(context.scene, lanes, fmap, event.mouse_region_x, event.mouse_region_y, scale)
        if ln is None:
            return {'PASS_THROUGH'}
        s = context.scene.cuelight
        s.active_effect = ln.index
        e = s.effects[ln.index]
        self.index, self.part, self.fmap = ln.index, part, fmap
        self.orig = (e.frame_start, e.frame_end, e.fade_in, e.fade_out)
        self.x0 = event.mouse_region_x
        self.moved = False
        context.window_manager.modal_handler_add(self)
        _redraw(context)
        return {'RUNNING_MODAL'}

    def _apply(self, context, values):
        e = context.scene.cuelight.effects[self.index]
        start, end, fi, fo = values
        # Order matters: never let start pass end mid-update
        if start > e.frame_end:
            e.frame_end, e.frame_start = end, start
        else:
            e.frame_start, e.frame_end = start, end
        e.fade_in, e.fade_out = fi, fo

    def modal(self, context, event):
        if event.type == 'MOUSEMOVE':
            if abs(event.mouse_region_x - self.x0) < 3 and not self.moved:
                return {'RUNNING_MODAL'}
            self.moved = True
            e = context.scene.cuelight.effects[self.index]
            delta = self.fmap.frame(event.mouse_region_x) - self.fmap.frame(self.x0)
            values = geometry.drag(context.scene, self.part, self.orig[0], self.orig[1], self.orig[2],
                                   self.orig[3], e.fade_unit, delta, self.fmap.frame(event.mouse_region_x),
                                   _snap_mode(event))
            self._apply(context, values)
            start, end, fi, fo = values
            if self.part in {'FADE_IN', 'FADE_OUT'}:
                v = fi if self.part == 'FADE_IN' else fo
                context.area.header_text_set("Fade %s: %g %s" % (
                    "in" if self.part == 'FADE_IN' else "out", v, e.fade_unit.lower()))
            else:
                context.area.header_text_set("%s  %d to %d   Shift: bars   Ctrl: no snap" % (e.name, start, end))
            _redraw(context)
            return {'RUNNING_MODAL'}
        if event.type == 'LEFTMOUSE' and event.value == 'RELEASE':
            context.area.header_text_set(None)
            live.refresh(context.scene)
            return {'FINISHED'}
        if event.type in {'RIGHTMOUSE', 'ESC'}:
            self._apply(context, self.orig)
            context.area.header_text_set(None)
            _redraw(context)
            return {'CANCELLED'}
        return {'RUNNING_MODAL'}


class CUELIGHT_OT_lane_menu(bpy.types.Operator):
    bl_idname = "cuelight.lane_menu"
    bl_label = "Effect lane menu"
    bl_description = "Right-click a lane for duplicate, delete, mute and playhead trims"
    bl_options = {'INTERNAL'}

    def invoke(self, context, event):
        if not draw.visible(context):
            return {'PASS_THROUGH'}
        lanes, fmap, scale = draw.layout_for(context)
        ln, _ = geometry.hit(context.scene, lanes, fmap, event.mouse_region_x, event.mouse_region_y, scale)
        if ln is None:
            return {'PASS_THROUGH'}
        context.scene.cuelight.active_effect = ln.index
        bpy.ops.wm.call_menu(name="CUELIGHT_MT_lane")
        return {'FINISHED'}


class CUELIGHT_OT_lane_mute(bpy.types.Operator):
    bl_idname = "cuelight.lane_mute"
    bl_label = "Mute"
    bl_description = "Turn the selected layer on or off"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        from ..effects.ops import active_effect
        e = active_effect(context)
        if e is None:
            return {'CANCELLED'}
        e.enabled = not e.enabled
        _redraw(context)
        return {'FINISHED'}


class CUELIGHT_OT_lane_snap(bpy.types.Operator):
    bl_idname = "cuelight.lane_snap"
    bl_label = "Snap to grid"
    bl_description = "Snap the selected layer's start and end to the beat grid"
    bl_options = {'REGISTER', 'UNDO'}

    to: EnumProperty(items=(('BEAT', "Beats", ""), ('BAR', "Bars", "")))

    def execute(self, context):
        from ..effects.ops import active_effect
        e = active_effect(context)
        if e is None:
            return {'CANCELLED'}
        start = geometry.snap(context.scene, e.frame_start, self.to)
        end = max(geometry.snap(context.scene, e.frame_end + 1, self.to) - 1, start)
        e.frame_start, e.frame_end = start, end
        _redraw(context)
        return {'FINISHED'}


class CUELIGHT_MT_lane(bpy.types.Menu):
    bl_idname = "CUELIGHT_MT_lane"
    bl_label = "Effect layer"

    def draw(self, context):
        from ..effects.ops import active_effect
        layout = self.layout
        e = active_effect(context)
        if e is None:
            return
        layout.label(text=e.name)
        layout.operator("cuelight.lane_mute", text="Unmute" if not e.enabled else "Mute",
                        icon='HIDE_OFF' if not e.enabled else 'HIDE_ON')
        layout.operator("cuelight.effect_duplicate", text="Duplicate", icon='DUPLICATE')
        layout.separator()
        layout.operator("cuelight.effect_frame", text="Start at playhead").which = 'START'
        layout.operator("cuelight.effect_frame", text="End at playhead").which = 'END'
        layout.operator("cuelight.lane_snap", text="Snap to bars").to = 'BAR'
        layout.operator("cuelight.lane_snap", text="Snap to beats").to = 'BEAT'
        layout.separator()
        layout.operator("cuelight.effect_remove", text="Delete", icon='TRASH')


def header_toggle(self, context):
    """Appended to the Timeline / Dope Sheet header."""
    s = getattr(context.scene, "cuelight", None)
    if s is None or context.space_data.mode not in {'TIMELINE', 'DOPESHEET'}:
        return
    from ..utils.icons import icon
    self.layout.prop(s, "show_lanes", text="Cuelight", icon_value=icon("mark"), toggle=True)


classes = (
    CUELIGHT_OT_lane_click,
    CUELIGHT_OT_lane_menu,
    CUELIGHT_OT_lane_mute,
    CUELIGHT_OT_lane_snap,
    CUELIGHT_MT_lane,
)
