import bpy

from . import draw, ops

_keymaps = []


def register():
    for c in ops.classes:
        bpy.utils.register_class(c)
    bpy.types.DOPESHEET_HT_header.append(ops.header_toggle)
    if not bpy.app.background:
        draw.register()
    kc = bpy.context.window_manager.keyconfigs.addon
    if kc is not None:
        km = kc.keymaps.new(name="Dopesheet", space_type='DOPESHEET_EDITOR')
        _keymaps.append((km, km.keymap_items.new("cuelight.lane_click", 'LEFTMOUSE', 'PRESS')))
        _keymaps.append((km, km.keymap_items.new("cuelight.lane_click", 'LEFTMOUSE', 'PRESS', shift=True)))
        _keymaps.append((km, km.keymap_items.new("cuelight.lane_click", 'LEFTMOUSE', 'PRESS', ctrl=True)))
        _keymaps.append((km, km.keymap_items.new("cuelight.lane_menu", 'RIGHTMOUSE', 'PRESS')))


def unregister():
    for km, kmi in _keymaps:
        km.keymap_items.remove(kmi)
    _keymaps.clear()
    draw.unregister()
    bpy.types.DOPESHEET_HT_header.remove(ops.header_toggle)
    for c in reversed(ops.classes):
        bpy.utils.unregister_class(c)
