"""Timeline lanes: where everything sits, what's under the mouse, and what a
drag does. No drawing and no bpy UI here, so it's all unit-testable."""

from dataclasses import dataclass

from ..engine import timing

LANE_H = 18.0       # px at UI scale 1
LANE_MIN = 7.0
LANE_GAP = 2.0
TOP_RESERVE = 26.0  # the scrubbing strip with frame numbers
BOTTOM_RESERVE = 6.0
MARKER_RESERVE = 44.0  # Blender draws markers (and takes clicks) in the bottom ~42 px
EDGE = 6.0          # px either end of a bar that trims instead of moving
FADE_GRAB = 6.0     # px around a fade handle


@dataclass
class FrameMap:
    """Linear frame <-> region-x mapping, taken from the region's View2D."""
    x_at_0: float
    px_per_frame: float

    @classmethod
    def from_view2d(cls, v2d):
        a = v2d.view_to_region(0.0, 0.0, clip=False)[0]
        b = v2d.view_to_region(1000.0, 0.0, clip=False)[0]
        return cls(float(a), (b - a) / 1000.0)

    def x(self, frame):
        return self.x_at_0 + frame * self.px_per_frame

    def frame(self, x):
        return (x - self.x_at_0) / self.px_per_frame


@dataclass
class Lane:
    index: int      # index into scene.cuelight.effects
    y0: float       # bottom
    y1: float       # top
    x0: float       # bar start (frame_start)
    x1: float       # bar end (after frame_end)


def lanes(effects, fmap, region_h, scale=1.0, has_markers=False):
    """Lanes for every effect, stacked up from the bottom of the editor (just above
    the markers) so they stay clear of channels and keyframes at the top. Top layer
    on top. Shrinks to fit short regions; lanes that still don't fit are left out."""
    n = len(effects)
    if n == 0:
        return []
    top = region_h - TOP_RESERVE * scale
    bottom = (MARKER_RESERVE if has_markers else BOTTOM_RESERVE) * scale
    room = max(0.0, top - bottom)
    gap = LANE_GAP * scale
    h = min(LANE_H * scale, max(LANE_MIN * scale, room / n - gap))
    out = []
    y = bottom
    for i in range(n):  # first effect = bottom layer = bottom lane
        e = effects[i]
        if y + h > top + 0.5:
            break  # out of room: the topmost layers aren't drawn
        out.append(Lane(i, y, y + h, fmap.x(e.frame_start), fmap.x(e.frame_end + 1)))
        y += h + gap
    return out


def fade_frames(scene, effect):
    """(fade in, fade out) in frames."""
    s = scene.cuelight
    unit = timing.frames_per_beat(scene, s) if effect.fade_unit == 'BEATS' else timing.fps(scene)
    return effect.fade_in * unit, effect.fade_out * unit


def fade_handles(scene, effect, lane, fmap, scale=1.0):
    """x of the fade-in and fade-out handles. With no fade they sit just inside
    the trim zones, so there's always something to grab."""
    fi, fo = fade_frames(scene, effect)
    inset = (EDGE + FADE_GRAB) * scale
    hx_in = max(fmap.x(effect.frame_start + fi), lane.x0 + inset)
    hx_out = min(fmap.x(effect.frame_end + 1 - fo), lane.x1 - inset)
    return hx_in, hx_out


def hit(scene, lane_list, fmap, x, y, scale=1.0):
    """(lane, part) under the mouse, or (None, None). part: BODY, START, END, FADE_IN, FADE_OUT."""
    effects = scene.cuelight.effects
    for ln in lane_list:
        if not (ln.y0 <= y <= ln.y1):
            continue
        edge = EDGE * scale
        if not (ln.x0 - edge <= x <= ln.x1 + edge):
            return None, None  # in this lane but off the bar: let Blender have the click
        if y >= ln.y1 - (ln.y1 - ln.y0) * 0.45:  # fade handles live on the top edge
            hx_in, hx_out = fade_handles(scene, effects[ln.index], ln, fmap, scale)
            grab = FADE_GRAB * scale
            if abs(x - hx_in) <= grab:
                return ln, 'FADE_IN'
            if abs(x - hx_out) <= grab:
                return ln, 'FADE_OUT'
        if abs(x - ln.x0) <= edge:
            return ln, 'START'
        if abs(x - ln.x1) <= edge:
            return ln, 'END'
        return ln, 'BODY'
    return None, None


def snap(scene, frame, mode):
    """Nearest beat or bar line to a (float) frame. mode: NONE, BEAT, BAR."""
    if mode == 'NONE':
        return int(round(frame))
    s = scene.cuelight
    step = timing.frames_per_beat(scene, s) * (s.beats_per_bar if mode == 'BAR' else 1)
    k = round((frame - s.beat_offset) / step)
    return int(round(s.beat_offset + k * step))


def drag(scene, part, start, end, fade_in, fade_out, fade_unit, delta, mouse_frame, mode):
    """New (start, end, fade_in, fade_out) for dragging `part` by `delta` frames.

    start/end are the values when the drag began; end is inclusive.
    mouse_frame is where the mouse is now (for fades).
    """
    if part == 'BODY':
        ns = snap(scene, start + delta, mode)
        return ns, end + (ns - start), fade_in, fade_out
    if part == 'START':
        ns = min(snap(scene, start + delta, mode), end)
        return ns, end, fade_in, fade_out
    if part == 'END':
        ne = max(snap(scene, end + 1 + delta, mode) - 1, start)
        return start, ne, fade_in, fade_out

    s = scene.cuelight
    unit = timing.frames_per_beat(scene, s) if fade_unit == 'BEATS' else timing.fps(scene)
    length = end + 1 - start
    if part == 'FADE_IN':
        frames = min(max(mouse_frame - start, 0.0), length - fade_out * unit)
        value = frames / unit
    else:
        frames = min(max(end + 1 - mouse_frame, 0.0), length - fade_in * unit)
        value = frames / unit
    if mode != 'NONE':
        q = 0.5 if fade_unit == 'BEATS' else 0.25  # half beats, quarter seconds
        value = round(value / q) * q
    value = max(0.0, value)
    return (start, end, value, fade_out) if part == 'FADE_IN' else (start, end, fade_in, value)


def grid_lines(scene, fmap, x_min, x_max, min_px=6.0):
    """[(x, is_bar)] for beat and bar lines on screen. Beats drop out when too dense."""
    s = scene.cuelight
    fpb = timing.frames_per_beat(scene, s)
    if fpb * abs(fmap.px_per_frame) < 1e-6:
        return []
    show_beats = fpb * abs(fmap.px_per_frame) >= min_px
    bar_px = fpb * s.beats_per_bar * abs(fmap.px_per_frame)
    if not show_beats and bar_px < min_px:
        return []
    f_lo, f_hi = sorted((fmap.frame(x_min), fmap.frame(x_max)))
    k0 = int((f_lo - s.beat_offset) // fpb)
    k1 = int((f_hi - s.beat_offset) // fpb) + 1
    out = []
    for k in range(k0, k1 + 1):
        is_bar = k % s.beats_per_bar == 0
        if is_bar or show_beats:
            out.append((fmap.x(s.beat_offset + k * fpb), is_bar))
    return out
