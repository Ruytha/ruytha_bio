"""Names of the custom properties that make up a fixture.

Effects only ever write the control channels on a head. Drivers carry those
values to lights and emissive meshes, so a .blend keeps working without the
add-on installed.
"""

# Identification
TYPE = "cl_fixture_type"     # on fixture roots: SPOT, WASH, LEDBAR, LASER, STROBE
HEAD = "cl_head"             # 1 on every object effects can write to
PART = "cl_part"             # role of a child object inside a fixture rig
PIXEL = "cl_pixel"           # pixel index inside an LED bar

# Control channels (written by effects)
INTENSITY = "cl_intensity"
COLOR = "cl_color"
PAN = "cl_pan"
TILT = "cl_tilt"
ZOOM = "cl_zoom"
STROBE = "cl_strobe"
SHUTTER = "cl_shutter"       # 0/1, computed by the engine from STROBE

# Fixture settings (set by the user, not by effects)
POWER = "cl_power"           # watts at intensity 1
BEAM = "cl_beam"             # visible beam cone opacity
BEAM_LENGTH = "cl_beam_length"
GOBO = "cl_gobo"
BEAM_CONES = "cl_beam_cones"  # on the scene: master for every beam cone

# Read by the shared materials through an Attribute node
EMIT = "cl_emit"
GAIN = "cl_gain"

FIXTURE_TYPES = (
    ('SPOT', "Spot", "Moving-head spot with pan, tilt, zoom and an optional gobo"),
    ('WASH', "Wash", "Wide wash or PAR, as a spot or an area light"),
    ('LEDBAR', "LED bar", "Strip of emissive pixels, each one addressable"),
    ('LASER', "Laser", "Fan of thin emissive beams with adjustable spread"),
    ('STROBE', "Strobe", "High-output area light with an emissive face"),
)
TYPE_LABEL = {k: label for k, label, _ in FIXTURE_TYPES}

# Degrees of beam angle at zoom 0 and zoom 1
ZOOM_RANGE = {
    'SPOT': (4.0, 30.0),
    'WASH': (20.0, 70.0),
}
LASER_SPREAD = 60.0  # full fan angle at zoom 1

DEFAULT_POWER = {
    'SPOT': 3000.0,
    'WASH': 1500.0,
    'LEDBAR': 0.0,
    'LASER': 0.0,
    'STROBE': 6000.0,
}

GOBOS = (
    ('NONE', "Open", "No gobo"),
    ('DOTS', "Dots", "Seven-dot pattern"),
    ('SPOKES', "Spokes", "Eight radial spokes"),
    ('RING', "Ring", "Ring with a centre dot"),
    ('BREAKUP', "Breakup", "Organic leaf breakup"),
    ('IMAGE', "Image", "Your own image file"),
)


def fixture_root(obj):
    """The fixture root an object belongs to, or None."""
    while obj is not None:
        if TYPE in obj:
            return obj
        obj = obj.parent
    return None


def is_root(obj):
    return obj is not None and TYPE in obj


def fixtures_in(scene):
    return [o for o in scene.objects if TYPE in o]
