import bpy

from . import ops


def register():
    for c in ops.classes:
        bpy.utils.register_class(c)


def unregister():
    for c in reversed(ops.classes):
        bpy.utils.unregister_class(c)
