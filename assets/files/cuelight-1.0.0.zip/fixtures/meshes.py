"""Shared meshes for fixture rigs.

Every fixture of a type links the same mesh datablocks, so a stage of 100
fixtures holds a handful of meshes, not hundreds.
"""

import bmesh
import bpy
from mathutils import Matrix

MESH_VERSION = 1


def _shared(name, build, material=None):
    me = bpy.data.meshes.get(name)
    if me is not None and me.get("cl_mesh_version") == MESH_VERSION:
        return me
    if me is None:
        me = bpy.data.meshes.new(name)
    bm = bmesh.new()
    build(bm)
    bm.to_mesh(me)
    bm.free()
    me["cl_mesh_version"] = MESH_VERSION
    me.materials.clear()
    if material is not None:
        me.materials.append(material)
    return me


def _box(bm, sx, sy, sz, x=0.0, y=0.0, z=0.0):
    m = Matrix.Translation((x, y, z)) @ Matrix.Diagonal((sx, sy, sz, 1.0))
    bmesh.ops.create_cube(bm, size=1.0, matrix=m)


def _cyl(bm, r, depth, z=0.0, segments=24, r2=None):
    bmesh.ops.create_cone(
        bm, cap_ends=True, cap_tris=False, segments=segments,
        radius1=r, radius2=r if r2 is None else r2, depth=depth,
        matrix=Matrix.Translation((0, 0, z)))


def _smooth(me):
    me.shade_smooth()


def spot_base(mat):
    return _shared("CL Spot Base", lambda bm: _box(bm, 0.34, 0.34, 0.1, z=-0.05), mat)


def yoke(mat, arm=0.22, width=0.3):
    def build(bm):
        _box(bm, width + 0.06, 0.08, 0.04, z=-0.02)
        for x in (-width / 2, width / 2):
            _box(bm, 0.03, 0.08, arm, x=x, z=-arm / 2)
    return _shared("CL Yoke %.2f" % width, build, mat)


def spot_head(mat):
    me = _shared("CL Spot Head", lambda bm: _cyl(bm, 0.11, 0.34, r2=0.13), mat)
    _smooth(me)
    return me


def wash_head(mat):
    me = _shared("CL Wash Head", lambda bm: _cyl(bm, 0.16, 0.26), mat)
    _smooth(me)
    return me


def lens(mat, r):
    def build(bm):
        bmesh.ops.create_circle(bm, cap_ends=True, segments=32, radius=r)
    return _shared("CL Lens %.2f" % r, build, mat)


def beam_cone():
    """Tip at the origin, radius 1 at z = -1, open-ended. Object scale sets angle and length."""
    def build(bm):
        bmesh.ops.create_cone(
            bm, cap_ends=False, cap_tris=False, segments=32,
            radius1=1.0, radius2=0.02, depth=1.0,
            matrix=Matrix.Translation((0, 0, -0.5)))
    me = _shared("CL Beam Cone", build)
    _smooth(me)
    return me


def ledbar_housing(mat, length):
    return _shared("CL LED Bar %.2f" % length,
                   lambda bm: _box(bm, length + 0.04, 0.08, 0.06, z=0.03), mat)


def pixel(mat, pitch):
    return _shared("CL Pixel %.3f" % pitch,
                   lambda bm: _box(bm, pitch * 0.86, 0.06, 0.012, z=-0.006), mat)


def laser_housing(mat):
    return _shared("CL Laser Body", lambda bm: _box(bm, 0.22, 0.26, 0.14, z=0.0), mat)


def laser_beam():
    """Unit-length thin cylinder from the origin along -Z."""
    me = _shared("CL Laser Beam", lambda bm: _cyl(bm, 0.004, 1.0, z=-0.5, segments=8))
    _smooth(me)
    return me


def strobe_housing(mat):
    return _shared("CL Strobe Body", lambda bm: _box(bm, 0.6, 0.18, 0.16, z=0.0), mat)


def strobe_face(mat):
    def build(bm):
        bmesh.ops.create_grid(bm, x_segments=1, y_segments=1, size=0.5,
                              matrix=Matrix.Diagonal((1.08, 0.26, 1.0, 1.0)))
    return _shared("CL Strobe Face", build, mat)


def haze_box():
    return _shared("CL Haze Box", lambda bm: _box(bm, 2.0, 2.0, 2.0))
