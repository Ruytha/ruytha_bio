"""Placement for fixture arrays: line, arc, circle and grid."""

import math

from mathutils import Vector

LAYOUTS = (
    ('LINE', "Line", "Evenly spaced along X"),
    ('ARC', "Arc", "Along an arc behind the cursor, facing its centre"),
    ('CIRCLE', "Circle", "A full ring around the cursor, facing its centre"),
    ('GRID', "Grid", "Rows and columns on the XY plane"),
)


def placements(layout, count, spacing=1.0, radius=6.0, arc=120.0, rows=2):
    """List of (offset Vector, yaw radians). Yaw turns local -Y towards the centre."""
    out = []
    if count < 1:
        return out
    if layout == 'LINE':
        for i in range(count):
            out.append((Vector(((i - (count - 1) / 2) * spacing, 0, 0)), 0.0))
    elif layout in {'ARC', 'CIRCLE'}:
        if layout == 'CIRCLE':
            angles = [2 * math.pi * i / count for i in range(count)]
        else:
            span = math.radians(arc)
            angles = [0.0] if count == 1 else [-span / 2 + span * i / (count - 1) for i in range(count)]
        for a in angles:
            # Angle 0 is upstage (+Y), so an arc wraps behind the cursor
            out.append((Vector((radius * math.sin(a), radius * math.cos(a), 0)), -a))
    elif layout == 'GRID':
        rows = max(1, min(rows, count))
        cols = math.ceil(count / rows)
        for i in range(count):
            r, c = divmod(i, cols)
            out.append((Vector(((c - (cols - 1) / 2) * spacing, ((rows - 1) / 2 - r) * spacing, 0)), 0.0))
    return out
