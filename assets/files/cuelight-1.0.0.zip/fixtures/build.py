"""Fixture rigs.

Every fixture is a root Empty that holds the control channels as custom
properties. Lights, rig rotations and emissive parts are wired to those
properties with simple-expression drivers.
"""

import math

import bpy

from . import gobos, materials, meshes
from . import schema as S
from ..utils.idprops import add_driver, num, set_prop

COLLECTION = "Cuelight"

MOUNTS = (
    ('HANG', "Hang", "Points down, as from a truss"),
    ('FLOOR', "Floor", "Points up, standing on the deck"),
    ('FRONT', "Front", "Points at the audience (-Y)"),
)
MOUNT_ROTATION = {
    'HANG': (0.0, 0.0, 0.0),
    'FLOOR': (math.pi, 0.0, 0.0),
    'FRONT': (-math.pi / 2, 0.0, 0.0),
}


# ---------------------------------------------------------------- helpers

def collection(scene):
    """The scene's Cuelight collection, created on first use."""
    for c in scene.collection.children_recursive:
        if c.get("cl_collection"):
            return c
    c = bpy.data.collections.new(COLLECTION)
    c["cl_collection"] = 1
    scene.collection.children.link(c)
    return c


def _rays(obj, camera=True, diffuse=False, glossy=True, shadow=False):
    obj.visible_camera = camera
    obj.visible_diffuse = diffuse
    obj.visible_glossy = glossy
    obj.visible_transmission = False
    obj.visible_volume_scatter = False
    obj.visible_shadow = shadow


def _ctl(name, k=None):
    return '["%s"]' % name if k is None else '["%s"][%d]' % (name, k)


class _Builder:
    def __init__(self, scene, root, coll):
        self.scene = scene
        self.root = root
        self.coll = coll

    def part(self, label, data, part, parent=None, loc=(0, 0, 0), rot=(0, 0, 0)):
        o = bpy.data.objects.new("%s · %s" % (self.root.name, label), data)
        self.coll.objects.link(o)
        o.parent = parent or self.root
        o.location = loc
        o.rotation_euler = rot
        o[S.PART] = part
        o.hide_select = True
        if data is None:
            o.empty_display_size = 0.05
        return o

    def rig(self, housing, arm, width, base=True):
        """Base -> yoke (pan about Z) -> head pivot (tilt about X). Returns the head pivot."""
        r = self.root
        if base:
            self.part("Base", meshes.spot_base(housing), "base")
        yoke = self.part("Yoke", meshes.yoke(housing, arm, width), "yoke", loc=(0, 0, -0.1))
        add_driver(yoke, "rotation_euler", "radians(p)", {"p": (r, _ctl(S.PAN))}, index=2)
        head = self.part("Pivot", None, "pivot", parent=yoke, loc=(0, 0, -arm * 0.8))
        add_driver(head, "rotation_euler", "radians(t)", {"t": (r, _ctl(S.TILT))}, index=0)
        return head

    def emissive(self, obj, gain, extra=None):
        """cl_emit = colour x intensity x shutter (x extra factors).

        extra: [(variable, target ID, data path)]
        """
        r = self.root
        set_prop(obj, S.GAIN, float(gain))
        set_prop(obj, S.EMIT, [0.0, 0.0, 0.0])
        names = ["c", "i", "s"] + [n for n, _, _ in (extra or [])]
        for k in range(3):
            v = {"c": (r, _ctl(S.COLOR, k)), "i": (r, _ctl(S.INTENSITY)), "s": (r, _ctl(S.SHUTTER))}
            for n, target, path in extra or []:
                v[n] = (target, path)
            add_driver(obj, _ctl(S.EMIT), "*".join(names), v, index=k)

    def light(self, light, size_path=None, zoom_range=None):
        r = self.root
        add_driver(light, "energy", "w*i*s",
                   {"w": (r, _ctl(S.POWER)), "i": (r, _ctl(S.INTENSITY)), "s": (r, _ctl(S.SHUTTER))})
        for k in range(3):
            add_driver(light, "color", "c", {"c": (r, _ctl(S.COLOR, k))}, index=k)
        if size_path:
            a, b = zoom_range
            add_driver(light, size_path, "radians(%s+%s*z)" % (num(a), num(b - a)),
                       {"z": (r, _ctl(S.ZOOM))})

    def cone(self, parent, z, zoom_range, gain):
        r = self.root
        c = self.part("Beam", meshes.beam_cone(), "beam", parent=parent, loc=(0, 0, z))
        if not c.data.materials:
            c.data.materials.append(materials.beam())
        c.material_slots[0].link = 'OBJECT'
        c.material_slots[0].material = materials.beam()
        a, b = zoom_range
        width = "tan(radians(%s+%s*z)*0.5)*L" % (num(a), num(b - a))
        for k in (0, 1):
            add_driver(c, "scale", width,
                       {"z": (r, _ctl(S.ZOOM)), "L": (r, _ctl(S.BEAM_LENGTH))}, index=k)
        add_driver(c, "scale", "L", {"L": (r, _ctl(S.BEAM_LENGTH))}, index=2)
        self.emissive(c, gain, extra=[("b", r, _ctl(S.BEAM)), ("m", self.scene, _ctl(S.BEAM_CONES))])
        _rays(c, glossy=False)
        return c


def _controls(o, color=(1.0, 1.0, 1.0)):
    set_prop(o, S.HEAD, 1)
    set_prop(o, S.INTENSITY, 1.0, min=0.0, max=10.0, soft_max=1.0, description="Dimmer")
    set_prop(o, S.COLOR, list(color), subtype='COLOR', min=0.0, max=1.0, description="Colour")
    set_prop(o, S.PAN, 0.0, soft_min=-270.0, soft_max=270.0, description="Pan in degrees")
    set_prop(o, S.TILT, 0.0, soft_min=-135.0, soft_max=135.0, description="Tilt in degrees")
    set_prop(o, S.ZOOM, 0.5, min=0.0, max=1.0, description="Beam angle, narrow to wide")
    set_prop(o, S.STROBE, 0.0, min=0.0, soft_max=25.0, description="Shutter rate in Hz, 0 is open")
    set_prop(o, S.SHUTTER, 1.0, min=0.0, max=1.0, description="Shutter state, set by Cuelight")


def _beam_settings(root, beam, length):
    set_prop(root, S.BEAM, beam, min=0.0, max=1.0, description="Visible beam strength")
    set_prop(root, S.BEAM_LENGTH, length, min=0.5, soft_max=60.0, subtype='DISTANCE',
             description="Visible beam length")


# ---------------------------------------------------------------- types

def _spot(b, gobo='NONE', beam=0.35, beam_length=14.0, **_):
    hm, em, r = materials.housing(), materials.emit(), b.root
    _beam_settings(r, beam, beam_length)
    r[S.GOBO] = 'NONE'
    head = b.rig(hm, arm=0.3, width=0.32)
    b.part("Body", meshes.spot_head(hm), "body", parent=head)
    lens = b.part("Lens", meshes.lens(em, 0.1), "lens", parent=head, loc=(0, 0, -0.172))
    b.emissive(lens, 30.0)
    _rays(lens)
    ld = bpy.data.lights.new(r.name, 'SPOT')
    ld.spot_blend = 0.2
    ld.shadow_soft_size = 0.02
    b.part("Light", ld, "light", parent=head, loc=(0, 0, -0.176))
    b.light(ld, "spot_size", S.ZOOM_RANGE['SPOT'])
    b.cone(head, -0.176, S.ZOOM_RANGE['SPOT'], gain=1.5)
    if gobo != 'NONE':
        set_gobo(r, gobo)


def _wash(b, light_type='SPOT', beam=0.15, beam_length=10.0, **_):
    hm, em, r = materials.housing(), materials.emit(), b.root
    _beam_settings(r, beam, beam_length)
    head = b.rig(hm, arm=0.32, width=0.4)
    b.part("Body", meshes.wash_head(hm), "body", parent=head)
    lens = b.part("Lens", meshes.lens(em, 0.14), "lens", parent=head, loc=(0, 0, -0.132))
    b.emissive(lens, 20.0)
    _rays(lens)
    if light_type == 'AREA':
        ld = bpy.data.lights.new(r.name, 'AREA')
        ld.shape = 'DISK'
        ld.size = 0.28
        b.light(ld, "spread", S.ZOOM_RANGE['WASH'])
    else:
        ld = bpy.data.lights.new(r.name, 'SPOT')
        ld.spot_blend = 0.75
        ld.shadow_soft_size = 0.14
        b.light(ld, "spot_size", S.ZOOM_RANGE['WASH'])
    b.part("Light", ld, "light", parent=head, loc=(0, 0, -0.136))
    b.cone(head, -0.136, S.ZOOM_RANGE['WASH'], gain=1.0)


def _ledbar(b, pixels=16, pitch=0.0625, **_):
    hm, em, r = materials.housing(), materials.emit(), b.root
    set_prop(r, "cl_pixels", int(pixels))
    length = pixels * pitch
    b.part("Housing", meshes.ledbar_housing(hm, length), "housing")
    px_mesh = meshes.pixel(em, pitch)
    for k in range(pixels):
        x = (k - (pixels - 1) / 2) * pitch
        p = b.part("Pixel %02d" % (k + 1), px_mesh, "pixel", loc=(x, 0, 0))
        _controls(p)
        set_prop(p, S.PIXEL, k)
        set_prop(p, S.GAIN, 8.0)
        set_prop(p, S.EMIT, [0.0, 0.0, 0.0])
        for c in range(3):
            add_driver(p, _ctl(S.EMIT), "pc*mc*pi*mi*ps*ms", {
                "pc": (p, _ctl(S.COLOR, c)), "mc": (r, _ctl(S.COLOR, c)),
                "pi": (p, _ctl(S.INTENSITY)), "mi": (r, _ctl(S.INTENSITY)),
                "ps": (p, _ctl(S.SHUTTER)), "ms": (r, _ctl(S.SHUTTER)),
            }, index=c)
        _rays(p)


def _laser(b, beams=5, beam_length=25.0, **_):
    hm, em, r = materials.housing(), materials.emit(), b.root
    set_prop(r, S.BEAM_LENGTH, beam_length, min=0.5, soft_max=80.0, subtype='DISTANCE',
             description="Beam length")
    set_prop(r, "cl_beams", int(beams))
    r[S.COLOR] = [0.1, 1.0, 0.2]
    head = b.rig(hm, arm=0.16, width=0.3)
    b.part("Body", meshes.laser_housing(hm), "body", parent=head)
    mesh = meshes.laser_beam()
    for k in range(beams):
        f = 0.0 if beams == 1 else (k / (beams - 1) - 0.5) * S.LASER_SPREAD
        o = b.part("Beam %02d" % (k + 1), mesh, "laser", parent=head, loc=(0, 0, -0.07))
        if not o.data.materials:
            o.data.materials.append(em)
        add_driver(o, "rotation_euler", "radians(%s*z)" % num(f), {"z": (r, _ctl(S.ZOOM))}, index=1)
        add_driver(o, "scale", "L", {"L": (r, _ctl(S.BEAM_LENGTH))}, index=2)
        b.emissive(o, 40.0)
        _rays(o)


def _strobe(b, **_):
    hm, em, r = materials.housing(), materials.emit(), b.root
    b.part("Body", meshes.strobe_housing(hm), "body")
    face = b.part("Face", meshes.strobe_face(em), "face", loc=(0, 0, -0.081))
    b.emissive(face, 40.0)
    _rays(face)
    ld = bpy.data.lights.new(r.name, 'AREA')
    ld.shape = 'RECTANGLE'
    ld.size = 0.54
    ld.size_y = 0.13
    b.part("Light", ld, "light", loc=(0, 0, -0.09))
    b.light(ld)


BUILDERS = {'SPOT': _spot, 'WASH': _wash, 'LEDBAR': _ledbar, 'LASER': _laser, 'STROBE': _strobe}


# ---------------------------------------------------------------- public

def create(scene, ftype, location=(0, 0, 0), rotation=(0, 0, 0), name=None, power=None, **options):
    """Build a fixture and return its root Empty."""
    coll = collection(scene)
    if S.BEAM_CONES not in scene:
        set_prop(scene, S.BEAM_CONES, 1.0, min=0.0, soft_max=2.0,
                 description="Master for every visible beam cone. Haze draws real beams, so adding haze lowers this")
    root = bpy.data.objects.new(name or S.TYPE_LABEL[ftype], None)
    coll.objects.link(root)
    root.empty_display_type = 'SPHERE'
    root.empty_display_size = 0.2
    root.location = location
    root.rotation_euler = rotation
    root[S.TYPE] = ftype
    _controls(root)
    set_prop(root, S.POWER, float(S.DEFAULT_POWER[ftype] if power is None else power),
             min=0.0, soft_max=20000.0, subtype='POWER', description="Light output at full intensity")
    BUILDERS[ftype](_Builder(scene, root, coll), **options)
    if ftype == 'STROBE':
        root[S.INTENSITY] = 0.0  # strobes stay dark until an effect hits them
    return root


def parts(root, part=None):
    return [o for o in root.children_recursive if part is None or o.get(S.PART) == part]


def heads(root):
    """Objects effects write to: the pixels of an LED bar, or the root itself."""
    if root.get(S.TYPE) == 'LEDBAR':
        px = parts(root, "pixel")
        px.sort(key=lambda o: o[S.PIXEL])
        return px
    return [root]


def delete(roots):
    objs = set()
    for r in roots:
        objs.add(r)
        objs.update(r.children_recursive)
    lights = {o.data for o in objs if o.type == 'LIGHT'}
    bpy.data.batch_remove(list(objs))
    bpy.data.batch_remove([l for l in lights if l.users == 0])


def set_gobo(root, kind, image=None):
    """Swap the gobo on a spot or wash: beam cone texture plus, for Cycles, the light's node tree."""
    if kind == 'IMAGE' and image is None:
        return
    root[S.GOBO] = kind
    mat = materials.beam(kind, image)
    for c in parts(root, "beam"):
        c.material_slots[0].material = mat
    img = image if kind == 'IMAGE' else gobos.image(kind)
    zr = S.ZOOM_RANGE.get(root[S.TYPE], S.ZOOM_RANGE['SPOT'])
    for lo in parts(root, "light"):
        if lo.data.type == 'SPOT':
            _light_gobo(lo.data, root, img, zr)


def _light_gobo(light, root, img, zoom_range):
    """Cycles projects the gobo through the spot's node tree. EEVEE ignores light nodes."""
    light.use_nodes = True
    nt = light.node_tree
    for n in [n for n in nt.nodes if n.name.startswith("CL ")]:
        nt.nodes.remove(n)
    em = next(n for n in nt.nodes if n.bl_idname == "ShaderNodeEmission")
    for l in list(em.inputs["Strength"].links):
        nt.links.remove(l)
    em.inputs["Strength"].default_value = 1.0
    if img is None:
        return

    def node(idname, name, x, y, **attrs):
        n = nt.nodes.new(idname)
        n.name = n.label = name
        n.location = (x, y)
        for k, v in attrs.items():
            setattr(n, k, v)
        return n

    def math_(op, name, x, y, a=None, b=None):
        n = node("ShaderNodeMath", name, x, y, operation=op)
        for i, v in enumerate((a, b)):
            if isinstance(v, bpy.types.NodeSocket):
                nt.links.new(v, n.inputs[i])
            elif v is not None:
                n.inputs[i].default_value = v
        return n

    tc = node("ShaderNodeTexCoord", "CL Coord", -1100, 0)
    sep = node("ShaderNodeSeparateXYZ", "CL Split", -900, 0)
    nt.links.new(tc.outputs["Normal"], sep.inputs[0])
    # 1 / tan(half beam angle), driven by zoom, so the gobo fills the beam
    k = node("ShaderNodeValue", "CL Gobo Scale", -900, -250)
    a, b = zoom_range
    add_driver(nt, 'nodes["CL Gobo Scale"].outputs[0].default_value',
               "0.5/tan(radians(%s+%s*z)*0.5)" % (num(a), num(b - a)), {"z": (root, _ctl(S.ZOOM))})
    depth = math_('MULTIPLY', "CL Depth", -700, -150, sep.outputs["Z"], -1.0)
    depth = math_('MAXIMUM', "CL Depth Safe", -550, -150, depth.outputs[0], 1e-4)
    uv = node("ShaderNodeCombineXYZ", "CL UV", -100, 0)
    for i, axis in enumerate("XY"):
        d = math_('DIVIDE', "CL %s/Z" % axis, -400, 100 - 160 * i, sep.outputs[axis], depth.outputs[0])
        s = math_('MULTIPLY_ADD', "CL %s Scale" % axis, -250, 100 - 160 * i, d.outputs[0], k.outputs[0])
        s.inputs[2].default_value = 0.5
        nt.links.new(s.outputs[0], uv.inputs[i])
    tex = node("ShaderNodeTexImage", "CL Gobo", 100, 0, image=img, extension='CLIP')
    nt.links.new(uv.outputs[0], tex.inputs["Vector"])
    nt.links.new(tex.outputs["Color"], em.inputs["Strength"])
