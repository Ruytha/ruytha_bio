import bpy
from bpy.props import EnumProperty, FloatProperty, IntProperty, StringProperty
from mathutils import Euler

from . import arrays, build, haze
from . import schema as S

_WASH_LIGHTS = (('SPOT', "Spot", "Spot light with a soft edge"), ('AREA', "Area", "Disk area light"))
_BUILTIN_GOBOS = tuple(g for g in S.GOBOS if g[0] != 'IMAGE')


def _select_only(context, objs):
    for o in context.selected_objects:
        o.select_set(False)
    for o in objs:
        o.select_set(True)
    if objs:
        context.view_layer.objects.active = objs[0]


def _selected_roots(context):
    roots = []
    for o in context.selected_objects:
        r = S.fixture_root(o)
        if r is not None and r not in roots:
            roots.append(r)
    return roots


class _FixtureOptions:
    fixture_type: EnumProperty(name="Type", items=S.FIXTURE_TYPES)
    mount: EnumProperty(name="Mount", items=build.MOUNTS, default='HANG')
    pixels: IntProperty(name="Pixels", default=16, min=1, max=128, description="Pixels per LED bar")
    beams: IntProperty(name="Beams", default=5, min=1, max=32, description="Beams in the laser fan")
    wash_light: EnumProperty(name="Light", items=_WASH_LIGHTS, default='SPOT')
    gobo: EnumProperty(name="Gobo", items=_BUILTIN_GOBOS, default='NONE')

    def build_options(self):
        t = self.fixture_type
        if t == 'LEDBAR':
            return {"pixels": self.pixels}
        if t == 'LASER':
            return {"beams": self.beams}
        if t == 'WASH':
            return {"light_type": self.wash_light}
        if t == 'SPOT':
            return {"gobo": self.gobo}
        return {}

    def draw_options(self, layout):
        t = self.fixture_type
        if t == 'LEDBAR':
            layout.prop(self, "pixels")
        elif t == 'LASER':
            layout.prop(self, "beams")
        elif t == 'WASH':
            layout.prop(self, "wash_light", expand=True)
        elif t == 'SPOT':
            layout.prop(self, "gobo")


class CUELIGHT_OT_add_fixture(_FixtureOptions, bpy.types.Operator):
    bl_idname = "cuelight.add_fixture"
    bl_label = "Add fixture"
    bl_description = "Add a fixture at the 3D cursor"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def description(cls, context, props):
        return dict((k, d) for k, _, d in S.FIXTURE_TYPES).get(props.fixture_type, cls.bl_description)

    def invoke(self, context, event):
        self.mount = context.scene.cuelight.mount
        return self.execute(context)

    def draw(self, context):
        layout = self.layout
        layout.use_property_split = True
        layout.prop(self, "fixture_type")
        layout.prop(self, "mount")
        self.draw_options(layout)

    def execute(self, context):
        root = build.create(context.scene, self.fixture_type,
                            location=context.scene.cursor.location.copy(),
                            rotation=build.MOUNT_ROTATION[self.mount], **self.build_options())
        _select_only(context, [root])
        return {'FINISHED'}


class CUELIGHT_OT_add_array(_FixtureOptions, bpy.types.Operator):
    bl_idname = "cuelight.add_array"
    bl_label = "Add array"
    bl_description = "Add a row, arc, ring or grid of fixtures around the 3D cursor"
    bl_options = {'REGISTER', 'UNDO'}

    layout_type: EnumProperty(name="Layout", items=arrays.LAYOUTS, default='LINE')
    count: IntProperty(name="Count", default=8, min=1, max=256)
    spacing: FloatProperty(name="Spacing", default=1.0, min=0.05, soft_max=10.0, subtype='DISTANCE')
    radius: FloatProperty(name="Radius", default=6.0, min=0.1, soft_max=50.0, subtype='DISTANCE')
    arc: FloatProperty(name="Arc", default=120.0, min=1.0, max=360.0, description="Arc angle in degrees")
    rows: IntProperty(name="Rows", default=2, min=1, max=64)
    name: StringProperty(name="Name", default="", description="Base name; leave empty to use the type")
    make_group: bpy.props.BoolProperty(name="Make group", default=True,
                                       description="Put the new fixtures in a group of the same name")

    def invoke(self, context, event):
        self.mount = context.scene.cuelight.mount
        return context.window_manager.invoke_props_dialog(self, width=320, title="Add array")

    def draw(self, context):
        layout = self.layout
        layout.use_property_split = True
        layout.prop(self, "fixture_type")
        layout.prop(self, "mount")
        self.draw_options(layout)
        layout.separator()
        layout.prop(self, "layout_type")
        layout.prop(self, "count")
        if self.layout_type in {'LINE', 'GRID'}:
            layout.prop(self, "spacing")
        if self.layout_type == 'GRID':
            layout.prop(self, "rows")
        if self.layout_type in {'ARC', 'CIRCLE'}:
            layout.prop(self, "radius")
        if self.layout_type == 'ARC':
            layout.prop(self, "arc")
        layout.prop(self, "name")
        layout.prop(self, "make_group")

    def execute(self, context):
        scene = context.scene
        base = self.name.strip() or S.TYPE_LABEL[self.fixture_type]
        origin = scene.cursor.location.copy()
        mx = build.MOUNT_ROTATION[self.mount][0]
        roots = []
        for i, (offset, yaw) in enumerate(arrays.placements(
                self.layout_type, self.count, self.spacing, self.radius, self.arc, self.rows)):
            roots.append(build.create(scene, self.fixture_type, location=origin + offset,
                                      rotation=Euler((mx, 0.0, yaw)), name="%s %02d" % (base, i + 1),
                                      **self.build_options()))
        _select_only(context, roots)
        if self.make_group:
            from ..groups.ops import new_group
            new_group(scene, base, roots)
        self.report({'INFO'}, "Added %d fixtures" % len(roots))
        return {'FINISHED'}


class CUELIGHT_OT_delete_fixtures(bpy.types.Operator):
    bl_idname = "cuelight.delete_fixtures"
    bl_label = "Delete fixtures"
    bl_description = "Delete the selected fixtures with their lights and parts"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return bool(_selected_roots(context))

    def execute(self, context):
        roots = _selected_roots(context)
        build.delete(roots)
        self.report({'INFO'}, "Deleted %d fixtures" % len(roots))
        return {'FINISHED'}


class CUELIGHT_OT_set_gobo(bpy.types.Operator):
    bl_idname = "cuelight.set_gobo"
    bl_label = "Gobo"
    bl_description = "Set the gobo on the selected spots"
    bl_options = {'REGISTER', 'UNDO'}

    kind: EnumProperty(name="Gobo", items=S.GOBOS)
    filepath: StringProperty(subtype='FILE_PATH', options={'SKIP_SAVE'})
    filter_image: bpy.props.BoolProperty(default=True, options={'HIDDEN', 'SKIP_SAVE'})
    filter_folder: bpy.props.BoolProperty(default=True, options={'HIDDEN', 'SKIP_SAVE'})

    @classmethod
    def poll(cls, context):
        return any(r[S.TYPE] == 'SPOT' for r in _selected_roots(context))

    def invoke(self, context, event):
        if self.kind == 'IMAGE':
            context.window_manager.fileselect_add(self)
            return {'RUNNING_MODAL'}
        return self.execute(context)

    def execute(self, context):
        image = None
        if self.kind == 'IMAGE':
            if not self.filepath:
                return {'CANCELLED'}
            image = bpy.data.images.load(self.filepath, check_existing=True)
            image.colorspace_settings.name = "Non-Color"
        for r in _selected_roots(context):
            if r[S.TYPE] == 'SPOT':
                build.set_gobo(r, self.kind, image)
        return {'FINISHED'}


class CUELIGHT_OT_add_haze(bpy.types.Operator):
    bl_idname = "cuelight.add_haze"
    bl_label = "Add haze"
    bl_description = "Fill the stage with haze so beams show. Fits the box to your fixtures"
    bl_options = {'REGISTER', 'UNDO'}

    density: FloatProperty(name="Density", default=0.015, min=0.0, soft_max=0.2, precision=4)
    margin: FloatProperty(name="Margin", default=4.0, min=0.0, soft_max=20.0, subtype='DISTANCE')

    def execute(self, context):
        haze.add(context.scene, self.density, self.margin)
        return {'FINISHED'}


class CUELIGHT_OT_remove_haze(bpy.types.Operator):
    bl_idname = "cuelight.remove_haze"
    bl_label = "Remove haze"
    bl_description = "Delete the haze box"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return haze.find(context.scene) is not None

    def execute(self, context):
        haze.remove(context.scene)
        return {'FINISHED'}


classes = (
    CUELIGHT_OT_add_fixture,
    CUELIGHT_OT_add_array,
    CUELIGHT_OT_delete_fixtures,
    CUELIGHT_OT_set_gobo,
    CUELIGHT_OT_add_haze,
    CUELIGHT_OT_remove_haze,
)
