"""Built-in gobo patterns, generated with numpy and packed into the .blend."""

import bpy
import numpy as np

SIZE = 256
VERSION = 1


def _grid():
    c = (np.arange(SIZE) + 0.5) / SIZE * 2.0 - 1.0
    return np.meshgrid(c, c)


def _soft(d, w=0.02):
    """Coverage from a signed distance (negative inside)."""
    return np.clip(0.5 - d / w, 0.0, 1.0)


def _dots():
    x, y = _grid()
    out = _soft(np.hypot(x, y) - 0.16)
    for k in range(6):
        a = k * np.pi / 3
        out = np.maximum(out, _soft(np.hypot(x - 0.55 * np.cos(a), y - 0.55 * np.sin(a)) - 0.16))
    return out


def _spokes():
    x, y = _grid()
    a = np.arctan2(y, x)
    r = np.hypot(x, y)
    spoke = _soft(-(np.cos(a * 8) - 0.55), 0.08)
    return spoke * _soft(0.12 - r, 0.03)  # open hub in the middle


def _ring():
    x, y = _grid()
    r = np.hypot(x, y)
    return np.maximum(_soft(np.abs(r - 0.7) - 0.09), _soft(r - 0.14))


def _breakup():
    rng = np.random.default_rng(7)
    x, y = _grid()
    field = np.zeros_like(x)
    for _ in range(26):
        cx, cy = rng.uniform(-0.9, 0.9, 2)
        s = rng.uniform(0.08, 0.22)
        field += np.exp(-((x - cx) ** 2 + (y - cy) ** 2) / (2 * s * s))
    return _soft(0.9 - field, 0.15)


PATTERNS = {"DOTS": _dots, "SPOKES": _spokes, "RING": _ring, "BREAKUP": _breakup}


def _aperture():
    x, y = _grid()
    return _soft(np.hypot(x, y) - 0.98, 0.02)


def _store(name, values, height):
    """Pack a grey float array (height x SIZE) as a Non-Color image."""
    rgba = np.empty((height, SIZE, 4), dtype=np.float32)
    rgba[..., 0] = rgba[..., 1] = rgba[..., 2] = values
    rgba[..., 3] = 1.0
    img = bpy.data.images.new(name, SIZE, height, alpha=False)
    img.colorspace_settings.name = "Non-Color"
    img.pixels.foreach_set(rgba.ravel())
    img.pack()
    img["cl_gobo_version"] = VERSION
    return img


def _cached(name):
    img = bpy.data.images.get(name)
    if img is not None and img.get("cl_gobo_version") == VERSION:
        return img, True
    if img is not None:
        bpy.data.images.remove(img)
    return None, False


def image(kind):
    """The packed image for a built-in gobo, or None for an open beam."""
    fn = PATTERNS.get(kind)
    if fn is None:
        return None
    name = "CL Gobo · " + kind.title()
    img, ok = _cached(name)
    if ok:
        return img
    # Hard circular aperture, like the gate of a real fixture
    return _store(name, fn() * _aperture(), SIZE)


def lut(source):
    """How much of each beam column the gobo lets through, seen side-on.

    A beam cone is a surface, so it only ever sees the rim of the gobo. This
    1D table sums the gobo along the line of sight and divides by the open
    beam, so the cone can show sub-beams as streaks. 1.0 means open.
    """
    name = "CL Gobo LUT · " + source.name
    img, ok = _cached(name)
    if ok:
        return img
    w, h = source.size
    px = np.empty(w * h * 4, dtype=np.float32)
    source.pixels.foreach_get(px)
    grey = px.reshape(h, w, 4)[..., :3].mean(axis=2)
    yi = (np.arange(SIZE) * h // SIZE)[:, None]
    xi = (np.arange(SIZE) * w // SIZE)[None, :]
    open_ = _aperture()
    g = grey[yi, xi] * open_
    cols = g.sum(axis=0) / np.maximum(open_.sum(axis=0), 1e-6)
    return _store(name, np.tile(np.clip(cols, 0.0, 1.0), (4, 1)), 4)
