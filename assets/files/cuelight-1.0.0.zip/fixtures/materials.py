"""Shared materials. Every emissive part reads its own cl_emit / cl_gain
through an Object Attribute node, so one material serves every fixture and
works the same in EEVEE and Cycles.
"""

import bpy

from . import schema as S
from . import gobos

MAT_VERSION = 2


class _Graph:
    """Small helper to lay out node trees left to right."""

    def __init__(self, tree):
        self.tree = tree
        self.nodes = tree.nodes
        self.links = tree.links
        self._x = 0

    def node(self, idname, x=None, y=0, **attrs):
        n = self.nodes.new(idname)
        n.location = (self._x if x is None else x, y)
        self._x += 200
        for k, v in attrs.items():
            setattr(n, k, v)
        return n

    def math(self, op, a, b=None, y=0, clamp=False):
        n = self.node("ShaderNodeMath", y=y, operation=op, use_clamp=clamp)
        self._in(n.inputs[0], a)
        if b is not None:
            self._in(n.inputs[1], b)
        return n.outputs[0]

    def _in(self, socket, value):
        if isinstance(value, bpy.types.NodeSocket):
            self.links.new(value, socket)
        else:
            socket.default_value = value

    def link(self, a, b):
        self.links.new(a, b)

    def attr(self, name, y=0):
        return self.node("ShaderNodeAttribute", y=y, attribute_type='OBJECT', attribute_name=name)


def _material(name):
    mat = bpy.data.materials.get(name)
    if mat is not None and mat.get("cl_mat_version") == MAT_VERSION:
        return mat, False
    if mat is None:
        mat = bpy.data.materials.new(name)
    mat.use_nodes = True
    mat.node_tree.nodes.clear()
    mat["cl_mat_version"] = MAT_VERSION
    return mat, True


def housing():
    mat, build = _material("CL Housing")
    if build:
        g = _Graph(mat.node_tree)
        bsdf = g.node("ShaderNodeBsdfPrincipled")
        bsdf.inputs["Base Color"].default_value = (0.012, 0.012, 0.012, 1.0)
        bsdf.inputs["Metallic"].default_value = 0.5
        bsdf.inputs["Roughness"].default_value = 0.45
        out = g.node("ShaderNodeOutputMaterial")
        g.link(bsdf.outputs[0], out.inputs["Surface"])
        mat.diffuse_color = (0.02, 0.02, 0.02, 1.0)
    return mat


def emit():
    """Lenses, LED pixels, laser beams, strobe faces: colour = cl_emit, strength = cl_gain."""
    mat, build = _material("CL Emit")
    if build:
        g = _Graph(mat.node_tree)
        col = g.attr(S.EMIT, y=80)
        gain = g.attr(S.GAIN, y=-120)
        em = g.node("ShaderNodeEmission")
        g.link(col.outputs["Color"], em.inputs["Color"])
        g.link(gain.outputs["Fac"], em.inputs["Strength"])
        out = g.node("ShaderNodeOutputMaterial")
        g.link(em.outputs[0], out.inputs["Surface"])
        mat.diffuse_color = (0.9, 0.9, 0.9, 1.0)
    return mat


def beam(gobo='NONE', image=None):
    """Additive beam cone. Fades along its length and towards its silhouette.

    With a gobo, the pattern is projected through the cone so EEVEE (which
    ignores light node trees) still shows it in the beam.
    """
    key = gobo if gobo != 'IMAGE' else "IMAGE " + (image.name if image else "")
    name = "CL Beam" if gobo == 'NONE' else "CL Beam · " + key.title()
    mat, build = _material(name)
    if not build:
        return mat
    g = _Graph(mat.node_tree)

    col = g.attr(S.EMIT, y=200)
    gain = g.attr(S.GAIN, y=0)
    tc = g.node("ShaderNodeTexCoord", x=-600, y=-300)
    sep = g.node("ShaderNodeSeparateXYZ", x=-400, y=-300)
    g.link(tc.outputs["Object"], sep.inputs[0])

    # t: 0 at the lens, 1 at the far end
    g._x = -200
    t = g.math('MULTIPLY', sep.outputs["Z"], -1.0, y=-300, clamp=True)
    fade = g.math('POWER', g.math('SUBTRACT', 1.0, t, y=-300), 1.6, y=-300)

    lw = g.node("ShaderNodeLayerWeight", x=0, y=-520)
    lw.inputs["Blend"].default_value = 0.5
    edge = g.math('POWER', g.math('SUBTRACT', 1.0, lw.outputs["Facing"], y=-520), 2.5, y=-520)

    strength = g.math('MULTIPLY', gain.outputs["Fac"], fade, y=0)
    strength = g.math('MULTIPLY', strength, edge, y=0)

    img = image if gobo == 'IMAGE' else gobos.image(gobo)
    if img is not None:
        # Signed distance of this point from the beam axis, across the line of
        # sight, divided by the beam radius here: -1..1 across the visible beam.
        g._x = -600
        geo = g.node("ShaderNodeNewGeometry", y=-800)
        vt = g.node("ShaderNodeVectorTransform", y=-800, vector_type='VECTOR',
                    convert_from='WORLD', convert_to='OBJECT')
        g.link(geo.outputs["Incoming"], vt.inputs[0])
        si = g.node("ShaderNodeSeparateXYZ", y=-800)
        g.link(vt.outputs[0], si.inputs[0])
        flat = g.node("ShaderNodeCombineXYZ", y=-800)
        g.link(si.outputs["X"], flat.inputs["X"])
        g.link(si.outputs["Y"], flat.inputs["Y"])
        nrm = g.node("ShaderNodeVectorMath", y=-800, operation='NORMALIZE')
        g.link(flat.outputs[0], nrm.inputs[0])
        sn = g.node("ShaderNodeSeparateXYZ", y=-800)
        g.link(nrm.outputs["Vector"], sn.inputs[0])
        g._x = -600
        cross = g.math('SUBTRACT', g.math('MULTIPLY', sep.outputs["X"], sn.outputs["Y"], y=-1000),
                       g.math('MULTIPLY', sep.outputs["Y"], sn.outputs["X"], y=-1100), y=-1000)
        u = g.math('DIVIDE', cross, g.math('MAXIMUM', t, 0.02, y=-1200), y=-1000)
        u = g.math('MULTIPLY_ADD', u, 0.5, y=-1000)
        u.node.inputs[2].default_value = 0.5
        uv = g.node("ShaderNodeCombineXYZ", y=-1000)
        g.link(u, uv.inputs["X"])
        uv.inputs["Y"].default_value = 0.5
        tex = g.node("ShaderNodeTexImage", y=-1000, image=gobos.lut(img), extension='EXTEND',
                     interpolation='Linear')
        g.link(uv.outputs[0], tex.inputs["Vector"])
        strength = g.math('MULTIPLY', strength, tex.outputs["Color"], y=-600)

    g._x = 1200
    em = g.node("ShaderNodeEmission", y=100)
    g.link(col.outputs["Color"], em.inputs["Color"])
    g.link(strength, em.inputs["Strength"])
    tr = g.node("ShaderNodeBsdfTransparent", x=1200, y=-100)
    add = g.node("ShaderNodeAddShader")
    g.link(em.outputs[0], add.inputs[0])
    g.link(tr.outputs[0], add.inputs[1])
    out = g.node("ShaderNodeOutputMaterial")
    g.link(add.outputs[0], out.inputs["Surface"])

    mat.surface_render_method = 'BLENDED'
    mat.use_transparency_overlap = True
    mat.use_backface_culling = False
    mat.diffuse_color = (1.0, 1.0, 1.0, 0.08)
    return mat


def haze(obj):
    """Principled Volume whose density is driven by the haze object's cl_density."""
    from ..utils.idprops import add_driver

    mat = bpy.data.materials.get("CL Haze") or bpy.data.materials.new("CL Haze")
    mat.use_nodes = True
    nt = mat.node_tree
    nt.nodes.clear()
    g = _Graph(nt)
    vol = g.node("ShaderNodeVolumePrincipled")
    vol.inputs["Color"].default_value = (0.9, 0.9, 0.9, 1.0)
    vol.inputs["Anisotropy"].default_value = 0.35
    out = g.node("ShaderNodeOutputMaterial")
    g.link(vol.outputs[0], out.inputs["Volume"])
    vol.name = "Haze"
    add_driver(nt, 'nodes["Haze"].inputs["Density"].default_value', "d",
               {"d": (obj, '["cl_density"]')})
    mat["cl_mat_version"] = MAT_VERSION
    return mat
