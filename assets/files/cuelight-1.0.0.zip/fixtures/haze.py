"""Atmosphere: a volume box sized to the rig, so beams read in both engines."""

import bpy
from mathutils import Vector

from . import materials, meshes
from . import schema as S
from .build import collection
from ..utils.idprops import set_prop

HAZE = "cl_haze"
DENSITY = "cl_density"


def find(scene):
    return next((o for o in scene.objects if o.get(HAZE)), None)


def _bounds(scene, margin):
    bpy.context.view_layer.update()  # fresh matrix_world for just-created fixtures
    pts = [o.matrix_world.translation.copy() for o in S.fixtures_in(scene)]
    if not pts:
        c = scene.cursor.location
        return Vector((c.x - 15, c.y - 15, 0.0)), Vector((c.x + 15, c.y + 15, 12.0))
    lo = Vector((min(p.x for p in pts), min(p.y for p in pts), min(p.z for p in pts)))
    hi = Vector((max(p.x for p in pts), max(p.y for p in pts), max(p.z for p in pts)))
    lo -= Vector((margin, margin, margin))
    hi += Vector((margin, margin, 1.0))
    lo.z = min(lo.z, 0.0)
    return lo, hi


def tune_eevee(scene, depth):
    """Volumetric settings that keep beams sharp without crawling noise."""
    e = scene.eevee
    e.volumetric_tile_size = '4'
    e.volumetric_samples = 96
    e.volumetric_start = 0.1
    e.volumetric_end = max(depth, 20.0)
    e.volumetric_sample_distribution = 0.8
    e.use_volumetric_shadows = True
    e.volumetric_shadow_samples = 16


def add(scene, density=0.015, margin=4.0, cones=0.25):
    """Create (or refit) the haze box around every fixture in the scene."""
    obj = find(scene)
    if obj is None:
        obj = bpy.data.objects.new("Haze", meshes.haze_box())
        collection(scene).objects.link(obj)
        obj[HAZE] = 1
        obj.display_type = 'BOUNDS'
        obj.hide_select = True
        set_prop(obj, DENSITY, float(density), min=0.0, soft_max=0.2, precision=4,
                 description="Haze density")
        mat = materials.haze(obj)
        if not obj.data.materials:
            obj.data.materials.append(mat)
        obj.material_slots[0].link = 'OBJECT'
        obj.material_slots[0].material = mat
        # Haze draws the real beams now; keep a little cone for punch
        if S.BEAM_CONES in scene:
            scene[S.BEAM_CONES] = cones
    else:
        obj[DENSITY] = float(density)
    lo, hi = _bounds(scene, margin)
    obj.location = (lo + hi) / 2
    obj.scale = (hi - lo) / 2
    tune_eevee(scene, (hi - lo).length)
    return obj


def remove(scene):
    obj = find(scene)
    if obj is None:
        return False
    mats = [s.material for s in obj.material_slots if s.material]
    bpy.data.objects.remove(obj)
    if S.BEAM_CONES in scene:
        scene[S.BEAM_CONES] = 1.0
    for m in mats:
        if m.users == 0:
            bpy.data.materials.remove(m)
    return True
