"""Group membership and ordering, cached between frames.

A group lists fixture roots. Expanded, LED bars contribute one head per pixel.
The direction turns member order into the index effects see.
"""

import numpy as np

from ..fixtures import build
from ..fixtures import schema as S

DIRECTIONS = (
    ('LTR', "Left to right", "In member order"),
    ('RTL', "Right to left", "Reverse member order"),
    ('CENTER_OUT', "Centre out", "From the middle to both ends; mirrored heads move together"),
    ('OUTSIDE_IN', "Outside in", "From both ends to the middle; mirrored heads move together"),
    ('RANDOM', "Random", "Shuffled, using the group's seed"),
)

# (scene pointer, group name) -> (revision, object count, heads, base order)
_cache = {}


def clear_cache():
    _cache.clear()


def bump(scene):
    """Mark group data as changed so caches rebuild."""
    scene.cuelight.revision += 1


def select(view_layer, objs, extend=False):
    """Select fixtures in the viewport; the first becomes active."""
    view_layer.update()  # fixtures made this step aren't in the view layer until it syncs
    objs = [o for o in objs if o is not None and o.name in view_layer.objects]
    if not extend:
        for o in list(view_layer.objects.selected):
            o.select_set(False)
    for o in objs:
        o.select_set(True)
    if objs:
        view_layer.objects.active = objs[0]
    return objs


def find(settings, name):
    return settings.groups.get(name) if name else None


def resolve_heads(group):
    """Heads of a group in member order. Missing objects are skipped."""
    heads = []
    for m in group.members:
        obj = m.obj
        if obj is None or S.TYPE not in obj:
            continue
        if group.expand_pixels:
            heads.extend(build.heads(obj))
        else:
            heads.append(obj)
    return heads


def heads(scene, group):
    """Cached head list for a group."""
    import bpy
    key = (scene.as_pointer(), group.name)
    stamp = (scene.cuelight.revision, len(bpy.data.objects))
    hit = _cache.get(key)
    if hit is not None and hit[0] == stamp:
        return hit[1]
    hs = resolve_heads(group)
    _cache[key] = (stamp, hs)
    return hs


def index_map(count, direction, reverse=False, seed=0):
    """(idx float array, n distinct positions) for count heads."""
    if count == 0:
        return np.zeros(0), 0
    i = np.arange(count, dtype=float)
    if reverse:
        i = i[::-1].copy()
    if direction == 'RTL':
        return (count - 1) - i, count
    if direction in {'CENTER_OUT', 'OUTSIDE_IN'}:
        c = (count - 1) / 2.0
        idx = np.abs(i - c) - (c % 1.0)  # 0 at the middle head(s)
        n = int(np.floor(c)) + 1
        if direction == 'OUTSIDE_IN':
            idx = (n - 1) - idx
        return idx, n
    if direction == 'RANDOM':
        perm = np.random.default_rng(seed).permutation(count).astype(float)
        return perm[i.astype(int)], count
    return i, count
