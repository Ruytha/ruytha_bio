import math

import bpy
from bpy.props import EnumProperty, IntProperty, StringProperty

from ..fixtures import schema as S
from . import core


def _settings(context):
    return context.scene.cuelight


def _active(context):
    s = _settings(context)
    return s.groups[s.active_group] if 0 <= s.active_group < len(s.groups) else None


def _selected_roots(context):
    out = []
    for o in context.selected_objects:
        r = S.fixture_root(o)
        if r is not None and r not in out:
            out.append(r)
    return out


def _x_order(objs):
    return sorted(objs, key=lambda o: (round(o.matrix_world.translation.x, 4), o.matrix_world.translation.y, o.name))


def unique_name(settings, base):
    names = {g.name for g in settings.groups}
    if base not in names:
        return base
    i = 2
    while "%s %d" % (base, i) in names:
        i += 1
    return "%s %d" % (base, i)


def new_group(scene, name, objs):
    """Create a group of fixture roots, in the given order."""
    s = scene.cuelight
    g = s.groups.add()
    g.name = unique_name(s, name)
    for o in objs:
        g.members.add().obj = o
    s.active_group = len(s.groups) - 1
    core.bump(scene)
    return g


class CUELIGHT_OT_group_add(bpy.types.Operator):
    bl_idname = "cuelight.group_add"
    bl_label = "New group"
    bl_description = "Make a group from the selected fixtures, ordered left to right"
    bl_options = {'REGISTER', 'UNDO'}

    name: StringProperty(name="Name", default="Group")

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self, title="New group")

    def execute(self, context):
        new_group(context.scene, self.name, _x_order(_selected_roots(context)))
        return {'FINISHED'}


class CUELIGHT_OT_group_remove(bpy.types.Operator):
    bl_idname = "cuelight.group_remove"
    bl_label = "Delete group"
    bl_description = "Delete the group. Its fixtures stay; effects on it go quiet"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return _active(context) is not None

    def execute(self, context):
        s = _settings(context)
        s.groups.remove(s.active_group)
        s.active_group = min(s.active_group, len(s.groups) - 1)
        core.bump(context.scene)
        return {'FINISHED'}


class CUELIGHT_OT_group_assign(bpy.types.Operator):
    bl_idname = "cuelight.group_assign"
    bl_label = "Add selected"
    bl_description = "Add the selected fixtures to the end of the group"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return _active(context) is not None and bool(_selected_roots(context))

    def execute(self, context):
        g = _active(context)
        have = {m.obj for m in g.members}
        for o in _x_order(_selected_roots(context)):
            if o not in have:
                g.members.add().obj = o
        core.bump(context.scene)
        return {'FINISHED'}


class CUELIGHT_OT_group_unassign(bpy.types.Operator):
    bl_idname = "cuelight.group_unassign"
    bl_label = "Remove selected"
    bl_description = "Take the selected fixtures out of the group"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return _active(context) is not None

    def execute(self, context):
        g = _active(context)
        sel = set(_selected_roots(context))
        for i in reversed(range(len(g.members))):
            if g.members[i].obj is None or g.members[i].obj in sel:
                g.members.remove(i)
        core.bump(context.scene)
        return {'FINISHED'}


class CUELIGHT_OT_group_select(bpy.types.Operator):
    bl_idname = "cuelight.group_select"
    bl_label = "Select all"
    bl_description = "Select every fixture in the group. Shift-click to add to the selection"
    bl_options = {'REGISTER', 'UNDO'}

    extend: bpy.props.BoolProperty(name="Extend", options={'SKIP_SAVE'})

    @classmethod
    def poll(cls, context):
        return _active(context) is not None

    def invoke(self, context, event):
        self.extend = event.shift
        return self.execute(context)

    def execute(self, context):
        core.select(context.view_layer, [m.obj for m in _active(context).members], self.extend)
        return {'FINISHED'}


class CUELIGHT_OT_member_select(bpy.types.Operator):
    bl_idname = "cuelight.member_select"
    bl_label = "Select one"
    bl_description = "Select only this fixture"
    bl_options = {'REGISTER', 'UNDO'}

    index: IntProperty(name="Member", default=-1, description="Member to select; -1 is the highlighted one")

    @classmethod
    def poll(cls, context):
        g = _active(context)
        return g is not None and len(g.members) > 0

    def execute(self, context):
        g = _active(context)
        i = g.active_member if self.index < 0 else self.index
        if not 0 <= i < len(g.members):
            return {'CANCELLED'}
        core.select(context.view_layer, [g.members[i].obj])
        return {'FINISHED'}


class CUELIGHT_OT_group_sort(bpy.types.Operator):
    bl_idname = "cuelight.group_sort"
    bl_label = "Sort"
    bl_description = "Reorder the group's members"
    bl_options = {'REGISTER', 'UNDO'}

    by: EnumProperty(name="By", items=(
        ('X', "Left to right", "By X position"),
        ('Y', "Front to back", "By Y position"),
        ('Z', "Low to high", "By height"),
        ('ANGLE', "Around the cursor", "Clockwise around the 3D cursor, for rings and arcs"),
        ('NAME', "Name", "Alphabetically"),
    ))

    @classmethod
    def poll(cls, context):
        return _active(context) is not None

    def execute(self, context):
        g = _active(context)
        c = context.scene.cursor.location
        objs = [m.obj for m in g.members if m.obj]

        def key(o):
            p = o.matrix_world.translation
            if self.by == 'X':
                return (p.x, p.y)
            if self.by == 'Y':
                return (p.y, p.x)
            if self.by == 'Z':
                return (p.z, p.x)
            if self.by == 'ANGLE':
                return (-math.atan2(p.x - c.x, p.y - c.y) % (2 * math.pi), 0)
            return (o.name, 0)
        objs.sort(key=key)
        g.members.clear()
        for o in objs:
            g.members.add().obj = o
        core.bump(context.scene)
        return {'FINISHED'}


class CUELIGHT_OT_member_move(bpy.types.Operator):
    bl_idname = "cuelight.member_move"
    bl_label = "Move member"
    bl_description = "Move the fixture up or down in the group order"
    bl_options = {'REGISTER', 'UNDO'}

    direction: EnumProperty(items=(('UP', "Up", ""), ('DOWN', "Down", "")))

    @classmethod
    def poll(cls, context):
        g = _active(context)
        return g is not None and len(g.members) > 1

    def execute(self, context):
        g = _active(context)
        i = g.active_member
        j = i - 1 if self.direction == 'UP' else i + 1
        if 0 <= j < len(g.members):
            g.members.move(i, j)
            g.active_member = j
            core.bump(context.scene)
        return {'FINISHED'}


classes = (
    CUELIGHT_OT_group_add,
    CUELIGHT_OT_group_remove,
    CUELIGHT_OT_group_assign,
    CUELIGHT_OT_group_unassign,
    CUELIGHT_OT_group_select,
    CUELIGHT_OT_member_select,
    CUELIGHT_OT_group_sort,
    CUELIGHT_OT_member_move,
)
