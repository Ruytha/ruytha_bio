import os
import tomllib

import bpy

# "cuelight" when run from source, "bl_ext.<repo>.cuelight" when installed.
PACKAGE = __package__.rsplit(".", 1)[0]
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

WEBSITE = "https://ruytha.dev/studios"
CONTACT = "ruytham4a@gmail.com"


def _read_version():
    try:
        with open(os.path.join(ROOT, "blender_manifest.toml"), "rb") as f:
            return tomllib.load(f).get("version", "0.0.0")
    except OSError:
        return "0.0.0"


VERSION = _read_version()


def eevee_engine_id():
    """'BLENDER_EEVEE_NEXT' in 4.2-4.5, 'BLENDER_EEVEE' from 5.0."""
    items = bpy.types.RenderSettings.bl_rna.properties["engine"].enum_items
    return "BLENDER_EEVEE_NEXT" if "BLENDER_EEVEE_NEXT" in items else "BLENDER_EEVEE"
