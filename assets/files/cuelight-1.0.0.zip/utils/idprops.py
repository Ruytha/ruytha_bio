def set_prop(id_, key, value, **ui):
    """Create or overwrite an ID property, with optional UI data (min, max, subtype...)."""
    id_[key] = value
    if ui:
        id_.id_properties_ui(key).update(**ui)
    return value


def add_driver(id_, path, expression, variables, index=-1):
    """Add a scripted driver.

    variables: {name: (target_id, data_path)}. Expressions are kept to Blender's
    "simple expression" subset so they evaluate without Python (auto-run off,
    render farms, no add-on installed).
    """
    fc = id_.driver_add(path, index) if index >= 0 else id_.driver_add(path)
    for mod in list(fc.modifiers):
        fc.modifiers.remove(mod)
    drv = fc.driver
    drv.type = 'SCRIPTED'
    for v in list(drv.variables):
        drv.variables.remove(v)
    for name, (target, data_path) in variables.items():
        v = drv.variables.new()
        v.name = name
        v.type = 'SINGLE_PROP'
        t = v.targets[0]
        t.id_type = target.id_type if hasattr(target, "id_type") else 'OBJECT'
        t.id = target
        t.data_path = data_path
    drv.expression = expression
    return fc


def num(x):
    """Format a float constant for a driver expression."""
    return repr(float(x))
