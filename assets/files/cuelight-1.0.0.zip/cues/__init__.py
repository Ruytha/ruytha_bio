import bpy


def register():
    from . import ops
    for c in ops.classes:
        bpy.utils.register_class(c)


def unregister():
    from . import ops
    for c in reversed(ops.classes):
        bpy.utils.unregister_class(c)
