"""Cues: named points in the song, each listing the effect layers that play
from there until the next cue.

With cues on, a layer plays when it's enabled, inside its own frame range, and
in the current cue. A cue's fade crossfades from the previous cue: layers
leaving fade out while layers arriving fade in; a layer in both carries on.
"""

from ..engine import timing

MARK = "▸"  # ▸ starts every cue marker Cuelight owns


def frame_of_beat(scene, beat):
    s = scene.cuelight
    return int(round(s.beat_offset + beat * timing.frames_per_beat(scene, s)))


def beat_of_frame(scene, frame):
    return timing.beats_at(scene, scene.cuelight, frame)


def ordered(settings):
    """Cues sorted by frame."""
    return sorted(settings.cues, key=lambda c: c.frame)


def current_index(cues, frame):
    i = -1
    for k, c in enumerate(cues):
        if c.frame <= frame:
            i = k
        else:
            break
    return i


def current(scene, frame=None):
    s = scene.cuelight
    frame = scene.frame_current if frame is None else frame
    cues = ordered(s)
    i = current_index(cues, frame)
    return cues[i] if i >= 0 else None


def gate(scene, frame):
    """{effect uid: weight 0..1} for this frame, or None when cues are off."""
    s = scene.cuelight
    if not s.use_cues or len(s.cues) == 0:
        return None
    cues = ordered(s)
    i = current_index(cues, frame)
    if i < 0:
        return {}
    cue = cues[i]
    fade = cue.fade * timing.frames_per_beat(scene, s)
    up = 1.0 if fade <= 0 else max(0.0, min(1.0, (frame - cue.frame) / fade))
    out = {}
    for r in cue.effects:
        out[r.uid] = out.get(r.uid, 0.0) + up
    if up < 1.0 and i > 0:
        for r in cues[i - 1].effects:
            out[r.uid] = out.get(r.uid, 0.0) + (1.0 - up)
    return {k: min(v, 1.0) for k, v in out.items()}


def contains(cue, uid):
    return any(r.uid == uid for r in cue.effects)


def set_member(cue, uid, member):
    have = [i for i, r in enumerate(cue.effects) if r.uid == uid]
    if member and not have:
        cue.effects.add().uid = uid
    elif not member:
        for i in reversed(have):
            cue.effects.remove(i)


def playing_uids(scene, frame):
    """Effects that would play at this frame, ignoring cues."""
    s = scene.cuelight
    return [e.uid for e in s.effects if e.enabled and e.frame_start <= frame <= e.frame_end]


def sync_markers(scene):
    """One timeline marker per cue, so cues read on the timeline."""
    for m in [m for m in scene.timeline_markers if m.name.startswith(MARK)]:
        scene.timeline_markers.remove(m)
    s = scene.cuelight
    if not s.cue_markers:
        return
    for c in s.cues:
        scene.timeline_markers.new("%s%s" % (MARK, c.name), frame=c.frame)


def relock(scene):
    """After the beat grid moves, beat-locked cues follow it."""
    for c in scene.cuelight.cues:
        if c.lock_to_beat:
            f = frame_of_beat(scene, c.beat)
            if c.frame != f:
                c["frame"] = f  # skip the update callback: the beat is already right
    sync_markers(scene)
