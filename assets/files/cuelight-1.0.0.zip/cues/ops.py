import bpy
from bpy.props import EnumProperty, IntProperty, StringProperty

from ..engine import live, timing
from . import core


def _settings(context):
    return context.scene.cuelight


def active_cue(context):
    s = _settings(context)
    return s.cues[s.active_cue] if 0 <= s.active_cue < len(s.cues) else None


def _snapped_beat(scene, frame):
    s = scene.cuelight
    beat = core.beat_of_frame(scene, frame)
    if s.cue_snap == 'BEAT':
        return float(round(beat))
    if s.cue_snap == 'BAR':
        return float(round(beat / s.beats_per_bar) * s.beats_per_bar)
    return beat


def add_cue(scene, name, frame=None, uids=None, fade=0.0, beat=None):
    """Add a cue. Its layers default to whatever plays at that frame right now."""
    s = scene.cuelight
    if uids is None:
        f = scene.frame_current if frame is None else frame
        cur = core.current(scene, f) if s.use_cues else None
        uids = [r.uid for r in cur.effects] if cur is not None else core.playing_uids(scene, f)
    c = s.cues.add()
    c["name"] = name
    if beat is not None:
        c.beat = beat
    elif frame is None:
        c.beat = _snapped_beat(scene, scene.frame_current)
    else:
        c.lock_to_beat = False
        c.frame = frame
    c.fade = fade
    for u in uids:
        c.effects.add().uid = u
    s.active_cue = len(s.cues) - 1
    core.sync_markers(scene)
    live.refresh(scene)
    return c


class CUELIGHT_OT_cue_add(bpy.types.Operator):
    bl_idname = "cuelight.cue_add"
    bl_label = "Add cue"
    bl_description = "Add a cue at the playhead holding the layers playing now"
    bl_options = {'REGISTER', 'UNDO'}

    name: StringProperty(name="Name", default="Cue")

    def invoke(self, context, event):
        self.name = "Cue %d" % (len(_settings(context).cues) + 1)
        return context.window_manager.invoke_props_dialog(self, title="New cue")

    def execute(self, context):
        s = _settings(context)
        add_cue(context.scene, self.name)
        if not s.use_cues:
            s.use_cues = True
        return {'FINISHED'}


class CUELIGHT_OT_cue_remove(bpy.types.Operator):
    bl_idname = "cuelight.cue_remove"
    bl_label = "Delete cue"
    bl_description = "Delete the selected cue"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return active_cue(context) is not None

    def execute(self, context):
        s = _settings(context)
        s.cues.remove(s.active_cue)
        s.active_cue = max(0, min(s.active_cue, len(s.cues) - 1))
        core.sync_markers(context.scene)
        live.refresh(context.scene)
        return {'FINISHED'}


class CUELIGHT_OT_cue_jump(bpy.types.Operator):
    bl_idname = "cuelight.cue_jump"
    bl_label = "Go to cue"
    bl_description = "Move the playhead to this cue"
    bl_options = {'REGISTER', 'UNDO'}

    index: IntProperty(default=-1)

    def execute(self, context):
        s = _settings(context)
        i = s.active_cue if self.index < 0 else self.index
        if not 0 <= i < len(s.cues):
            return {'CANCELLED'}
        s.active_cue = i
        context.scene.frame_set(s.cues[i].frame)
        return {'FINISHED'}


class CUELIGHT_OT_cue_step(bpy.types.Operator):
    bl_idname = "cuelight.cue_step"
    bl_label = "Next cue"
    bl_description = "Jump to the next or previous cue"
    bl_options = {'REGISTER', 'UNDO'}

    direction: EnumProperty(items=(('NEXT', "Next", ""), ('PREV', "Previous", "")))

    @classmethod
    def poll(cls, context):
        return len(_settings(context).cues) > 0

    def execute(self, context):
        scene = context.scene
        s = _settings(context)
        f = scene.frame_current
        cues = core.ordered(s)
        if self.direction == 'NEXT':
            target = next((c for c in cues if c.frame > f), None)
        else:
            before = [c for c in cues if c.frame < f]
            target = before[-1] if before else None
        if target is None:
            return {'CANCELLED'}
        s.active_cue = list(s.cues).index(target)
        scene.frame_set(target.frame)
        return {'FINISHED'}


class CUELIGHT_OT_cue_toggle_effect(bpy.types.Operator):
    bl_idname = "cuelight.cue_toggle_effect"
    bl_label = "In cue"
    bl_description = "Play this layer in the selected cue, or not"
    bl_options = {'REGISTER', 'UNDO', 'INTERNAL'}

    uid: StringProperty()

    def execute(self, context):
        c = active_cue(context)
        if c is None:
            return {'CANCELLED'}
        core.set_member(c, self.uid, not core.contains(c, self.uid))
        live.refresh(context.scene)
        return {'FINISHED'}


class CUELIGHT_OT_cue_capture(bpy.types.Operator):
    bl_idname = "cuelight.cue_capture"
    bl_label = "Fill from layers"
    bl_description = "Set the cue to every enabled layer whose time range covers the cue"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return active_cue(context) is not None

    def execute(self, context):
        c = active_cue(context)
        c.effects.clear()
        for u in core.playing_uids(context.scene, c.frame):
            c.effects.add().uid = u
        live.refresh(context.scene)
        return {'FINISHED'}


class CUELIGHT_OT_cue_here(bpy.types.Operator):
    bl_idname = "cuelight.cue_here"
    bl_label = "Move here"
    bl_description = "Move the selected cue to the playhead (snapped)"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return active_cue(context) is not None

    def execute(self, context):
        c = active_cue(context)
        if c.lock_to_beat:
            c.beat = _snapped_beat(context.scene, context.scene.frame_current)
        else:
            c.frame = context.scene.frame_current
        return {'FINISHED'}


def format_position(scene, cue):
    s = scene.cuelight
    if cue.lock_to_beat:
        b = int(round(cue.beat))
        bar, beat = divmod(b, s.beats_per_bar)
        return "%d.%d" % (bar + 1, beat + 1)
    return "f%d" % cue.frame


classes = (
    CUELIGHT_OT_cue_add,
    CUELIGHT_OT_cue_remove,
    CUELIGHT_OT_cue_jump,
    CUELIGHT_OT_cue_step,
    CUELIGHT_OT_cue_toggle_effect,
    CUELIGHT_OT_cue_capture,
    CUELIGHT_OT_cue_here,
)
