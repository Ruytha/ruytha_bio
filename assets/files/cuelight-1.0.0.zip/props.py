"""Scene data: scene.cuelight. Saved with the .blend."""

import bpy
from bpy.props import (BoolProperty, CollectionProperty, EnumProperty, FloatProperty,
                       FloatVectorProperty, IntProperty, PointerProperty, StringProperty)

from .effects import params, registry
from .fixtures import schema as S
from .fixtures.build import MOUNTS
from .audio.analysis import BANDS
from .groups.core import DIRECTIONS

BLENDS = (
    ('REPLACE', "Replace", "Fade from what's below towards this layer by its opacity"),
    ('ADD', "Add", "Add this layer on top"),
    ('MULTIPLY', "Multiply", "Scale what's below; good for masks and dimmers"),
    ('MAX', "Max (HTP)", "Highest takes precedence"),
)
SPEED_UNITS = (
    ('BEATS', "Beats", "Beats per cycle, locked to the song's BPM and offset"),
    ('SECONDS', "Seconds", "Seconds per cycle"),
    ('HZ', "Hz", "Cycles per second"),
)
TIME_UNITS = (
    ('BEATS', "Beats", "Fade times in beats"),
    ('SECONDS', "Seconds", "Fade times in seconds"),
)
EFFECT_DIRECTIONS = (('GROUP', "Group order", "Use the group's direction"),) + DIRECTIONS


def _refresh(scene):
    from .engine import live
    live.refresh(scene)


def _effect_changed(self, context):
    _refresh(self.id_data)


def _group_changed(self, context):
    scene = self.id_data
    scene.cuelight.revision += 1
    _refresh(scene)


def _group_renamed(self, context):
    """Keep effects pointing at a group when it's renamed."""
    old, new = self.last_name, self.name
    if old and old != new:
        for e in self.id_data.cuelight.effects:
            if e.group == old:
                e.group = new
    self.last_name = new
    _group_changed(self, context)


def _member_clicked(self, context):
    """Clicking a member in the list selects just that fixture."""
    if 0 <= self.active_member < len(self.members):
        from .groups.core import select
        select(bpy.context.view_layer, [self.members[self.active_member].obj])


_type_items_cache = []


def _type_items(self, context):
    _type_items_cache[:] = registry.enum_items()
    return _type_items_cache


def _get_type(self):
    e = registry.get(self.effect_type)
    return e.order if e else 0


def _set_type(self, value):
    for e in registry.REGISTRY.values():
        if e.order == value and e.id != self.effect_type:
            self.effect_type = e.id
            params.apply_defaults(self, e)
            _refresh(self.id_data)


def _timing_changed(self, context):
    """BPM, offset or bar length changed: markers, cues and beat-locked effects follow."""
    scene = self.id_data
    from .cues import core as cues
    cues.relock(scene)
    if self.metronome:
        from .audio import metronome
        metronome.build(scene)
    if self.markers != 'NONE':
        from .audio import tempo
        tempo.update_markers(scene)
    _refresh(scene)


def _metronome_toggled(self, context):
    from .audio import metronome
    metronome.sync(self.id_data)


def _metronome_volume(self, context):
    from .audio import metronome
    st = metronome.find(self.id_data)
    if st is not None:
        st.volume = self.metronome_volume


def _markers_changed(self, context):
    from .audio import tempo
    tempo.update_markers(self.id_data)


_mod_items_cache = []


def _mod_owner(mod):
    """The effect a modulator belongs to."""
    for e in mod.id_data.cuelight.effects:
        for m in e.modulators:
            if m.as_pointer() == mod.as_pointer():
                return e
    return None


def _mod_keys(mod):
    from .audio.modulate import target_items
    e = _mod_owner(mod)
    return target_items(registry.get(e.effect_type) if e else None)


def _mod_items(self, context):
    _mod_items_cache[:] = [(k, label, desc, i) for i, (k, label, desc) in enumerate(_mod_keys(self))]
    return _mod_items_cache


def _get_mod_target(self):
    keys = [k for k, _, _ in _mod_keys(self)]
    return keys.index(self.target) if self.target in keys else 0


def _set_mod_target(self, value):
    keys = [k for k, _, _ in _mod_keys(self)]
    if 0 <= value < len(keys):
        self.target = keys[value]
        _refresh(self.id_data)


def _cue_changed(self, context):
    from .cues import core as cues
    cues.sync_markers(self.id_data)
    _refresh(self.id_data)


def _cue_frame_changed(self, context):
    from .cues import core as cues
    self["beat"] = cues.beat_of_frame(self.id_data, self.frame)  # direct: no update loop
    _cue_changed(self, context)


def _cue_beat_changed(self, context):
    from .cues import core as cues
    self["frame"] = cues.frame_of_beat(self.id_data, self.beat)
    _cue_changed(self, context)


def _cue_markers_toggled(self, context):
    from .cues import core as cues
    cues.sync_markers(self.id_data)


def _lanes_toggled(self, context):
    for win in bpy.context.window_manager.windows:
        for area in win.screen.areas:
            if area.type == 'DOPESHEET_EDITOR':
                area.tag_redraw()


def _live_toggled(self, context):
    from .engine import live
    if self.live_preview:
        live.refresh(self.id_data)
    else:
        live.release_all(self.id_data)


class CuelightColor(bpy.types.PropertyGroup):
    color: FloatVectorProperty(name="Colour", subtype='COLOR', size=3, min=0.0, max=1.0,
                               default=(1.0, 1.0, 1.0), update=_effect_changed)


class CuelightModulator(bpy.types.PropertyGroup):
    enabled: BoolProperty(name="On", default=True, update=_effect_changed)
    target: StringProperty(name="Target id", default="opacity", options={'HIDDEN'})
    target_enum: EnumProperty(name="Drives", items=_mod_items, get=_get_mod_target, set=_set_mod_target,
                              description="What the band drives")
    band: EnumProperty(name="Band", items=BANDS, default='BASS', update=_effect_changed)
    mode: EnumProperty(name="Mode", default='SCALE', update=_effect_changed, items=(
        ('SCALE', "Scale", "Silence pulls the value down, peaks leave it as set"),
        ('ADD', "Add", "Peaks add on top of the value"),
    ))
    amount: FloatProperty(name="Amount", default=1.0, soft_min=-2.0, soft_max=2.0, update=_effect_changed,
                          description="How strongly the band drives the target")
    gain: FloatProperty(name="Gain", default=1.0, min=0.0, soft_max=4.0, update=_effect_changed,
                        description="Boost the band before the threshold")
    threshold: FloatProperty(name="Threshold", default=0.1, min=0.0, max=0.99, subtype='FACTOR',
                             update=_effect_changed, description="Ignore the band below this level")
    attack: FloatProperty(name="Attack", default=0.01, min=0.0, soft_max=1.0, update=_effect_changed,
                          description="Rise time in seconds")
    release: FloatProperty(name="Release", default=0.15, min=0.0, soft_max=2.0, update=_effect_changed,
                           description="Fall time in seconds")


class CuelightCueRef(bpy.types.PropertyGroup):
    uid: StringProperty()


class CuelightCue(bpy.types.PropertyGroup):
    name: StringProperty(name="Name", update=_cue_changed)
    frame: IntProperty(name="Frame", update=_cue_frame_changed, description="Where the cue starts")
    beat: FloatProperty(name="Beat", update=_cue_beat_changed,
                        description="Where the cue starts, in beats from beat 1")
    lock_to_beat: BoolProperty(name="Lock to beat", default=True, update=_cue_changed,
                               description="Stay on the same beat when the BPM or beat 1 changes")
    fade: FloatProperty(name="Fade", default=0.0, min=0.0, soft_max=32.0, update=_effect_changed,
                        description="Crossfade from the previous cue, in beats. 0 is a hard cut")
    effects: CollectionProperty(type=CuelightCueRef)


class CuelightMember(bpy.types.PropertyGroup):
    obj: PointerProperty(name="Fixture", type=bpy.types.Object,
                         poll=lambda self, o: S.TYPE in o, update=_group_changed)


class CuelightGroup(bpy.types.PropertyGroup):
    name: StringProperty(name="Name", update=_group_renamed)
    last_name: StringProperty(options={'HIDDEN'})
    members: CollectionProperty(type=CuelightMember)
    active_member: IntProperty(update=_member_clicked,
                               description="Click a fixture to select it in the viewport")
    direction: EnumProperty(name="Direction", items=DIRECTIONS, default='LTR', update=_group_changed,
                            description="Order effects travel across the group")
    reverse: BoolProperty(name="Reverse", update=_group_changed, description="Flip the member order")
    seed: IntProperty(name="Seed", min=0, update=_group_changed, description="Shuffle for random order")
    expand_pixels: BoolProperty(name="Pixels as heads", default=True, update=_group_changed,
                                description="Treat every LED pixel as its own head")


class CuelightEffect(bpy.types.PropertyGroup):
    name: StringProperty(name="Name", update=_effect_changed)
    uid: StringProperty(options={'HIDDEN'})
    effect_type: StringProperty(name="Type id", options={'HIDDEN'})
    type_enum: EnumProperty(name="Effect", items=_type_items, get=_get_type, set=_set_type)
    group: StringProperty(name="Group", update=_effect_changed, description="Group this layer plays on")
    enabled: BoolProperty(name="On", default=True, update=_effect_changed)
    frame_start: IntProperty(name="Start", default=1, update=_effect_changed)
    frame_end: IntProperty(name="End", default=250, update=_effect_changed)
    blend: EnumProperty(name="Blend", items=BLENDS, default='REPLACE', update=_effect_changed)
    opacity: FloatProperty(name="Opacity", default=1.0, min=0.0, max=1.0, subtype='FACTOR',
                           update=_effect_changed)
    speed: FloatProperty(name="Speed", default=4.0, min=0.001, soft_max=64.0, update=_effect_changed,
                         description="Length of one cycle, in the chosen unit (Hz: cycles per second)")
    speed_unit: EnumProperty(name="Unit", items=SPEED_UNITS, default='BEATS', update=_effect_changed)
    phase_spread: FloatProperty(name="Spread", default=0.0, soft_min=-4.0, soft_max=4.0,
                                update=_effect_changed,
                                description="Cycles of offset across the group. 1 puts a full wave across it")
    direction: EnumProperty(name="Direction", items=EFFECT_DIRECTIONS, default='GROUP',
                            update=_effect_changed)
    fade_in: FloatProperty(name="Fade in", default=0.0, min=0.0, soft_max=32.0, update=_effect_changed)
    fade_out: FloatProperty(name="Fade out", default=0.0, min=0.0, soft_max=32.0, update=_effect_changed)
    fade_unit: EnumProperty(name="Fade unit", items=TIME_UNITS, default='BEATS', update=_effect_changed)
    colors: CollectionProperty(type=CuelightColor)
    active_color: IntProperty()
    seed: IntProperty(name="Seed", min=0, update=_effect_changed)
    modulators: CollectionProperty(type=CuelightModulator)


class CuelightSettings(bpy.types.PropertyGroup):
    mount: EnumProperty(name="Mount", items=MOUNTS, default='HANG',
                        description="How new fixtures are hung")
    groups: CollectionProperty(type=CuelightGroup)
    active_group: IntProperty(name="Group")
    effects: CollectionProperty(type=CuelightEffect)
    active_effect: IntProperty(name="Effect")

    bpm: FloatProperty(name="BPM", default=128.0, min=20.0, max=400.0, update=_timing_changed,
                       description="Song tempo")
    beat_offset: FloatProperty(name="Beat offset", default=1.0, update=_timing_changed,
                               description="Frame where beat 1 of bar 1 lands")
    beats_per_bar: IntProperty(name="Beats per bar", default=4, min=1, max=16, update=_timing_changed)
    metronome: BoolProperty(name="Metronome", default=False, update=_metronome_toggled,
                            description="Play a click on every beat with the song, to check the grid by ear. "
                                        "Never included in renders")
    metronome_volume: FloatProperty(name="Volume", default=0.8, min=0.0, max=2.0, update=_metronome_volume,
                                    description="Click volume")
    markers: EnumProperty(name="Markers", default='NONE', update=_markers_changed, items=(
        ('NONE', "Off", "No beat markers"),
        ('BARS', "Bars", "A marker on every bar"),
        ('BEATS', "Beats", "A marker on every beat"),
    ))

    cues: CollectionProperty(type=CuelightCue)
    active_cue: IntProperty(name="Cue")
    use_cues: BoolProperty(name="Use cues", default=False, update=_effect_changed,
                           description="Play only the layers in the current cue")
    cue_snap: EnumProperty(name="Snap", default='BAR', items=(
        ('NONE', "Frame", "New cues land exactly on the playhead"),
        ('BEAT', "Beat", "New cues snap to the nearest beat"),
        ('BAR', "Bar", "New cues snap to the nearest bar"),
    ))
    cue_markers: BoolProperty(name="Cue markers", default=True, update=_cue_markers_toggled,
                              description="Show cues as markers on the timeline")

    show_lanes: BoolProperty(name="Effect lanes", default=True, update=_lanes_toggled,
                             description="Show effect layers as bars on the Timeline and Dope Sheet")

    live_preview: BoolProperty(name="Live preview", default=True, update=_live_toggled,
                               description="Play effects as you scrub. Turn off to edit fixtures by hand")
    baked: BoolProperty(name="Baked", default=False,
                        description="The show is baked to keyframes, so live preview stands aside")
    bake_start: IntProperty(name="Baked from", options={'HIDDEN'})
    bake_end: IntProperty(name="Baked to", options={'HIDDEN'})
    bake_keys: IntProperty(name="Baked keys", options={'HIDDEN'})
    bake_simplify: BoolProperty(name="Simplify", default=True,
                                description="Keep only the keys needed to stay within a hair of the live "
                                            "show. Far smaller files; off keys every changing frame")
    bake_range: EnumProperty(name="Range", default='SCENE', items=(
        ('SCENE', "Scene", "The scene's start to end frame"),
        ('PREVIEW', "Preview", "The timeline's preview range"),
        ('EFFECTS', "Effects", "From the first effect's start to the last effect's end"),
    ))
    revision: IntProperty(options={'HIDDEN', 'SKIP_SAVE'})


classes = (CuelightColor, CuelightModulator, CuelightCueRef, CuelightCue, CuelightMember, CuelightGroup, CuelightEffect, CuelightSettings)


def register():
    for c in classes:
        bpy.utils.register_class(c)
    bpy.types.Scene.cuelight = PointerProperty(type=CuelightSettings)


def unregister():
    del bpy.types.Scene.cuelight
    for c in reversed(classes):
        bpy.utils.unregister_class(c)
