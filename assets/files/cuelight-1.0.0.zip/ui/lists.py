import bpy

from ..effects import registry
from ..fixtures import schema as S
from ..utils.icons import icon


class CUELIGHT_UL_groups(bpy.types.UIList):
    def draw_item(self, context, layout, data, item, icon_, active_data, active_prop, index=0, flt_flag=0):
        row = layout.row(align=True)
        row.prop(item, "name", text="", emboss=False)
        n = sum(1 for m in item.members if m.obj)
        row.label(text=str(n))


class CUELIGHT_UL_members(bpy.types.UIList):
    def draw_item(self, context, layout, data, item, icon_, active_data, active_prop, index=0, flt_flag=0):
        obj = item.obj
        if obj is None:
            layout.label(text="Missing", icon='ERROR')
            return
        layout.label(text="%02d  %s" % (index + 1, obj.name), icon_value=icon(obj.get(S.TYPE, "").lower()))


class CUELIGHT_UL_effects(bpy.types.UIList):
    """Top layer first, the way a layer stack reads."""

    def draw_item(self, context, layout, data, item, icon_, active_data, active_prop, index=0, flt_flag=0):
        et = registry.get(item.effect_type)
        s = context.scene.cuelight
        row = layout.row(align=True)
        if s.use_cues and 0 <= s.active_cue < len(s.cues):
            from ..cues.core import contains
            inside = contains(s.cues[s.active_cue], item.uid)
            row.operator("cuelight.cue_toggle_effect", text="", emboss=False,
                         icon='RADIOBUT_ON' if inside else 'RADIOBUT_OFF').uid = item.uid
        row.prop(item, "enabled", text="")
        sub = row.row(align=True)
        sub.active = item.enabled and item.group in context.scene.cuelight.groups
        sub.prop(item, "name", text="", emboss=False, icon=et.icon if et else 'ERROR')
        dim = sub.row(align=True)
        dim.active = False
        dim.label(text=item.group or "No group")

    def filter_items(self, context, data, propname):
        items = getattr(data, propname)
        flags = [self.bitflag_filter_item] * len(items)
        if self.filter_name:
            needle = self.filter_name.lower()
            flags = [self.bitflag_filter_item if needle in (e.name + e.group).lower() else 0 for e in items]
        order = list(reversed(range(len(items))))
        # flt_neworder maps item index -> display position
        neworder = [0] * len(items)
        for pos, i in enumerate(order):
            neworder[i] = pos
        return flags, neworder


class CUELIGHT_UL_cues(bpy.types.UIList):
    """Cues in song order, each with a jump button."""

    def draw_item(self, context, layout, data, item, icon_, active_data, active_prop, index=0, flt_flag=0):
        from ..cues.core import current
        from ..cues.ops import format_position
        now = current(context.scene)
        row = layout.row(align=True)
        row.operator("cuelight.cue_jump", text="", emboss=False,
                     icon='PLAY' if now is not None and now.as_pointer() == item.as_pointer() else 'RIGHTARROW_THIN'
                     ).index = index
        row.prop(item, "name", text="", emboss=False)
        dim = row.row(align=True)
        dim.active = False
        dim.label(text="%s · %d fx" % (format_position(context.scene, item), len(item.effects)))

    def filter_items(self, context, data, propname):
        items = getattr(data, propname)
        flags = [self.bitflag_filter_item] * len(items)
        order = sorted(range(len(items)), key=lambda i: items[i].frame)
        neworder = [0] * len(items)
        for pos, i in enumerate(order):
            neworder[i] = pos
        return flags, neworder


classes = (CUELIGHT_UL_groups, CUELIGHT_UL_members, CUELIGHT_UL_effects, CUELIGHT_UL_cues)
