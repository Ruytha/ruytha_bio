import bpy

from . import bpm_editor, lists, panels, prefs

_classes = prefs.classes + lists.classes + panels.classes


def register():
    bpm_editor.register()
    for c in _classes:
        bpy.utils.register_class(c)


def unregister():
    for c in reversed(_classes):
        bpy.utils.unregister_class(c)
    bpm_editor.unregister()
