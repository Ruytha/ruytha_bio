import bpy

from ..utils.addon import PACKAGE
from .panels import draw_about


class CuelightPreferences(bpy.types.AddonPreferences):
    bl_idname = PACKAGE

    def draw(self, context):
        draw_about(self.layout)


classes = (CuelightPreferences,)
