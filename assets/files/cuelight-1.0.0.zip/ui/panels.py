"""The Light Show tab in the 3D viewport sidebar."""

import bpy

from ..effects import registry
from ..effects.ops import active_effect
from ..engine.evaluate import home_key, home_props
from ..fixtures import haze
from ..fixtures import schema as S
from ..utils.addon import CONTACT, VERSION, WEBSITE
from ..utils.icons import icon

TAB = "Light Show"


class _Panel:
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = TAB


def draw_about(layout):
    row = layout.row()
    row.template_icon(icon_value=icon("cuelight") or icon("mark"), scale=3.0)
    col = row.column(align=True)
    col.label(text="Cuelight %s" % VERSION, icon_value=0)
    col.label(text="Concert lights, cued properly.")
    col.label(text="By Ruytha Studios", icon_value=icon("mark"))
    col = layout.column(align=True)
    col.operator("wm.url_open", text="ruytha.dev/studios", icon='URL').url = WEBSITE
    col.operator("wm.url_open", text=CONTACT, icon='LINKED').url = "mailto:" + CONTACT


class CUELIGHT_PT_main(_Panel, bpy.types.Panel):
    bl_idname = "CUELIGHT_PT_main"
    bl_label = "Cuelight"

    def draw_header(self, context):
        self.layout.label(text="", icon_value=icon("cuelight") or icon("mark"))

    def draw(self, context):
        n = len(S.fixtures_in(context.scene))
        self.layout.label(text="%d fixture%s" % (n, "" if n == 1 else "s"))


class CUELIGHT_PT_fixtures(_Panel, bpy.types.Panel):
    bl_idname = "CUELIGHT_PT_fixtures"
    bl_parent_id = "CUELIGHT_PT_main"
    bl_label = "01  Fixtures"

    def draw(self, context):
        layout = self.layout
        settings = context.scene.cuelight

        grid = layout.grid_flow(row_major=True, columns=3, even_columns=True, align=True)
        for key, label, _ in S.FIXTURE_TYPES:
            op = grid.operator("cuelight.add_fixture", text=label, icon_value=icon(key.lower()))
            op.fixture_type = key
        grid.operator("cuelight.add_array", text="Array", icon_value=icon("array"))

        row = layout.row(align=True)
        row.prop(settings, "mount", expand=True)
        if S.BEAM_CONES in context.scene:
            layout.prop(context.scene, '["%s"]' % S.BEAM_CONES, text="Beam cones", slider=True)

        root = S.fixture_root(context.active_object)
        if root is not None:
            draw_fixture(layout.box(), root)


def _channel(layout, root, prop, **kw):
    """Draw a control channel. Under effect control, edit the home value instead
    of the live one (which the next frame would overwrite)."""
    k = home_key(prop)
    if k in root:
        layout.prop(root, '["%s"]' % k, **kw)
    else:
        layout.prop(root, '["%s"]' % prop, **kw)


def draw_fixture(layout, root):
    t = root[S.TYPE]
    head = layout.row()
    head.label(text=root.name, icon_value=icon(t.lower()))
    head.operator("cuelight.delete_fixtures", text="", icon='TRASH')

    if home_props(root):
        layout.label(text="Effects playing. Editing home look.", icon='INFO')
    col = layout.column(align=True)
    _channel(col, root, S.INTENSITY, text="Intensity", slider=True)
    _channel(col, root, S.COLOR, text="")
    if t in {'SPOT', 'WASH', 'LASER'}:
        col = layout.column(align=True)
        _channel(col, root, S.PAN, text="Pan")
        _channel(col, root, S.TILT, text="Tilt")
        _channel(col, root, S.ZOOM, text="Spread" if t == 'LASER' else "Zoom", slider=True)
    _channel(layout, root, S.STROBE, text="Strobe Hz")

    if t in {'SPOT', 'WASH', 'STROBE'}:
        layout.prop(root, '["%s"]' % S.POWER, text="Power")
    if S.BEAM in root:
        col = layout.column(align=True)
        col.prop(root, '["%s"]' % S.BEAM, text="Beam", slider=True)
        col.prop(root, '["%s"]' % S.BEAM_LENGTH, text="Beam length")
    elif S.BEAM_LENGTH in root:
        layout.prop(root, '["%s"]' % S.BEAM_LENGTH, text="Beam length")
    if t == 'SPOT':
        label = dict((k, l) for k, l, _ in S.GOBOS).get(root.get(S.GOBO, 'NONE'), "Open")
        layout.operator_menu_enum("cuelight.set_gobo", "kind", text="Gobo: " + label)


class CUELIGHT_PT_haze(_Panel, bpy.types.Panel):
    bl_idname = "CUELIGHT_PT_haze"
    bl_parent_id = "CUELIGHT_PT_fixtures"
    bl_label = "Haze"
    bl_options = {'DEFAULT_CLOSED'}

    def draw_header(self, context):
        self.layout.label(text="", icon_value=icon("haze"))

    def draw(self, context):
        layout = self.layout
        obj = haze.find(context.scene)
        if obj is None:
            layout.operator("cuelight.add_haze", text="Add haze")
            return
        layout.prop(obj, '["%s"]' % haze.DENSITY, text="Density", slider=True)
        row = layout.row(align=True)
        row.operator("cuelight.add_haze", text="Refit").density = obj[haze.DENSITY]
        row.operator("cuelight.remove_haze", text="Remove")
        eevee = context.scene.eevee
        col = layout.column(align=True)
        col.label(text="EEVEE volumes")
        col.prop(eevee, "volumetric_tile_size", text="Detail")
        col.prop(eevee, "volumetric_samples", text="Samples")


class CUELIGHT_PT_groups(_Panel, bpy.types.Panel):
    bl_idname = "CUELIGHT_PT_groups"
    bl_parent_id = "CUELIGHT_PT_main"
    bl_label = "02  Groups"

    def draw(self, context):
        layout = self.layout
        s = context.scene.cuelight
        row = layout.row()
        row.template_list("CUELIGHT_UL_groups", "", s, "groups", s, "active_group", rows=3)
        col = row.column(align=True)
        col.operator("cuelight.group_add", text="", icon='ADD')
        col.operator("cuelight.group_remove", text="", icon='REMOVE')
        if not (0 <= s.active_group < len(s.groups)):
            layout.label(text="Select fixtures, then press +.")
            return
        g = s.groups[s.active_group]

        row = layout.row(align=True)
        row.operator("cuelight.group_assign", text="Add selected")
        row.operator("cuelight.group_unassign", text="Remove")
        row = layout.row(align=True)
        row.operator("cuelight.member_select", text="Select one", icon='RESTRICT_SELECT_OFF')
        row.operator("cuelight.group_select", text="Select all", icon='SELECT_SET')

        col = layout.column(align=True)
        col.prop(g, "direction", text="")
        row = col.row(align=True)
        row.prop(g, "reverse", toggle=True)
        row.prop(g, "expand_pixels", toggle=True)
        if g.direction == 'RANDOM':
            col.prop(g, "seed")

        row = layout.row()
        row.template_list("CUELIGHT_UL_members", "", g, "members", g, "active_member", rows=3)
        col = row.column(align=True)
        col.operator("cuelight.member_move", text="", icon='TRIA_UP').direction = 'UP'
        col.operator("cuelight.member_move", text="", icon='TRIA_DOWN').direction = 'DOWN'
        col.separator()
        col.operator_menu_enum("cuelight.group_sort", "by", text="", icon='SORTSIZE')


class CUELIGHT_PT_effects(_Panel, bpy.types.Panel):
    bl_idname = "CUELIGHT_PT_effects"
    bl_parent_id = "CUELIGHT_PT_main"
    bl_label = "03  Effects"

    def draw_header_preset(self, context):
        s = context.scene.cuelight
        self.layout.prop(s, "live_preview", text="", icon='PLAY' if s.live_preview else 'PAUSE', emboss=False)

    def draw(self, context):
        layout = self.layout
        s = context.scene.cuelight
        if s.baked:
            layout.label(text="Baked. Clear the bake to preview edits.", icon='KEYFRAME_HLT')
        row = layout.row()
        row.template_list("CUELIGHT_UL_effects", "", s, "effects", s, "active_effect", rows=5)
        col = row.column(align=True)
        col.operator_menu_enum("cuelight.effect_add", "effect_type", text="", icon='ADD')
        col.operator("cuelight.effect_remove", text="", icon='REMOVE')
        col.operator("cuelight.effect_duplicate", text="", icon='DUPLICATE')
        col.separator()
        col.operator("cuelight.effect_move", text="", icon='TRIA_UP').direction = 'UP'
        col.operator("cuelight.effect_move", text="", icon='TRIA_DOWN').direction = 'DOWN'

        e = active_effect(context)
        if e is not None:
            draw_effect(layout, context, e)


def draw_effect(layout, context, e):
    s = context.scene.cuelight
    et = registry.get(e.effect_type)

    col = layout.column(align=True)
    col.prop(e, "type_enum", text="")
    col.prop_search(e, "group", s, "groups", text="", icon='GROUP')
    if e.group and e.group not in s.groups:
        col.label(text="Group not found", icon='ERROR')

    box = layout.box()
    box.label(text="Time")
    row = box.row(align=True)
    row.prop(e, "frame_start")
    row.operator("cuelight.effect_frame", text="", icon='TIME').which = 'START'
    row.prop(e, "frame_end")
    row.operator("cuelight.effect_frame", text="", icon='TIME').which = 'END'
    row = box.row(align=True)
    row.prop(e, "fade_in", text="In")
    row.prop(e, "fade_out", text="Out")
    row.prop(e, "fade_unit", text="")

    box = layout.box()
    box.label(text="Layer")
    row = box.row(align=True)
    row.prop(e, "blend", text="")
    row.prop(e, "opacity", slider=True)

    box = layout.box()
    box.label(text="Motion")
    if et is None or et.uses_speed:
        row = box.row(align=True)
        row.prop(e, "speed")
        row.prop(e, "speed_unit", text="")
        if e.speed_unit == 'BEATS':
            row = box.row(align=True)
            for beats, label in ((0.25, "¼"), (0.5, "½"), (1.0, "1"), (2.0, "2"), (4.0, "4"),
                                 (8.0, "8"), (16.0, "16")):
                op = row.operator("cuelight.speed_preset", text=label, depress=abs(e.speed - beats) < 1e-6)
                op.beats = beats
    box.prop(e, "phase_spread")
    box.prop(e, "direction", text="")

    if et is None:
        layout.label(text="Unknown effect type %r" % e.effect_type, icon='ERROR')
        return

    if et.params:
        box = layout.box()
        box.label(text=et.label)
        for prm in et.params:
            if prm.key not in e:
                continue
            if prm.choices:
                cur = int(e[prm.key])
                box.label(text=prm.label or prm.name.title())
                row = box.row(align=True)
                for i, (_, label) in enumerate(prm.choices):
                    op = row.operator("cuelight.param_choice", text=label, depress=(i == cur))
                    op.name, op.index = prm.name, i
            elif isinstance(prm.default, bool):
                box.prop(e, '["%s"]' % prm.key, text=prm.label or prm.name.title(), toggle=True)
            else:
                box.prop(e, '["%s"]' % prm.key, text=prm.label or prm.name.title(),
                         slider=prm.min is not None and prm.max is not None)

    draw_modulators(layout, context, e)

    if et.colors:
        box = layout.box()
        row = box.row()
        row.label(text="Colours")
        row.operator("cuelight.color_add", text="", icon='ADD', emboss=False)
        flow = box.grid_flow(columns=4, even_columns=True, align=True)
        for i, c in enumerate(e.colors):
            r = flow.row(align=True)
            r.prop(c, "color", text="")
            r.operator("cuelight.color_remove", text="", icon='X').index = i


def draw_modulators(layout, context, e):
    box = layout.box()
    row = box.row()
    row.label(text="Audio")
    row.operator("cuelight.modulator_add", text="", icon='ADD', emboss=False)
    for i, m in enumerate(e.modulators):
        col = box.column(align=True)
        row = col.row(align=True)
        row.prop(m, "enabled", text="")
        row.prop(m, "band", text="")
        row.prop(m, "target_enum", text="")
        row.operator("cuelight.modulator_remove", text="", icon='X').index = i
        sub = col.column(align=True)
        sub.active = m.enabled
        r = sub.row(align=True)
        r.prop(m, "mode", expand=True)
        r = sub.row(align=True)
        r.prop(m, "amount")
        r.prop(m, "gain")
        r = sub.row(align=True)
        r.prop(m, "threshold", slider=True)
        r = sub.row(align=True)
        r.prop(m, "attack")
        r.prop(m, "release")


class CUELIGHT_PT_presets(_Panel, bpy.types.Panel):
    bl_idname = "CUELIGHT_PT_presets"
    bl_parent_id = "CUELIGHT_PT_effects"
    bl_label = "Presets"
    bl_options = {'DEFAULT_CLOSED'}

    def draw(self, context):
        layout = self.layout
        col = layout.column(align=True)
        row = col.row(align=True)
        row.menu("CUELIGHT_MT_show_presets", text="Add show", icon='PRESET')
        row.menu("CUELIGHT_MT_effect_presets", text="Add effect", icon='PRESET')
        row = col.row(align=True)
        row.operator("cuelight.preset_save", text="Save show").kind = 'SHOW'
        row.operator("cuelight.preset_save", text="Save effect").kind = 'EFFECT'
        row = col.row(align=True)
        row.operator("cuelight.preset_export", text="Export…", icon='EXPORT')
        row.operator("cuelight.preset_folder", text="", icon='FILE_FOLDER')
        layout.label(text="Built-in shows drop in at the playhead.", icon='INFO')


class CUELIGHT_PT_music(_Panel, bpy.types.Panel):
    bl_idname = "CUELIGHT_PT_music"
    bl_parent_id = "CUELIGHT_PT_main"
    bl_label = "04  Music"

    def draw(self, context):
        from ..audio import analysis, loader
        from ..engine import timing
        layout = self.layout
        scene = context.scene
        s = scene.cuelight

        strip = loader.song_strip(scene)
        row = layout.row(align=True)
        if strip is None:
            row.operator("cuelight.load_song", text="Load song", icon='SOUND')
        else:
            secs = strip.frame_final_duration / timing.fps(scene)
            row.label(text="%s  %d:%02d" % (strip.name, secs // 60, secs % 60), icon='SOUND')
            row.operator("cuelight.load_song", text="", icon='FILE_REFRESH')

        box = layout.box()
        if strip is not None:
            from .bpm_editor import verdict
            row = box.row()
            verdict(row, scene)
            row.operator("cuelight.bpm_editor", text="Editor", icon='SETTINGS')
        row = box.row(align=True)
        row.prop(s, "bpm")
        row.operator("cuelight.tap_tempo", text="Tap")
        row.operator("cuelight.detect_bpm", text="", icon='VIEWZOOM')
        row = box.row(align=True)
        row.prop(s, "beat_offset", text="Beat 1 at")
        row.operator("cuelight.beat_nudge", text="", icon='TRIA_LEFT').frames = -1.0
        row.operator("cuelight.beat_nudge", text="", icon='TRIA_RIGHT').frames = 1.0
        row.operator("cuelight.beat_here", text="", icon='TIME')
        row = box.row(align=True)
        row.prop(s, "beats_per_bar", text="Beats per bar")
        row = box.row(align=True)
        row.label(text="Markers")
        row.prop(s, "markers", expand=True)
        beat = timing.beats_at(scene, s, scene.frame_current)
        if beat >= 0:
            bar, b = divmod(int(beat), s.beats_per_bar)
            box.label(text="Now: bar %d, beat %d" % (bar + 1, b + 1))

        box = layout.box()
        row = box.row()
        row.label(text="Audio bands")
        row.operator("cuelight.analyze_audio", text="Analyse", icon='SEQ_HISTOGRAM')
        if analysis.has_analysis(scene):
            col = box.column(align=True)
            for key, label, _ in analysis.BANDS:
                start, env = analysis.envelope(scene, key)
                i = scene.frame_current - start
                v = float(env[i]) if 0 <= i < len(env) else 0.0
                col.progress(factor=v, text="%s  %d%%" % (label, round(v * 100)))
        else:
            box.label(text="Load a song, then analyse to drive effects with it.")


class CUELIGHT_PT_bpm(_Panel, bpy.types.Panel):
    bl_idname = "CUELIGHT_PT_bpm"
    bl_parent_id = "CUELIGHT_PT_music"
    bl_label = "BPM editor"
    bl_options = {'DEFAULT_CLOSED'}

    def draw(self, context):
        from .bpm_editor import draw_bpm_editor
        draw_bpm_editor(self.layout, context)


class CUELIGHT_PT_cues(_Panel, bpy.types.Panel):
    bl_idname = "CUELIGHT_PT_cues"
    bl_parent_id = "CUELIGHT_PT_main"
    bl_label = "05  Cues"

    def draw_header_preset(self, context):
        self.layout.prop(context.scene.cuelight, "use_cues", text="")

    def draw(self, context):
        from ..cues.ops import active_cue
        layout = self.layout
        s = context.scene.cuelight

        row = layout.row(align=True)
        row.operator("cuelight.cue_step", text="", icon='PREV_KEYFRAME').direction = 'PREV'
        row.operator("cuelight.cue_add", text="Cue here", icon='ADD')
        row.operator("cuelight.cue_step", text="", icon='NEXT_KEYFRAME').direction = 'NEXT'

        row = layout.row()
        row.template_list("CUELIGHT_UL_cues", "", s, "cues", s, "active_cue", rows=4)
        col = row.column(align=True)
        col.operator("cuelight.cue_remove", text="", icon='REMOVE')

        c = active_cue(context)
        if c is None:
            layout.label(text="Build the look, then add a cue. Repeat per section.")
            return
        box = layout.box()
        row = box.row(align=True)
        if c.lock_to_beat:
            row.prop(c, "beat")
        else:
            row.prop(c, "frame")
        row.prop(c, "lock_to_beat", text="", icon='LOCKED' if c.lock_to_beat else 'UNLOCKED')
        row.operator("cuelight.cue_here", text="", icon='TIME')
        box.prop(c, "fade", text="Fade in (beats)")
        row = box.row()
        row.label(text="%d layer%s" % (len(c.effects), "" if len(c.effects) == 1 else "s"))
        row.operator("cuelight.cue_capture", text="Fill from layers")
        if s.use_cues:
            box.label(text="Pick its layers with the dots.", icon='INFO')
        else:
            box.label(text="Cues are off: every enabled layer plays.", icon='INFO')

        row = layout.row(align=True)
        row.prop(s, "cue_snap", expand=True)
        row.prop(s, "cue_markers", text="", icon='MARKER_HLT')


class CUELIGHT_PT_bake(_Panel, bpy.types.Panel):
    bl_idname = "CUELIGHT_PT_bake"
    bl_parent_id = "CUELIGHT_PT_main"
    bl_label = "06  Bake"

    def draw(self, context):
        from ..engine.ops import bake_range
        layout = self.layout
        scene = context.scene
        s = scene.cuelight
        row = layout.row(align=True)
        row.prop(s, "bake_range", expand=True)
        start, end = bake_range(scene)
        row = layout.row()
        row.label(text="Frames %d to %d" % (start, end))
        row.prop(s, "bake_simplify")
        col = layout.column(align=True)
        col.scale_y = 1.4
        col.operator("cuelight.bake", text="Rebake show" if s.baked else "Bake show", icon='RENDER_ANIMATION')
        if s.baked:
            layout.operator("cuelight.clear_bake", icon='TRASH')
            layout.label(text="Baked %d to %d, %s keys" % (s.bake_start, s.bake_end, format(s.bake_keys, ",")),
                         icon='CHECKMARK')
            if s.bake_keys > 50000:
                layout.label(text="Save with Compress on: about 9x smaller.", icon='FILE_BLEND')
        else:
            layout.label(text="Live preview. Bake before you render.", icon='INFO')


class CUELIGHT_PT_about(_Panel, bpy.types.Panel):
    bl_idname = "CUELIGHT_PT_about"
    bl_parent_id = "CUELIGHT_PT_main"
    bl_label = "About"
    bl_options = {'DEFAULT_CLOSED'}

    def draw(self, context):
        draw_about(self.layout)


classes = (
    CUELIGHT_PT_main,
    CUELIGHT_PT_fixtures,
    CUELIGHT_PT_haze,
    CUELIGHT_PT_groups,
    CUELIGHT_PT_effects,
    CUELIGHT_PT_presets,
    CUELIGHT_PT_music,
    CUELIGHT_PT_bpm,
    CUELIGHT_PT_cues,
    CUELIGHT_PT_bake,
    CUELIGHT_PT_about,
)
