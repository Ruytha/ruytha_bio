"""The BPM editor: verdict, song strip with the beat grid, tempo candidates,
fine tempo and grid controls, and the metronome. Drawn in 04 Music and as a
popup."""

import bpy.utils.previews

from ..audio import analysis, beat, loader

TILES = 8
TILE = 64
_pcoll = None
_key = None


def _strip_icons(scene):
    """Icon ids for the strip tiles, regenerated when anything they show changes."""
    global _key
    if _pcoll is None:
        return [], 0
    s = scene.cuelight
    data = scene.get(analysis.KEY)
    _, _, first_bar = beat.strip_window(scene, TILES)
    key = (data.get("stamp") if data else None, round(s.bpm, 4), round(s.beat_offset, 4),
           s.beats_per_bar, scene.frame_current, scene.render.fps)
    if key != _key:
        tiles, first_bar = beat.render_strip(scene, TILES, TILE)
        for i, img in enumerate(tiles):
            p = _pcoll.get("tile%d" % i) or _pcoll.new("tile%d" % i)
            flat = img.ravel()
            p.image_size = (TILE, TILE)
            p.image_pixels_float = flat
            p.icon_size = (TILE, TILE)  # the panel draws the icon, so give it full detail
            p.icon_pixels_float = flat
        _key = key
    return [_pcoll["tile%d" % i].icon_id for i in range(TILES)], first_bar


def verdict(layout, scene):
    conf, _ = beat.info(scene)
    if conf is None:
        layout.label(text="Tempo not detected yet", icon='QUESTION')
    elif conf >= beat.SURE:
        layout.label(text="Locked, %d%% sure" % round(conf * 100), icon='CHECKMARK')
    else:
        layout.label(text="Check by ear, %d%% sure" % round(conf * 100), icon='ERROR')


def draw_bpm_editor(layout, context):
    scene = context.scene
    s = scene.cuelight
    if loader.song_strip(scene) is None:
        layout.label(text="Load a song to fit the beat grid to it.")
        layout.operator("cuelight.load_song", icon='SOUND')
        return

    verdict(layout, scene)

    # Song strip: the song's hits under the grid
    if analysis.has_analysis(scene):
        ids, first_bar = _strip_icons(scene)
        col = layout.column(align=True)
        row = col.row(align=True)
        for icon_id in ids:
            row.template_icon(icon_value=icon_id, scale=2.4)
        sub = col.row()
        sub.active = False
        sub.label(text="Bars %d to %d. Hits should sit on the bright bar lines." % (first_bar + 1, first_bar + TILES))
    else:
        layout.operator("cuelight.analyze_audio", text="Analyse to see the song", icon='SEQ_HISTOGRAM')

    # Tempos the detector heard
    _, cands = beat.info(scene)
    if cands:
        row = layout.row(align=True)
        row.label(text="Heard")
        for bpm, score in [c for c in cands if c[1] >= 0.02] or cands[:1]:
            op = row.operator("cuelight.pick_tempo", text="%.1f  %d%%" % (bpm, round(score * 100)),
                              depress=abs(s.bpm - bpm) < 0.05)
            op.bpm = bpm

    # Tempo
    box = layout.box()
    row = box.row(align=True)
    for mode, value, label in (('MUL', 0.5, "÷2"), ('ADD', -1.0, "-1"), ('ADD', -0.1, "-.1")):
        op = row.operator("cuelight.bpm_adjust", text=label)
        op.mode, op.value = mode, value
    row.prop(s, "bpm", text="")
    for mode, value, label in (('ADD', 0.1, "+.1"), ('ADD', 1.0, "+1"), ('MUL', 2.0, "×2")):
        op = row.operator("cuelight.bpm_adjust", text=label)
        op.mode, op.value = mode, value
    row = box.row(align=True)
    row.operator("cuelight.tap_tempo", text="Tap", icon='HAND')
    row.operator("cuelight.detect_bpm", text="Detect", icon='VIEWZOOM').section = False
    sub = row.row(align=True)
    sub.enabled = scene.use_preview_range
    sub.operator("cuelight.detect_bpm", text="In range", icon='PREVIEW_RANGE').section = True

    # Grid
    box = layout.box()
    row = box.row(align=True)
    row.prop(s, "beat_offset", text="Beat 1")
    row.operator("cuelight.beat_nudge", text="", icon='TRIA_LEFT').frames = -1.0
    row.operator("cuelight.beat_nudge", text="", icon='TRIA_RIGHT').frames = 1.0
    row = box.row(align=True)
    row.operator("cuelight.beat_shift", text="Beat earlier", icon='BACK').beats = -1.0
    row.operator("cuelight.beat_shift", text="Beat later", icon='FORWARD').beats = 1.0
    row = box.row(align=True)
    row.operator("cuelight.beat_here", text="Beat 1 here", icon='TIME')
    row.operator("cuelight.fit_grid", text="Fit grid", icon='SNAP_ON')

    # Metronome
    row = layout.row(align=True)
    row.prop(s, "metronome", toggle=True, icon='SPEAKER')
    sub = row.row(align=True)
    sub.active = s.metronome
    sub.prop(s, "metronome_volume", slider=True)


def register():
    global _pcoll, _key
    _pcoll = bpy.utils.previews.new()
    _key = None


def unregister():
    global _pcoll, _key
    if _pcoll is not None:
        bpy.utils.previews.remove(_pcoll)
    _pcoll = None
    _key = None

