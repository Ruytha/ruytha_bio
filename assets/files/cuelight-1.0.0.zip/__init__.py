# SPDX-License-Identifier: GPL-3.0-or-later
# Cuelight, by Ruytha Studios. https://ruytha.dev/studios

from . import audio, cues, effects, engine, fixtures, groups, presets, props, timeline, ui
from .utils import icons

# Registration order matters: props before anything that points at them,
# UI last so panels never draw against missing types.
_modules = (icons, props, fixtures, groups, effects, audio, cues, presets, engine, timeline, ui)


def register():
    for m in _modules:
        m.register()


def unregister():
    for m in reversed(_modules):
        m.unregister()
