"""Presets as JSON: single effects and whole shows.

Times are stored in beats, so a show saved at 128 BPM lands on the right bars
in a 96 BPM song. Groups are matched by name, then by role (the fixture type
most of a group is made of), so built-in shows work on any rig.
"""

import json
import os

import bpy

from ..effects import params, registry
from ..effects.ops import add_effect
from ..engine import live, timing
from ..fixtures import schema as S
from ..groups import core as groups
from ..groups.ops import new_group

FORMAT = "cuelight/1"
COMMON = ("enabled", "blend", "opacity", "speed", "speed_unit", "phase_spread", "direction",
          "fade_in", "fade_out", "fade_unit", "seed")
MODULATOR = ("enabled", "target", "band", "mode", "amount", "gain", "threshold", "attack", "release")
ROLES = {'SPOT': "spots", 'WASH': "wash", 'LEDBAR': "leds", 'LASER': "lasers", 'STROBE': "strobes"}
ROLE_LABELS = {"spots": "Spots", "wash": "Wash", "leds": "LEDs", "lasers": "Lasers", "strobes": "Strobes"}

BUILTIN_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "builtin")


# ---------------------------------------------------------------- folders

def library_dir(kind):
    """User preset folder for 'effects' or 'shows'. CUELIGHT_PRESET_DIR overrides it."""
    base = os.environ.get("CUELIGHT_PRESET_DIR")
    if not base:
        from ..utils.addon import PACKAGE
        try:
            base = bpy.utils.extension_path_user(PACKAGE, path="presets", create=True)
        except (ValueError, TypeError):  # running from source, not as an installed extension
            base = bpy.utils.user_resource('CONFIG', path="cuelight_presets", create=True)
    path = os.path.join(base, kind)
    os.makedirs(path, exist_ok=True)
    return path


def list_presets(folder):
    """[(path, name, description)] for every JSON preset in a folder."""
    out = []
    if not os.path.isdir(folder):
        return out
    for fn in sorted(os.listdir(folder)):
        if fn.lower().endswith(".json"):
            path = os.path.join(folder, fn)
            try:
                with open(path, encoding="utf-8") as f:
                    d = json.load(f)
                out.append((path, d.get("name", fn[:-5]), d.get("description", "")))
            except (OSError, ValueError):
                continue
    return out


def safe_name(name):
    keep = "".join(ch if ch.isalnum() or ch in " -_" else "_" for ch in name).strip()
    return keep or "preset"


def write(path, data):
    with open(path, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2)


def read(path):
    with open(path, encoding="utf-8") as f:
        d = json.load(f)
    if d.get("format") != FORMAT:
        raise ValueError("Not a Cuelight preset (format %r)" % d.get("format"))
    return d


# ---------------------------------------------------------------- effects

def _plain(v):
    if hasattr(v, "to_list"):
        return v.to_list()
    if hasattr(v, "__len__") and not isinstance(v, str):
        return list(v)
    return v


def effect_to_dict(scene, e, origin_beat=0.0):
    s = scene.cuelight
    fpb = timing.frames_per_beat(scene, s)
    et = registry.get(e.effect_type)
    d = {
        "type": e.effect_type,
        "name": e.name,
        "group": e.group,
        "start_beat": round(timing.beats_at(scene, s, e.frame_start) - origin_beat, 4),
        "length_beats": round((e.frame_end - e.frame_start + 1) / fpb, 4),
        "params": {prm.name: _plain(e.get(prm.key, prm.default)) for prm in (et.params if et else ())},
        "colors": [list(c.color) for c in e.colors],
        "modulators": [{k: getattr(m, k) for k in MODULATOR} for m in e.modulators],
    }
    for k in COMMON:
        d[k] = getattr(e, k)
    return d


def effect_from_dict(scene, d, group, start_frame):
    s = scene.cuelight
    fpb = timing.frames_per_beat(scene, s)
    start = int(round(start_frame))
    end = start + max(1, int(round(d.get("length_beats", 32) * fpb))) - 1
    e = add_effect(scene, d["type"], group, start, end, name=d.get("name"))
    et = registry.get(d["type"])
    for k in COMMON:
        if k in d:
            setattr(e, k, d[k])
    for name, v in d.get("params", {}).items():
        prm = et.param(name)
        if prm is not None:
            e[prm.key] = type(prm.default)(v) if not isinstance(prm.default, bool) else bool(v)
    params.ensure(e, et)
    if d.get("colors"):
        e.colors.clear()
        for c in d["colors"]:
            e.colors.add().color = c[:3]
    for md in d.get("modulators", []):
        m = e.modulators.add()
        for k in MODULATOR:
            if k in md:
                setattr(m, k, md[k])
    return e


def save_effect(scene, e, name):
    d = {"format": FORMAT, "kind": "effect", "name": name, **effect_to_dict(scene, e, timing.beats_at(scene, scene.cuelight, e.frame_start))}
    d.pop("group", None)
    path = os.path.join(library_dir("effects"), safe_name(name) + ".json")
    write(path, d)
    return path


def apply_effect(scene, d, group, frame=None):
    frame = scene.frame_current if frame is None else frame
    e = effect_from_dict(scene, d, group, frame)
    live.refresh(scene)
    return e


# ---------------------------------------------------------------- shows

def role_of(scene, group):
    counts = {}
    for h in group.members:
        if h.obj is not None and S.TYPE in h.obj:
            r = ROLES.get(h.obj[S.TYPE])
            counts[r] = counts.get(r, 0) + 1
    return max(counts, key=counts.get) if counts else None


def show_to_dict(scene, name="Show", description=""):
    s = scene.cuelight
    out = {
        "format": FORMAT, "kind": "show", "name": name, "description": description,
        "bpm": s.bpm, "beats_per_bar": s.beats_per_bar,
        "groups": [], "effects": [], "cues": [],
    }
    for g in s.groups:
        out["groups"].append({
            "name": g.name, "role": role_of(scene, g), "direction": g.direction, "reverse": g.reverse,
            "seed": g.seed, "expand_pixels": g.expand_pixels,
            "members": [m.obj.name for m in g.members if m.obj],
        })
    index = {}
    for i, e in enumerate(s.effects):
        index[e.uid] = i
        out["effects"].append(effect_to_dict(scene, e))
    for c in s.cues:
        out["cues"].append({
            "name": c.name, "beat": round(timing.beats_at(scene, s, c.frame), 4), "fade": c.fade,
            "lock_to_beat": c.lock_to_beat, "effects": [index[r.uid] for r in c.effects if r.uid in index],
        })
    return out


def save_show(scene, name, description=""):
    path = os.path.join(library_dir("shows"), safe_name(name) + ".json")
    write(path, show_to_dict(scene, name, description))
    return path


def resolve_groups(scene, preset_groups, create_missing=True):
    """{preset group name: scene group name or None}, plus notes for the report."""
    s = scene.cuelight
    taken, mapping, notes = set(), {}, []
    for gd in preset_groups:
        name = gd["name"]
        if name in s.groups:
            mapping[name] = name
            taken.add(name)
    for gd in preset_groups:
        name = gd["name"]
        if name in mapping:
            continue
        role = gd.get("role")
        match = next((g.name for g in s.groups if g.name not in taken and role and role_of(scene, g) == role), None)
        if match is None:
            members = [bpy.data.objects.get(n) for n in gd.get("members", [])]
            members = [o for o in members if o is not None and S.TYPE in o]
            if members:
                match = new_group(scene, name, members).name
            elif create_missing and gd.get("members"):
                match = new_group(scene, name, []).name
                notes.append("%s: created empty, add fixtures to it" % match)
        if match is not None:
            taken.add(match)
        else:
            notes.append("No %s for %s" % (ROLE_LABELS.get(role, role or "group"), name))
        mapping[name] = match
    groups.bump(scene)
    return mapping, notes


def apply_show(scene, d, frame=None, replace=False):
    """Load a show. frame=None keeps saved positions; otherwise the show's first
    effect lands on the bar nearest `frame`. Returns (effects added, notes)."""
    s = scene.cuelight
    if replace:
        s.effects.clear()
        s.cues.clear()
    mapping, notes = resolve_groups(scene, d.get("groups", []))
    for gd in d.get("groups", []):
        target = mapping.get(gd["name"])
        if not target or target not in s.groups or target != gd["name"]:
            continue  # unmatched, or matched by role: keep the user's own group settings
        g = s.groups[target]
        for k in ("direction", "reverse", "seed", "expand_pixels"):
            if k in gd:
                setattr(g, k, gd[k])

    effects = d.get("effects", [])
    origin = min((e.get("start_beat", 0.0) for e in effects), default=0.0)
    if frame is None:
        base = 0.0
        origin = 0.0
    else:
        b = timing.beats_at(scene, s, frame)
        base = round(b / s.beats_per_bar) * s.beats_per_bar
    fpb = timing.frames_per_beat(scene, s)

    added, uids = 0, {}
    for i, ed in enumerate(effects):
        g = mapping.get(ed.get("group"))
        if not g or ed.get("type") not in registry.REGISTRY:
            continue
        start = s.beat_offset + (base + ed.get("start_beat", 0.0) - origin) * fpb
        e = effect_from_dict(scene, ed, g, start)
        uids[i] = e.uid
        added += 1
    if d.get("cues"):
        from ..cues.ops import add_cue
        for cd in d["cues"]:
            add_cue(scene, cd["name"], beat=base + cd.get("beat", 0.0) - origin,
                    uids=[uids[i] for i in cd.get("effects", []) if i in uids], fade=cd.get("fade", 0.0))
        s.use_cues = True
    live.refresh(scene)
    return added, notes


def builtin_shows():
    return list_presets(BUILTIN_DIR)

