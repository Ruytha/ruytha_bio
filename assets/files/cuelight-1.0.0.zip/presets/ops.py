import json
import os

import bpy
from bpy.props import EnumProperty, StringProperty
from bpy_extras.io_utils import ExportHelper, ImportHelper

from . import io

_MODES = (
    ('ADD', "At playhead", "Drop it in starting at the nearest bar"),
    ('REPLACE', "Replace show", "Clear the effect stack and cues, then load at the saved positions"),
)


def _load(op, context, path, mode):
    scene = context.scene
    try:
        d = io.read(path)
    except (OSError, ValueError) as ex:
        op.report({'ERROR'}, "Couldn't read %s: %s" % (os.path.basename(path), ex))
        return {'CANCELLED'}
    if d.get("kind") == "effect":
        from ..effects.ops import active_effect
        s = scene.cuelight
        group = s.groups[s.active_group].name if 0 <= s.active_group < len(s.groups) else ""
        io.apply_effect(scene, d, group)
        op.report({'INFO'}, "Added %s on %s" % (d.get("name", "effect"), group or "no group"))
        return {'FINISHED'}
    frame = None if mode == 'REPLACE' else scene.frame_current
    added, notes = io.apply_show(scene, d, frame=frame, replace=(mode == 'REPLACE'))
    msg = "%s: %d layer%s" % (d.get("name", "Show"), added, "" if added == 1 else "s")
    if notes:
        op.report({'WARNING'}, msg + ". " + "; ".join(notes))
    else:
        op.report({'INFO'}, msg)
    return {'FINISHED'}


class CUELIGHT_OT_preset_load(bpy.types.Operator):
    bl_idname = "cuelight.preset_load"
    bl_label = "Load preset"
    bl_options = {'REGISTER', 'UNDO'}

    path: StringProperty(options={'HIDDEN'})
    mode: EnumProperty(name="Load", items=_MODES, default='ADD')

    @classmethod
    def description(cls, context, props):
        try:
            with open(props.path, encoding="utf-8") as f:
                d = json.load(f)
            return d.get("description") or d.get("name", "Preset")
        except (OSError, ValueError):
            return "Load this preset"

    def execute(self, context):
        return _load(self, context, self.path, self.mode)


class CUELIGHT_OT_preset_import(bpy.types.Operator, ImportHelper):
    bl_idname = "cuelight.preset_import"
    bl_label = "Import preset"
    bl_description = "Load an effect or show preset from a JSON file"
    bl_options = {'REGISTER', 'UNDO'}

    filename_ext = ".json"
    filter_glob: StringProperty(default="*.json", options={'HIDDEN'})
    mode: EnumProperty(name="Load", items=_MODES, default='ADD')

    def execute(self, context):
        return _load(self, context, self.filepath, self.mode)


class CUELIGHT_OT_preset_save(bpy.types.Operator):
    bl_idname = "cuelight.preset_save"
    bl_label = "Save preset"
    bl_description = "Save to your preset library"
    bl_options = {'REGISTER'}

    kind: EnumProperty(items=(('SHOW', "Show", "Groups, every layer and the cues"),
                              ('EFFECT', "Effect", "The selected layer")))
    name: StringProperty(name="Name", default="My show")
    description_text: StringProperty(name="Description", default="")

    @classmethod
    def description(cls, context, props):
        return "Save the whole show to your library" if props.kind == 'SHOW' else "Save the selected layer to your library"

    def invoke(self, context, event):
        if self.kind == 'EFFECT':
            from ..effects.ops import active_effect
            e = active_effect(context)
            if e is None:
                self.report({'WARNING'}, "Select a layer first")
                return {'CANCELLED'}
            self.name = e.name
        return context.window_manager.invoke_props_dialog(self, title="Save %s preset" % self.kind.lower())

    def execute(self, context):
        if self.kind == 'EFFECT':
            from ..effects.ops import active_effect
            e = active_effect(context)
            if e is None:
                return {'CANCELLED'}
            path = io.save_effect(context.scene, e, self.name)
        else:
            path = io.save_show(context.scene, self.name, self.description_text)
        self.report({'INFO'}, "Saved %s" % os.path.basename(path))
        return {'FINISHED'}


class CUELIGHT_OT_preset_export(bpy.types.Operator, ExportHelper):
    bl_idname = "cuelight.preset_export"
    bl_label = "Export show"
    bl_description = "Write the whole show to a JSON file you can share"

    filename_ext = ".json"
    filter_glob: StringProperty(default="*.json", options={'HIDDEN'})

    def execute(self, context):
        name = os.path.splitext(os.path.basename(self.filepath))[0]
        io.write(self.filepath, io.show_to_dict(context.scene, name))
        self.report({'INFO'}, "Exported %s" % os.path.basename(self.filepath))
        return {'FINISHED'}


class CUELIGHT_OT_preset_folder(bpy.types.Operator):
    bl_idname = "cuelight.preset_folder"
    bl_label = "Open preset folder"
    bl_description = "Show your preset library in the file browser"

    def execute(self, context):
        bpy.ops.wm.path_open(filepath=os.path.dirname(io.library_dir("shows")))
        return {'FINISHED'}


class CUELIGHT_MT_show_presets(bpy.types.Menu):
    bl_idname = "CUELIGHT_MT_show_presets"
    bl_label = "Shows"

    def draw(self, context):
        layout = self.layout
        layout.label(text="Built in")
        for path, name, _ in io.builtin_shows():
            layout.operator("cuelight.preset_load", text=name).path = path
        mine = io.list_presets(io.library_dir("shows"))
        if mine:
            layout.separator()
            layout.label(text="Yours")
            for path, name, _ in mine:
                row = layout.row()
                op = row.operator("cuelight.preset_load", text=name)
                op.path, op.mode = path, 'REPLACE'
        layout.separator()
        layout.operator("cuelight.preset_import", text="Import…", icon='IMPORT')


class CUELIGHT_MT_effect_presets(bpy.types.Menu):
    bl_idname = "CUELIGHT_MT_effect_presets"
    bl_label = "Effects"

    def draw(self, context):
        layout = self.layout
        mine = io.list_presets(io.library_dir("effects"))
        if not mine:
            layout.label(text="Save a layer to start your library")
        for path, name, _ in mine:
            layout.operator("cuelight.preset_load", text=name).path = path


classes = (
    CUELIGHT_OT_preset_load,
    CUELIGHT_OT_preset_import,
    CUELIGHT_OT_preset_save,
    CUELIGHT_OT_preset_export,
    CUELIGHT_OT_preset_folder,
    CUELIGHT_MT_show_presets,
    CUELIGHT_MT_effect_presets,
)
