import bpy

from . import bake


def bake_range(scene):
    s = scene.cuelight
    if s.bake_range == 'PREVIEW' and scene.use_preview_range:
        return scene.frame_preview_start, scene.frame_preview_end
    if s.bake_range == 'EFFECTS':
        on = [e for e in s.effects if e.enabled]
        if on:
            return min(e.frame_start for e in on), max(e.frame_end for e in on)
    return scene.frame_start, scene.frame_end


class CUELIGHT_OT_bake(bpy.types.Operator):
    bl_idname = "cuelight.bake"
    bl_label = "Bake show"
    bl_description = ("Write every effect to keyframes, so renders, render farms and background "
                      "renders play the show without Cuelight")
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return len(context.scene.cuelight.effects) > 0

    def execute(self, context):
        scene = context.scene
        start, end = bake_range(scene)
        if end < start:
            self.report({'ERROR'}, "The bake range is empty")
            return {'CANCELLED'}
        wm = context.window_manager
        wm.progress_begin(0, end - start + 1)
        try:
            heads, keys = bake.bake(scene, start, end, progress=wm.progress_update,
                                    simplify=scene.cuelight.bake_simplify)
        finally:
            wm.progress_end()
        scene.cuelight.bake_keys = keys
        scene.frame_set(scene.frame_current)
        self.report({'INFO'}, "Baked frames %d-%d: %d heads, %d keyframes" % (start, end, heads, keys))
        return {'FINISHED'}


class CUELIGHT_OT_clear_bake(bpy.types.Operator):
    bl_idname = "cuelight.clear_bake"
    bl_label = "Clear bake"
    bl_description = "Remove Cuelight's keyframes and go back to live preview. Your own keyframes stay"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        n = bake.clear(context.scene)
        context.scene.cuelight.bake_keys = 0
        self.report({'INFO'}, "Removed %d baked curves" % n)
        return {'FINISHED'}


classes = (CUELIGHT_OT_bake, CUELIGHT_OT_clear_bake)
