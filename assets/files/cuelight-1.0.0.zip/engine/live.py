"""Live preview: write the evaluated stack onto fixture heads every frame.

Only values that changed are written, and only touched objects are tagged
for re-evaluation. A head an effect lets go of returns to its home values.
"""

import bpy
import numpy as np

from ..fixtures import build
from ..fixtures import schema as S
from . import timing
from .evaluate import PROPS, evaluate, home_key, home_props, shutter

# scene pointer -> {head pointer: (head, {props under effect control})}
_controlled = {}
# scene pointer -> (stamp, [every head in the scene])
_all_heads = {}


def clear_cache():
    _controlled.clear()
    _all_heads.clear()


def all_heads(scene):
    key = scene.as_pointer()
    stamp = (scene.cuelight.revision, len(bpy.data.objects))
    hit = _all_heads.get(key)
    if hit is not None and hit[0] == stamp:
        return hit[1]
    hs = []
    for root in S.fixtures_in(scene):
        hs.append(root)
        if root[S.TYPE] == 'LEDBAR':
            hs.extend(build.heads(root))
    _all_heads[key] = (stamp, hs)
    return hs


def _write(head, prop, value):
    cur = head.get(prop)
    if prop == S.COLOR:
        new = [float(x) for x in value]
        if cur is not None and all(abs(a - b) < 1e-6 for a, b in zip(cur, new)):
            return False
        head[prop] = new
        return True
    value = float(value)
    if cur is not None and abs(cur - value) < 1e-6:
        return False
    head[prop] = value
    return True


def snapshot(head, prop):
    k = home_key(prop)
    if k not in head:
        v = head.get(prop)
        head[k] = list(v) if prop == S.COLOR else v
        if prop in head:
            head.id_properties_ui(k).update_from(head.id_properties_ui(prop))


def _release(head, prop):
    k = home_key(prop)
    if k not in head:
        return False
    v = head[k]
    changed = _write(head, prop, v[:] if prop == S.COLOR else v)
    del head[k]
    return changed


def _previous(scene):
    """Heads under control last frame. After a reload or undo, rebuild from saved homes."""
    prev = _controlled.get(scene.as_pointer())
    if prev is None:
        prev = {}
        for h in all_heads(scene):
            held = home_props(h)
            if held:
                prev[h.as_pointer()] = (h, set(held))
    return prev


def apply(scene, frame=None):
    """Evaluate and write one frame."""
    if frame is None:
        frame = scene.frame_current + scene.frame_subframe
    res = evaluate(scene, frame)
    prev = _previous(scene)
    now, dirty = {}, {}

    for ch, vals in res.values.items():
        prop = PROPS[ch]
        for row in np.flatnonzero(res.touched[ch]):
            h = res.heads[row]
            snapshot(h, prop)
            if _write(h, prop, vals[row]):
                dirty[h.as_pointer()] = h
            now.setdefault(h.as_pointer(), (h, set()))[1].add(prop)

    for k, (h, props) in prev.items():
        keep = now[k][1] if k in now else set()
        try:
            for prop in props - keep:
                if _release(h, prop):
                    dirty[k] = h
        except ReferenceError:
            pass  # deleted since last frame
    _controlled[scene.as_pointer()] = now

    seconds = frame / timing.fps(scene)
    fps = timing.fps(scene)
    for h in all_heads(scene):
        s = shutter(h.get(S.STROBE, 0.0), seconds, fps)
        if h.get(S.SHUTTER, 1.0) != s:
            h[S.SHUTTER] = s
            dirty[h.as_pointer()] = h

    for h in dirty.values():
        h.update_tag()
    return res


def release_all(scene):
    """Hand every head back its home values (live preview off)."""
    for h in all_heads(scene):
        held = home_props(h)
        if held:
            for prop in held:
                _release(h, prop)
            h.update_tag()
        if h.get(S.SHUTTER, 1.0) != 1.0:
            h[S.SHUTTER] = 1.0
            h.update_tag()
    _controlled[scene.as_pointer()] = {}


def is_live(scene):
    s = scene.cuelight
    return s.live_preview and not s.baked


def refresh(scene):
    """Re-apply the current frame after an edit, so changes show without scrubbing."""
    if scene is not None and is_live(scene):
        apply(scene)
