"""Bake the show to keyframes, so renders never depend on Python.

The same evaluator as live preview runs for every frame in the range; the
results are written to F-curves on each head's control properties in bulk.
Baked F-curves sit in an F-curve group named "Cuelight", so Clear Bake removes
exactly those and leaves any animation of your own alone.
"""

import bpy
import numpy as np

from ..fixtures import schema as S
from . import live, timing
from .evaluate import PROPS, evaluate, home_value, shutter

GROUP = "Cuelight"
_CONSTANT, _LINEAR = 0, 1  # Keyframe.interpolation enum values


def _channelbag(obj):
    """The channelbag for obj's action slot, creating action, slot, layer and strip as needed."""
    ad = obj.animation_data or obj.animation_data_create()
    act = ad.action
    if act is None:
        act = bpy.data.actions.new("CL " + obj.name)
        act["cl_bake"] = 1
        ad.action = act
    if ad.action_slot is None:
        ad.action_slot = act.slots.new(id_type='OBJECT', name=obj.name)
    if len(act.layers) == 0:
        act.layers.new("Layer")
    layer = act.layers[0]
    strip = layer.strips[0] if len(layer.strips) else layer.strips.new(type='KEYFRAME')
    return strip.channelbag(ad.action_slot, ensure=True)


def _group(cb, create=False):
    g = next((g for g in cb.groups if g.name == GROUP), None)
    if g is None and create:
        g = cb.groups.new(GROUP)
    return g


def _existing_channelbag(obj):
    ad = obj.animation_data
    if ad is None or ad.action is None or ad.action_slot is None:
        return None
    for layer in ad.action.layers:
        for strip in layer.strips:
            cb = strip.channelbag(ad.action_slot)
            if cb is not None:
                return cb
    return None


def clear_head(obj):
    """Remove Cuelight's F-curves from one object. Returns how many went."""
    cb = _existing_channelbag(obj)
    if cb is None:
        return 0
    ours = [fc for fc in cb.fcurves if fc.group is not None and fc.group.name == GROUP]
    for fc in ours:
        cb.fcurves.remove(fc)
    grp = _group(cb)
    if grp is not None and not any(fc.group == grp for fc in cb.fcurves):
        cb.groups.remove(grp)
    act = obj.animation_data.action
    if act.get("cl_bake") and len(cb.fcurves) == 0:
        obj.animation_data.action = None
        if act.users == 0:
            bpy.data.actions.remove(act)
    return len(ours)


# Largest error simplification may leave, per property. Well under anything visible.
TOLERANCE = {S.INTENSITY: 0.002, S.COLOR: 0.002, S.PAN: 0.05, S.TILT: 0.05, S.ZOOM: 0.002, S.STROBE: 0.01}


def _steps_mask(values):
    """For constant interpolation: a key wherever the value changes."""
    keep = np.ones(len(values), dtype=bool)
    keep[1:] = values[1:] != values[:-1]
    keep[-1] = True
    return keep


def _simplify_mask(frames, values, tol):
    """Ramer-Douglas-Peucker: the fewest keys whose straight lines stay within tol
    of every sampled frame. tol = 0 still drops the middle of flat runs."""
    n = len(values)
    keep = np.zeros(n, dtype=bool)
    keep[0] = keep[-1] = True
    stack = [(0, n - 1)]
    while stack:
        a, b = stack.pop()
        if b - a < 2:
            continue
        t = (frames[a + 1:b] - frames[a]) / (frames[b] - frames[a])
        d = np.abs(values[a + 1:b] - (values[a] + (values[b] - values[a]) * t))
        i = int(np.argmax(d))
        if d[i] > tol:
            m = a + 1 + i
            keep[m] = True
            stack.append((a, m))
            stack.append((m, b))
    return keep


def _write_curve(cb, group, path, index, frames, values, interpolation, tol):
    if interpolation == _CONSTANT:
        keep = _steps_mask(values)
    else:
        keep = _simplify_mask(frames, values, tol)
    f, v = frames[keep], values[keep]
    fc = cb.fcurves.new(path, index=index)
    fc.group = group
    fc.keyframe_points.add(len(f))
    co = np.empty(len(f) * 2, dtype=np.float32)
    co[0::2], co[1::2] = f, v
    fc.keyframe_points.foreach_set("co", co)
    fc.keyframe_points.foreach_set("interpolation", np.full(len(f), interpolation, dtype=np.int32))
    fc.update()
    return len(f)


def sample(scene, frames, progress=None):
    """Evaluate every frame. Returns {head pointer: (head, {prop: (frames x width) array})}.

    A channel is included for a head if any layer touched it in the range;
    frames where nothing touched it hold the head's home value.
    """
    per_frame = []
    heads = {}
    for i, f in enumerate(frames):
        res = evaluate(scene, f)
        per_frame.append(res)
        for ch, mask in res.touched.items():
            for row in np.flatnonzero(mask):
                h = res.heads[row]
                heads.setdefault(h.as_pointer(), (h, set()))[1].add(ch)
        if progress:
            progress(i)

    out = {}
    nf = len(frames)
    for k, (h, chans) in heads.items():
        data = {}
        for ch in chans:
            prop = PROPS[ch]
            home = np.asarray(home_value(h, prop), dtype=float)
            arr = np.empty((nf, 3) if ch == "color" else (nf,), dtype=float)
            arr[:] = home
            data[prop] = arr
        out[k] = (h, data)

    for i, res in enumerate(per_frame):
        for ch, mask in res.touched.items():
            prop = PROPS[ch]
            vals = res.values[ch]
            for row in np.flatnonzero(mask):
                out[res.heads[row].as_pointer()][1][prop][i] = vals[row]
    return out


def bake(scene, frame_start, frame_end, progress=None, simplify=True):
    """Bake frames [start, end]. Returns (heads keyed, keyframes written).

    simplify: drop keys a straight line can stand in for (see TOLERANCE).
    Off, only the middle of perfectly flat runs is dropped.
    """
    live.release_all(scene)  # homes back on the props, so untouched frames bake correctly
    clear(scene, refresh=False)
    frames = np.arange(int(frame_start), int(frame_end) + 1, dtype=float)
    data = sample(scene, frames, progress)

    # Shutter: from baked strobe values, or a head's own strobe setting
    fps = timing.fps(scene)
    secs = frames / fps
    for h in live.all_heads(scene):
        k = h.as_pointer()
        strobe = data.get(k, (h, {}))[1].get(S.STROBE)
        if strobe is None:
            hz = float(h.get(S.STROBE, 0.0))
            if hz <= 0:
                continue
            strobe = np.full(len(frames), hz)
        if not np.any(strobe > 0):
            continue
        shut = np.array([shutter(hz, t, fps) for hz, t in zip(strobe, secs)])
        data.setdefault(k, (h, {}))[1][S.SHUTTER] = shut

    keys = 0
    for h, props in data.values():
        cb = _channelbag(h)
        group = _group(cb, create=True)
        for prop, arr in props.items():
            # Remember the home look, so Clear Bake can put it back
            if prop != S.SHUTTER:
                live.snapshot(h, prop)
            path = '["%s"]' % prop
            interp = _CONSTANT if prop == S.SHUTTER else _LINEAR
            tol = TOLERANCE.get(prop, 0.0) if simplify else 0.0
            if arr.ndim == 2:
                for c in range(arr.shape[1]):
                    keys += _write_curve(cb, group, path, c, frames, arr[:, c], interp, tol)
            else:
                keys += _write_curve(cb, group, path, 0, frames, arr, interp, tol)
        h.update_tag()

    s = scene.cuelight
    s.baked = True
    s.bake_start, s.bake_end = int(frame_start), int(frame_end)
    return len(data), keys


def clear(scene, refresh=True):
    """Remove every baked F-curve and hand the show back to live preview."""
    removed = 0
    for h in live.all_heads(scene):
        removed += clear_head(h)
        h.update_tag()
    live.release_all(scene)  # baked values stay on the props otherwise
    scene.cuelight.baked = False
    if refresh:
        live.refresh(scene)
    return removed
