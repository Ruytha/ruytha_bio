import bpy
from bpy.app.handlers import persistent

from ..audio import analysis
from ..groups import core as groups
from . import live, ops


@persistent
def _on_frame(scene, depsgraph=None):
    if hasattr(scene, "cuelight") and live.is_live(scene):
        live.apply(scene)


@persistent
def _on_reload(*_args):
    # Object references don't survive undo or file load
    live.clear_cache()
    groups.clear_cache()
    analysis.clear_cache()


_HANDLERS = (
    (bpy.app.handlers.frame_change_pre, _on_frame),
    (bpy.app.handlers.load_post, _on_reload),
    (bpy.app.handlers.undo_post, _on_reload),
    (bpy.app.handlers.redo_post, _on_reload),
)


def register():
    for c in ops.classes:
        bpy.utils.register_class(c)
    for lst, fn in _HANDLERS:
        if fn not in lst:
            lst.append(fn)


def unregister():
    for lst, fn in _HANDLERS:
        while fn in lst:
            lst.remove(fn)
    for c in reversed(ops.classes):
        bpy.utils.unregister_class(c)
    live.clear_cache()
    groups.clear_cache()
