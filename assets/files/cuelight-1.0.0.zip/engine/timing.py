"""Time in seconds, beats and effect cycles."""


def fps(scene):
    return scene.render.fps / scene.render.fps_base


def seconds_per_beat(settings):
    return 60.0 / max(settings.bpm, 1e-6)


def frames_per_beat(scene, settings):
    return fps(scene) * seconds_per_beat(settings)


def beats_at(scene, settings, frame):
    """Song position in beats; 0 at the beat offset."""
    return (frame - settings.beat_offset) / frames_per_beat(scene, settings)


def cycle_seconds(settings, effect):
    s = max(effect.speed, 1e-6)
    if effect.speed_unit == 'HZ':
        return 1.0 / s
    if effect.speed_unit == 'BEATS':
        return s * seconds_per_beat(settings)
    return s


def cycles(scene, settings, effect, frame):
    """Cycles elapsed for an effect at a frame.

    Beat-locked effects count from the song's beat 1, so a chase that starts
    mid-bar still lands on the grid. Seconds and Hz count from the effect start.
    """
    if effect.speed_unit == 'BEATS':
        return beats_at(scene, settings, frame) / max(effect.speed, 1e-6)
    return (frame - effect.frame_start) / fps(scene) / cycle_seconds(settings, effect)


def frame_step(scene, settings, effect):
    """One frame, measured in cycles of this effect."""
    return 1.0 / (fps(scene) * cycle_seconds(settings, effect))


def envelope(scene, settings, effect, frame):
    """Fade-in / fade-out multiplier, 0..1."""
    f = fps(scene)
    unit = seconds_per_beat(settings) if effect.fade_unit == 'BEATS' else 1.0
    w = 1.0
    if effect.fade_in > 0:
        w = min(w, (frame - effect.frame_start) / f / (effect.fade_in * unit))
    if effect.fade_out > 0:
        w = min(w, (effect.frame_end - frame) / f / (effect.fade_out * unit))
    return max(0.0, min(1.0, w))
