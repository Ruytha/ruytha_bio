"""The layer stack: active effects -> per-head channel values.

Pure computation, no scene writes, so live preview and bake share it.
"""

import numpy as np

from ..audio import modulate
from ..cues.core import gate as cue_gate
from ..effects import registry
from ..effects.params import Params
from ..fixtures import schema as S
from ..groups import core as groups
from . import timing

PROPS = {
    "intensity": S.INTENSITY,
    "color": S.COLOR,
    "pan": S.PAN,
    "tilt": S.TILT,
    "zoom": S.ZOOM,
    "strobe": S.STROBE,
}
LIMITS = {"intensity": (0.0, 10.0), "color": (0.0, 1.0), "zoom": (0.0, 1.0), "strobe": (0.0, None)}
# A head under effect control keeps the value it returns to when effects let
# go as a flat property, e.g. cl_intensity -> cl_home_intensity. Flat, so the
# UI can draw and edit it like any other property.
HOME = "cl_home_"


def home_key(prop):
    return HOME + prop[len("cl_"):]


def home_props(head):
    """Channel properties of a head currently held by effects."""
    return ["cl_" + k[len(HOME):] for k in head.keys() if k.startswith(HOME)]


class Result:
    """heads: objects; values[ch]: array over heads; touched[ch]: bool mask."""

    def __init__(self, heads):
        self.heads = heads
        self.values = {}
        self.touched = {}


def home_value(head, prop):
    k = home_key(prop)
    v = head[k] if k in head else head.get(prop)
    if v is None:
        return (1.0, 1.0, 1.0) if prop == S.COLOR else 0.0
    return v[:] if prop == S.COLOR else v


def blend(mode, below, value, w):
    if below.ndim == 2:
        w = w[:, None]
    if mode == 'ADD':
        return below + value * w
    if mode == 'MULTIPLY':
        return below * (1.0 - w + value * w)
    if mode == 'MAX':
        return np.maximum(below, value * w)
    return below + (value - below) * w


def active_layers(scene, frame, gates=None):
    """(effect, effect type, group, cue weight) for every layer playing at this
    frame, bottom first. gates: from cues.gate(); None when cues are off."""
    settings = scene.cuelight
    out = []
    for e in settings.effects:
        if not e.enabled or not (e.frame_start <= frame <= e.frame_end):
            continue
        et = registry.get(e.effect_type)
        g = settings.groups.get(e.group)
        if et is None or g is None:
            continue
        cw = 1.0
        if gates is not None:
            cw = gates.get(e.uid, 0.0)
            if cw <= 0.0:
                continue
        out.append((e, et, g, cw))
    return out


def _show_groups(settings):
    """Every group an enabled effect plays on."""
    names = []
    for e in settings.effects:
        if e.enabled and e.group in settings.groups and e.group not in names:
            names.append(e.group)
    return [settings.groups[n] for n in names]


def evaluate(scene, frame):
    settings = scene.cuelight
    gates = cue_gate(scene, frame)
    layers = active_layers(scene, frame, gates)

    heads, rows = [], {}

    def rows_for(g):
        r = []
        for h in groups.heads(scene, g):
            k = h.as_pointer()
            if k not in rows:
                rows[k] = len(heads)
                heads.append(h)
            r.append(rows[k])
        return np.array(r, dtype=int)

    layer_rows = [rows_for(g) for _, _, g, _ in layers]
    # With cues on, the stage is dark unless the current cue lights it: every
    # head the show uses is held at black intensity, playing or not
    dark_rows = [rows_for(g) for g in _show_groups(settings)] if gates is not None else []

    res = Result(heads)
    count = len(heads)
    if count == 0:
        return res

    def channel(ch):
        if ch not in res.values:
            if ch == "intensity":
                # Like a console: once effects drive intensity, the stack starts from
                # black, so a layer fading out (or ducked by audio) goes dark rather
                # than revealing the fixture's own level. Colour and position still
                # start from the head's home values.
                res.values[ch] = np.zeros(count)
            else:
                prop = PROPS[ch]
                vals = [home_value(h, prop) for h in heads]
                res.values[ch] = np.array(vals, dtype=float).reshape(count, 3 if ch == "color" else 1)
                if ch != "color":
                    res.values[ch] = res.values[ch][:, 0]
            res.touched[ch] = np.zeros(count, dtype=bool)
        return res.values[ch]

    for rws in dark_rows:
        channel("intensity")
        res.touched["intensity"][rws] = True

    f = timing.fps(scene)
    for (e, et, g, cw), rws in zip(layers, layer_rows):
        if len(rws) == 0:
            continue
        # A playing layer keeps its channels even at zero opacity (start of a fade,
        # ducked by audio): it adds nothing, but the heads stay under effect control.
        w = e.opacity * timing.envelope(scene, settings, e, frame) * cw
        if e.direction == 'GROUP':
            idx, n = groups.index_map(len(rws), g.direction, g.reverse, g.seed)
        else:
            idx, n = groups.index_map(len(rws), e.direction, g.reverse, e.seed)
        t = timing.cycles(scene, settings, e, frame)
        p = Params(e, et, timing.frame_step(scene, settings, e), (frame - e.frame_start) / f, frame)
        if len(e.modulators):
            w, t = modulate.apply(scene, e, frame, w, t, p)
        out = et.fn(idx, n, t, p)

        wv = np.full(len(rws), w)
        if "alpha" in out:
            wv = wv * np.broadcast_to(np.asarray(out["alpha"], dtype=float), (len(rws),))
        for ch, v in out.items():
            if ch not in PROPS:
                continue
            shape = (len(rws), 3) if ch == "color" else (len(rws),)
            v = np.broadcast_to(np.asarray(v, dtype=float), shape)
            arr = channel(ch)
            arr[rws] = blend(e.blend, arr[rws], v, wv)
            res.touched[ch][rws] = True

    for ch, (lo, hi) in LIMITS.items():
        if ch in res.values:
            np.clip(res.values[ch], lo, hi, out=res.values[ch])
    return res


def shutter(hz, seconds, fps):
    """Fixture shutter for a strobe rate: 1 open, 0 closed. Always shows at least one frame."""
    if hz <= 0.0:
        return 1.0
    step = hz / fps  # cycles per frame
    if step >= 0.5:
        return 1.0 if round(seconds * fps) % 2 == 0 else 0.0
    ph = seconds * hz
    return 1.0 if ph - np.floor(ph) < max(0.3, step * 1.01) else 0.0
