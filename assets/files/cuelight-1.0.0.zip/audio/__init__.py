import bpy


def register():
    from . import metronome, ops
    for c in ops.classes:
        bpy.utils.register_class(c)
    metronome.register()


def unregister():
    from . import metronome, ops
    metronome.unregister()
    for c in reversed(ops.classes):
        bpy.utils.unregister_class(c)
