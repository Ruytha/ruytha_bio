"""Audio analysis with numpy only: bands per video frame, and a tempo estimate.

Results are stored on the scene (scene["cl_audio"]) so they save with the
.blend and bake / render without the audio file present.
"""

import numpy as np

from ..engine import timing
from . import loader

KEY = "cl_audio"
BANDS = (
    ('BASS', "Bass", "20 to 150 Hz: kick and bass"),
    ('MID', "Mid", "150 Hz to 2 kHz: vocals, snare body, keys"),
    ('HIGH', "High", "2 to 16 kHz: hats, cymbals, air"),
    ('ENERGY', "Energy", "Overall loudness"),
)
RANGES = {'BASS': (20.0, 150.0), 'MID': (150.0, 2000.0), 'HIGH': (2000.0, 16000.0)}

_cache = {}  # (scene pointer, stamp) -> {band: array}; smoothed envelopes keyed further


def clear_cache():
    _cache.clear()


def _windows(x, centres, win):
    """Frames of length win centred on sample positions, zero-padded at the ends."""
    pad = win // 2
    xp = np.concatenate([np.zeros(pad, np.float32), x, np.zeros(pad + 1, np.float32)])
    idx = centres[:, None] + np.arange(win)[None, :]
    return xp[np.clip(idx, 0, len(xp) - 1)]


def _normalise(v):
    """Log-compress, then map the 5th..99.5th percentile to 0..1."""
    db = 10.0 * np.log10(v + 1e-12)
    lo, hi = np.percentile(db, 5), np.percentile(db, 99.5)
    if hi - lo < 1e-6:
        return np.zeros_like(db)
    return np.clip((db - lo) / (hi - lo), 0.0, 1.0)


def band_curves(x, rate, frames, fps, win=4096, chunk=512):
    """Per-frame band powers for `frames` video frames starting at sample 0."""
    centres = (np.arange(frames) * rate / fps).astype(np.int64)
    freqs = np.fft.rfftfreq(win, 1.0 / rate)
    masks = {b: (freqs >= lo) & (freqs < hi) for b, (lo, hi) in RANGES.items()}
    window = np.hanning(win).astype(np.float32)
    out = {b: np.zeros(frames) for b in ('BASS', 'MID', 'HIGH', 'ENERGY')}
    onset = np.zeros(frames)
    audible = freqs < 16000.0
    prev = None
    for s in range(0, frames, chunk):
        block = _windows(x, centres[s:s + chunk], win)
        out['ENERGY'][s:s + chunk] = np.mean(block * block, axis=1)
        power = np.abs(np.fft.rfft(block * window, axis=1)) ** 2
        for b, m in masks.items():
            out[b][s:s + chunk] = power[:, m].sum(axis=1)
        # Onset strength: spectral flux, the new energy arriving each frame
        logp = np.log1p(power[:, audible] * 1e3)
        before = np.vstack([logp[:1] if prev is None else prev[None, :], logp[:-1]])
        onset[s:s + chunk] = np.maximum(logp - before, 0).sum(axis=1)
        prev = logp[-1]
    curves = {b: _normalise(v) for b, v in out.items()}
    top = np.percentile(onset, 99) if np.any(onset > 0) else 1.0
    curves['ONSET'] = np.clip(onset / max(top, 1e-9), 0.0, 1.0)
    return curves


def analyze(scene, strip=None):
    """Analyse the song strip. Returns the number of frames analysed."""
    strip = strip or loader.song_strip(scene)
    if strip is None:
        raise RuntimeError("No song loaded")
    x, rate = loader.samples(strip)
    fps = timing.fps(scene)
    # The strip may be trimmed: start reading where its visible part starts
    skip = int(round((strip.frame_final_start - strip.frame_start) / fps * rate))
    x = x[max(skip, 0):]
    frames = int(strip.frame_final_duration)
    curves = band_curves(x, rate, frames, fps)
    scene[KEY] = {
        "stamp": int(np.random.default_rng().integers(1, 2**31 - 1)),
        "start": int(strip.frame_final_start),
        "fps": float(fps),
        "frames": frames,
        **{b.lower(): curves[b].astype(np.float32).tolist() for b in curves},
    }
    clear_cache()
    return frames


def has_analysis(scene):
    return KEY in scene


def _curves(scene):
    data = scene.get(KEY)
    if data is None:
        return None
    k = scene.as_pointer()
    stamp = data.get("stamp")
    hit = _cache.get(k)
    if hit is not None and hit[0] == stamp:
        return hit[1]
    curves = {"start": data["start"], "smoothed": {}}
    for b in [k for k, _, _ in BANDS] + ['ONSET']:
        if b.lower() in data:
            curves[b] = np.asarray(data[b.lower()], dtype=np.float64)
    _cache[k] = (stamp, curves)
    return curves


def envelope(scene, band, attack=0.0, release=0.0):
    """(start frame, array) for a band, with attack/release smoothing in seconds."""
    c = _curves(scene)
    if c is None:
        return None, None
    key = (band, round(attack, 4), round(release, 4))
    sm = c["smoothed"].get(key)
    if sm is None:
        raw = c[band]
        if attack <= 0 and release <= 0:
            sm = raw
        else:
            fps = timing.fps(scene)
            up = np.exp(-1.0 / (fps * attack)) if attack > 0 else 0.0
            down = np.exp(-1.0 / (fps * release)) if release > 0 else 0.0
            sm = np.empty_like(raw)
            y = 0.0
            for i, v in enumerate(raw):
                k = up if v > y else down
                y = v + (y - v) * k
                sm[i] = y
        c["smoothed"][key] = sm
    return c["start"], sm
