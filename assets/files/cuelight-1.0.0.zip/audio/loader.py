"""The song: a sound strip in the scene's sequencer, and its samples."""

import os
import tempfile

import aud
import bpy
import numpy as np

SONG = "cl_song"  # marks the strip Cuelight treats as the song


def _strips(scene):
    se = scene.sequence_editor
    if se is None:
        return None
    return se.strips if hasattr(se, "strips") else se.sequences


def song_strip(scene):
    coll = _strips(scene)
    if coll is None:
        return None
    for s in coll:
        if s.type == 'SOUND' and s.get(SONG):
            return s
    return None


def load(scene, filepath, frame_start=1, fit_scene=True):
    """Add (or replace) the song strip. Returns the strip."""
    se = scene.sequence_editor_create()
    coll = se.strips if hasattr(se, "strips") else se.sequences
    old = song_strip(scene)
    channel = old.channel if old else 1
    if old is not None:
        coll.remove(old)
    used = {s.channel for s in coll if s.frame_final_start <= frame_start < s.frame_final_end}
    while channel in used:
        channel += 1
    strip = coll.new_sound(os.path.splitext(os.path.basename(filepath))[0], filepath, channel, frame_start)
    strip[SONG] = 1
    scene.sync_mode = 'AUDIO_SYNC'  # keep light and sound together during playback
    scene.use_audio_scrub = True
    if fit_scene:
        scene.frame_start = strip.frame_final_start
        scene.frame_end = strip.frame_final_end - 1
    return strip


def trim(scene, strip, start_seconds, length_seconds, at_frame=1):
    """Play only part of the song: `length_seconds` from `start_seconds`, starting at `at_frame`."""
    from ..engine import timing
    fps = timing.fps(scene)
    off = int(round(start_seconds * fps))
    length = max(1, int(round(length_seconds * fps)))
    total = strip.frame_duration
    strip.frame_offset_start = 0
    strip.frame_offset_end = 0
    strip.frame_start = at_frame - off
    strip.frame_offset_start = off
    strip.frame_offset_end = max(0, total - off - length)
    return strip


def samples(strip):
    """(mono float32 samples, sample rate) for the strip's sound, packed or on disk."""
    snd = strip.sound
    path = bpy.path.abspath(snd.filepath, library=snd.library)
    tmp = None
    if snd.packed_file is not None:
        ext = os.path.splitext(snd.filepath)[1] or ".wav"
        fd, tmp = tempfile.mkstemp(suffix=ext)
        with os.fdopen(fd, "wb") as f:
            f.write(snd.packed_file.data)
        path = tmp
    try:
        a = aud.Sound(path)
        rate = int(a.specs[0])
        data = a.data()
    finally:
        if tmp:
            os.unlink(tmp)
    mono = data.mean(axis=1) if data.ndim == 2 else data
    return np.ascontiguousarray(mono, dtype=np.float32), rate
