import bpy
from bpy.props import BoolProperty, FloatProperty, IntProperty, StringProperty
from bpy_extras.io_utils import ImportHelper

from ..engine import live
from . import analysis, beat, loader, metronome, tempo


def _apply_detection(scene, r):
    s = scene.cuelight
    s.bpm = r["bpm"]
    s.beat_offset = round(r["first"], 2)


def _verdict(r):
    if r["confidence"] >= beat.SURE:
        return "Locked at %.1f BPM (%d%% sure)" % (r["bpm"], round(r["confidence"] * 100))
    return "Check by ear: about %.1f BPM, only %d%% sure" % (r["bpm"], round(r["confidence"] * 100))


class CUELIGHT_OT_load_song(bpy.types.Operator, ImportHelper):
    bl_idname = "cuelight.load_song"
    bl_label = "Load song"
    bl_description = "Put a song in the sequencer, analyse it and estimate its tempo"
    bl_options = {'REGISTER', 'UNDO'}

    filter_glob: StringProperty(default="*.wav;*.mp3;*.ogg;*.flac;*.m4a;*.aac;*.aif;*.aiff", options={'HIDDEN'})
    fit_scene: BoolProperty(name="Fit scene to song", default=True,
                            description="Set the scene's start and end to the song")
    analyze: BoolProperty(name="Analyse", default=True, description="Split the song into bass, mid and high")
    detect: BoolProperty(name="Detect tempo", default=True, description="Estimate BPM and beat 1")

    def execute(self, context):
        scene = context.scene
        try:
            strip = loader.load(scene, self.filepath, frame_start=scene.frame_start, fit_scene=self.fit_scene)
        except Exception as ex:  # unreadable file, unsupported codec
            self.report({'ERROR'}, "Couldn't load that file: %s" % ex)
            return {'CANCELLED'}
        msg = "Loaded %s" % strip.name
        if self.analyze or self.detect:
            analysis.analyze(scene, strip)  # the grid fit and song strip need it too
        unsure = False
        if self.detect:
            r = beat.detect(scene)
            _apply_detection(scene, r)
            msg += ". " + _verdict(r)
            unsure = r["confidence"] < beat.SURE
        metronome.sync(scene)  # follows the new song, or clears the old song's clicks
        live.refresh(scene)
        self.report({'WARNING'} if unsure else {'INFO'}, msg)
        if unsure and context.window is not None:
            # Not sure of the tempo: open the editor straight away
            bpy.ops.cuelight.bpm_editor('INVOKE_DEFAULT')
        return {'FINISHED'}


class _NeedsSong:
    @classmethod
    def poll(cls, context):
        return loader.song_strip(context.scene) is not None


class CUELIGHT_OT_analyze_audio(_NeedsSong, bpy.types.Operator):
    bl_idname = "cuelight.analyze_audio"
    bl_label = "Analyse"
    bl_description = "Split the song into bass, mid, high and overall energy, frame by frame"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        n = analysis.analyze(context.scene)
        live.refresh(context.scene)
        self.report({'INFO'}, "Analysed %d frames" % n)
        return {'FINISHED'}


class CUELIGHT_OT_detect_bpm(_NeedsSong, bpy.types.Operator):
    bl_idname = "cuelight.detect_bpm"
    bl_label = "Detect"
    bl_description = "Estimate the tempo and where beat 1 falls"
    bl_options = {'REGISTER', 'UNDO'}

    section: BoolProperty(name="Preview range only", default=False,
                          description="Listen only inside the preview range, for songs whose intro has no clear beat")

    @classmethod
    def description(cls, context, props):
        if props.section:
            return "Detect from the preview range only. Use it when the intro has no clear beat"
        return cls.bl_description

    def execute(self, context):
        scene = context.scene
        if self.section and not scene.use_preview_range:
            self.report({'WARNING'}, "Set a preview range on the timeline first")
            return {'CANCELLED'}
        if not analysis.has_analysis(scene):
            analysis.analyze(scene)
        r = beat.detect(scene, section=self.section)
        _apply_detection(scene, r)
        self.report({'INFO'} if r["confidence"] >= beat.SURE else {'WARNING'}, _verdict(r))
        return {'FINISHED'}


class CUELIGHT_OT_pick_tempo(bpy.types.Operator):
    bl_idname = "cuelight.pick_tempo"
    bl_label = "Use this tempo"
    bl_description = "Switch to this tempo and line the grid up with the song"
    bl_options = {'REGISTER', 'UNDO', 'INTERNAL'}

    bpm: FloatProperty()

    def execute(self, context):
        s = context.scene.cuelight
        s.bpm = self.bpm
        f = beat.fit_offset(context.scene, self.bpm)
        if f is not None:
            s.beat_offset = f
        return {'FINISHED'}


class CUELIGHT_OT_bpm_adjust(bpy.types.Operator):
    bl_idname = "cuelight.bpm_adjust"
    bl_label = "Adjust BPM"
    bl_description = "Change the tempo"
    bl_options = {'REGISTER', 'UNDO', 'INTERNAL'}

    mode: bpy.props.EnumProperty(items=(('ADD', "Add", ""), ('MUL', "Multiply", "")))
    value: FloatProperty()

    @classmethod
    def description(cls, context, props):
        if props.mode == 'MUL':
            return "Double time" if props.value > 1 else "Half time"
        return "%+g BPM" % props.value

    def execute(self, context):
        s = context.scene.cuelight
        v = s.bpm * self.value if self.mode == 'MUL' else s.bpm + self.value
        s.bpm = round(min(max(v, 20.0), 400.0), 2)
        return {'FINISHED'}


class CUELIGHT_OT_beat_shift(bpy.types.Operator):
    bl_idname = "cuelight.beat_shift"
    bl_label = "Shift grid by a beat"
    bl_description = "Move beat 1 a whole beat, when the grid fits but the downbeat is wrong"
    bl_options = {'REGISTER', 'UNDO', 'INTERNAL'}

    beats: FloatProperty(default=1.0)

    def execute(self, context):
        from ..engine import timing
        s = context.scene.cuelight
        s.beat_offset += self.beats * timing.frames_per_beat(context.scene, s)
        return {'FINISHED'}


class CUELIGHT_OT_fit_grid(_NeedsSong, bpy.types.Operator):
    bl_idname = "cuelight.fit_grid"
    bl_label = "Fit grid"
    bl_description = "Keep the BPM, and slide beat 1 so the grid sits on the song's hits"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        scene = context.scene
        if not analysis.has_analysis(scene):
            analysis.analyze(scene)
        f = beat.fit_offset(scene)
        if f is None:
            return {'CANCELLED'}
        scene.cuelight.beat_offset = f
        self.report({'INFO'}, "Beat 1 at frame %.2f" % f)
        return {'FINISHED'}


class CUELIGHT_OT_bpm_editor(bpy.types.Operator):
    bl_idname = "cuelight.bpm_editor"
    bl_label = "BPM editor"
    bl_description = "Check and fix the tempo and beat grid against the song"

    def invoke(self, context, event):
        return context.window_manager.invoke_popup(self, width=420)

    def draw(self, context):
        from ..ui.bpm_editor import draw_bpm_editor
        draw_bpm_editor(self.layout, context)

    def execute(self, context):
        return {'FINISHED'}


class CUELIGHT_OT_tap_tempo(bpy.types.Operator):
    bl_idname = "cuelight.tap_tempo"
    bl_label = "Tap"
    bl_description = "Click in time with the music. Three taps set the BPM; pause two seconds to start over"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        bpm, n = tempo.tap()
        if bpm is None:
            self.report({'INFO'}, "Tap %d" % n)
            return {'FINISHED'}
        context.scene.cuelight.bpm = min(max(bpm, 20.0), 400.0)
        self.report({'INFO'}, "Tap %d: %.1f BPM" % (n, bpm))
        return {'FINISHED'}


class CUELIGHT_OT_beat_here(bpy.types.Operator):
    bl_idname = "cuelight.beat_here"
    bl_label = "Beat 1 here"
    bl_description = "Make the current frame beat 1 of a bar"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        context.scene.cuelight.beat_offset = context.scene.frame_current
        return {'FINISHED'}


class CUELIGHT_OT_beat_nudge(bpy.types.Operator):
    bl_idname = "cuelight.beat_nudge"
    bl_label = "Nudge"
    bl_description = "Shift the beat grid"
    bl_options = {'REGISTER', 'UNDO'}

    frames: FloatProperty(default=1.0)

    def execute(self, context):
        context.scene.cuelight.beat_offset += self.frames
        return {'FINISHED'}


class CUELIGHT_OT_speed_preset(bpy.types.Operator):
    bl_idname = "cuelight.speed_preset"
    bl_label = "Speed"
    bl_description = "Lock the effect's cycle to this many beats"
    bl_options = {'REGISTER', 'UNDO', 'INTERNAL'}

    beats: FloatProperty()

    def execute(self, context):
        from ..effects.ops import active_effect
        e = active_effect(context)
        if e is None:
            return {'CANCELLED'}
        e.speed_unit = 'BEATS'
        e.speed = self.beats
        return {'FINISHED'}


class CUELIGHT_OT_modulator_add(bpy.types.Operator):
    bl_idname = "cuelight.modulator_add"
    bl_label = "Add audio link"
    bl_description = "Let a band of the song drive this effect"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        from ..effects.ops import active_effect
        e = active_effect(context)
        if e is None:
            return {'CANCELLED'}
        e.modulators.add()
        if not analysis.has_analysis(context.scene):
            self.report({'WARNING'}, "Analyse a song in 04 Music first")
        live.refresh(context.scene)
        return {'FINISHED'}


class CUELIGHT_OT_modulator_remove(bpy.types.Operator):
    bl_idname = "cuelight.modulator_remove"
    bl_label = "Remove audio link"
    bl_description = "Remove this audio link"
    bl_options = {'REGISTER', 'UNDO'}

    index: IntProperty()

    def execute(self, context):
        from ..effects.ops import active_effect
        e = active_effect(context)
        if e is None or not 0 <= self.index < len(e.modulators):
            return {'CANCELLED'}
        e.modulators.remove(self.index)
        live.refresh(context.scene)
        return {'FINISHED'}


classes = (
    CUELIGHT_OT_load_song,
    CUELIGHT_OT_analyze_audio,
    CUELIGHT_OT_detect_bpm,
    CUELIGHT_OT_pick_tempo,
    CUELIGHT_OT_bpm_adjust,
    CUELIGHT_OT_beat_shift,
    CUELIGHT_OT_fit_grid,
    CUELIGHT_OT_bpm_editor,
    CUELIGHT_OT_tap_tempo,
    CUELIGHT_OT_beat_here,
    CUELIGHT_OT_beat_nudge,
    CUELIGHT_OT_speed_preset,
    CUELIGHT_OT_modulator_add,
    CUELIGHT_OT_modulator_remove,
)
