"""Tap tempo and beat/bar markers on the timeline."""

import time

from ..engine import timing

MARK = "♪"  # ♪ starts every marker Cuelight owns
MAX_MARKERS = 4000
RESET_AFTER = 2.0  # seconds without a tap starts a new count

_taps = []


def tap(now=None):
    """Register a tap. Returns (bpm or None, taps in this run)."""
    now = time.perf_counter() if now is None else now
    if _taps and now - _taps[-1] > RESET_AFTER:
        _taps.clear()
    _taps.append(now)
    del _taps[:-9]  # the last 8 intervals
    if len(_taps) < 3:
        return None, len(_taps)
    gaps = sorted(b - a for a, b in zip(_taps, _taps[1:]))
    median = gaps[len(gaps) // 2] if len(gaps) % 2 else (gaps[len(gaps) // 2 - 1] + gaps[len(gaps) // 2]) / 2
    return round(60.0 / median, 1), len(_taps)


def reset_taps():
    _taps.clear()


def clear_markers(scene):
    for m in [m for m in scene.timeline_markers if m.name.startswith(MARK)]:
        scene.timeline_markers.remove(m)


def update_markers(scene):
    """Rebuild Cuelight's beat or bar markers over the scene range."""
    clear_markers(scene)
    s = scene.cuelight
    if s.markers == 'NONE':
        return 0
    fpb = timing.frames_per_beat(scene, s)
    bpb = s.beats_per_bar
    step = 1 if s.markers == 'BEATS' else bpb
    # First marked beat at or after the scene start, on the grid
    first = int(-(-(scene.frame_start - s.beat_offset) // fpb))
    first += (-first) % step
    count = 0
    b = first
    while count < MAX_MARKERS:
        frame = s.beat_offset + b * fpb
        if frame > scene.frame_end:
            break
        bar, beat = divmod(b, bpb)
        name = "%s%d" % (MARK, bar + 1) if beat == 0 else "%s%d.%d" % (MARK, bar + 1, beat + 1)
        scene.timeline_markers.new(name, frame=int(round(frame)))
        count += 1
        b += step
    return count
