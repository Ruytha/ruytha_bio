"""A click track on the beat grid, so you can hear whether the grid fits the song.

It lives as its own sound strip, packed into the .blend, on a channel above
the song. Off means muted, and renders mute it even when it's on.
"""

import os
import tempfile
import wave

import bpy
import numpy as np
from bpy.app.handlers import persistent

from ..engine import timing
from . import loader

MET = "cl_metronome"
RATE = 22050


def find(scene):
    coll = loader._strips(scene)
    if coll is None:
        return None
    return next((s for s in coll if s.type == 'SOUND' and s.get(MET)), None)


def remove(scene):
    st = find(scene)
    if st is None:
        return
    snd = st.sound
    loader._strips(scene).remove(st)
    if snd is not None and snd.users == 0:
        bpy.data.sounds.remove(snd)


def click_track(scene, start_frame, frames):
    """Mono float samples at RATE: a short blip on every beat, higher on each bar."""
    s = scene.cuelight
    fps = timing.fps(scene)
    fpb = timing.frames_per_beat(scene, s)
    n = int(frames / fps * RATE) + 1
    out = np.zeros(n, dtype=np.float32)
    t = np.arange(int(0.03 * RATE)) / RATE
    env = np.exp(-t / 0.006)
    tick = (np.sin(2 * np.pi * 1200 * t) * env * 0.5).astype(np.float32)
    tock = (np.sin(2 * np.pi * 2000 * t) * env * 0.7).astype(np.float32)
    k = int(np.ceil((start_frame - s.beat_offset) / fpb))
    while True:
        f = s.beat_offset + k * fpb
        i = int(round((f - start_frame) / fps * RATE))
        if i >= n:
            break
        if i >= 0:
            c = tock if k % s.beats_per_bar == 0 else tick
            m = min(len(c), n - i)
            out[i:i + m] += c[:m]
        k += 1
    return out


def build(scene):
    """(Re)build the click strip for the current BPM and beat 1."""
    song = loader.song_strip(scene)
    remove(scene)
    if song is None:
        return None
    s = scene.cuelight
    start, frames = song.frame_final_start, song.frame_final_duration
    pcm = (np.clip(click_track(scene, start, frames), -1, 1) * 32767).astype(np.int16)
    fd, path = tempfile.mkstemp(suffix=".wav")
    os.close(fd)
    try:
        with wave.open(path, "wb") as w:
            w.setnchannels(1)
            w.setsampwidth(2)
            w.setframerate(RATE)
            w.writeframes(pcm.tobytes())
        coll = loader._strips(scene)
        channel = song.channel + 1
        while any(st.channel == channel and st.frame_final_start < start + frames and st.frame_final_end > start
                  for st in coll):
            channel += 1
        st = coll.new_sound("Metronome", path, channel, start)
        st.sound.pack()
    finally:
        os.unlink(path)
    st[MET] = 1
    st.mute = not s.metronome
    st.volume = s.metronome_volume
    return st


def sync(scene):
    """Follow the metronome switch: build when on, drop when off (rebuilt next time)."""
    if scene.cuelight.metronome:
        return build(scene)
    remove(scene)
    return None


# Renders never include the click, even if it's on

_muted_for_render = []


@persistent
def _on_render_start(scene, *_):
    st = find(scene)
    if st is not None and not st.mute:
        st.mute = True
        _muted_for_render.append(scene.name)


@persistent
def _on_render_end(scene, *_):
    if scene.name in _muted_for_render:
        _muted_for_render.remove(scene.name)
        st = find(scene)
        if st is not None:
            st.mute = False


_HANDLERS = (
    (bpy.app.handlers.render_init, _on_render_start),
    (bpy.app.handlers.render_complete, _on_render_end),
    (bpy.app.handlers.render_cancel, _on_render_end),
)


def register():
    for lst, fn in _HANDLERS:
        if fn not in lst:
            lst.append(fn)


def unregister():
    for lst, fn in _HANDLERS:
        while fn in lst:
            lst.remove(fn)
