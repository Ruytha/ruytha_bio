"""Audio-reactive modulation of an effect layer.

A modulator reads one band, applies gain and threshold, and drives a target:
the layer's opacity, its speed, or any numeric effect parameter.

    x = clamp((band * gain - threshold) / (1 - threshold), 0, 1)
    Scale:  value = base * lerp(1, x, amount)   (amount 1: silence -> 0, peaks -> base)
    Add:    value = base + amount * x
"""

import numpy as np

from ..engine import timing
from . import analysis

FIXED_TARGETS = (
    ("opacity", "Intensity", "The layer's opacity: louder band, brighter effect"),
    ("speed", "Speed", "How fast the effect runs"),
)


def target_items(effect_type):
    items = list(FIXED_TARGETS)
    if effect_type is not None:
        for prm in effect_type.params:
            if prm.choices is None and not isinstance(prm.default, bool):
                items.append((prm.name, prm.label or prm.name.title(), prm.description or "Effect parameter"))
    return items


def _shape(mod, band):
    x = band * mod.gain
    th = min(mod.threshold, 0.999)
    return np.clip((x - th) / (1.0 - th), 0.0, 1.0)


def _apply(mod, base, x):
    if mod.mode == 'ADD':
        return base + mod.amount * x
    return base * (1.0 + mod.amount * (x - 1.0))


def _lookup(start, env, frame):
    i = int(round(frame)) - start
    if i < 0 or i >= len(env):
        return 0.0
    return float(env[i])


def apply(scene, effect, frame, w, t, p):
    """Return modulated (w, t). Parameters are modulated in place on p."""
    settings = scene.cuelight
    for mod in effect.modulators:
        if not mod.enabled:
            continue
        start, env = analysis.envelope(scene, mod.band, mod.attack, mod.release)
        if env is None:
            continue
        if mod.target == "opacity":
            w = _apply(mod, w, _shape(mod, _lookup(start, env, frame)))
        elif mod.target == "speed":
            # Integrate the modulated rate from the layer's start, so the effect
            # speeds up and slows down without jumping
            f0 = int(effect.frame_start)
            f1 = int(np.floor(frame))
            if f1 > f0:
                i0, i1 = f0 - start, f1 - start
                band = np.zeros(f1 - f0)
                lo, hi = max(i0, 0), min(i1, len(env))
                if hi > lo:
                    band[lo - i0:hi - i0] = env[lo:hi]
                factor = _apply(mod, 1.0, _shape(mod, band))
                step = timing.frame_step(scene, settings, effect)
                t0 = timing.cycles(scene, settings, effect, f0)
                t = t0 + step * (float(np.sum(factor)) + (frame - f1) * float(factor[-1]))
        elif mod.target in p._values:
            x = _shape(mod, _lookup(start, env, frame))
            p._values[mod.target] = _apply(mod, float(p._values[mod.target]), x)
    return max(0.0, w), t
