"""Split a song into quiet, building and full stretches, bar by bar.

Loudness per bar (RMS) on the beat grid, then:
  1. a bar is quiet when it's under 60% of the median bar
  2. other stretches are judged in 4-bar phrases: full when the phrase is near
     the typical loud level, building when it's under it
  3. runs shorter than `min_bars` merge into the stretch before them
"""

import numpy as np

from ..engine import timing
from . import loader

LOW, MID, HIGH = "LOW", "MID", "HIGH"
LABELS = {LOW: "Breakdown", MID: "Build", HIGH: "Full"}


def bar_levels(x, rate, first_seconds, bar_seconds, bars=None):
    """RMS per bar, normalised so the loudest bar is 1."""
    n = int((len(x) / rate - first_seconds) // bar_seconds)
    if bars is not None:
        n = min(n, bars)
    out = np.zeros(max(n, 0))
    for k in range(n):
        s0 = int((first_seconds + k * bar_seconds) * rate)
        s1 = int((first_seconds + (k + 1) * bar_seconds) * rate)
        seg = x[s0:s1]
        out[k] = float(np.sqrt(np.mean(seg * seg))) if len(seg) else 0.0
    top = out.max() if len(out) else 0.0
    return out / top if top > 0 else out


def _runs(labels):
    runs = []
    for i, lab in enumerate(labels):
        if runs and runs[-1][0] == lab:
            runs[-1][2] = i + 1
        else:
            runs.append([lab, i, i + 1])
    return runs


def _merge_short(runs, min_bars):
    changed = True
    while changed and len(runs) > 1:
        changed = False
        for j, r in enumerate(runs):
            if r[2] - r[1] < min_bars:
                target = runs[j - 1] if j > 0 else runs[j + 1]
                target[1], target[2] = min(target[1], r[1]), max(target[2], r[2])
                runs.pop(j)
                k = 0
                while k < len(runs) - 1:  # fuse neighbours that now match
                    if runs[k][0] == runs[k + 1][0]:
                        runs[k][2] = runs[k + 1][2]
                        runs.pop(k + 1)
                    else:
                        k += 1
                changed = True
                break
    return runs


def classify(levels, min_bars=2, phrase=4):
    """[(label, first bar index, end bar index exclusive)] for bar levels 0..1."""
    if len(levels) == 0:
        return []
    med = float(np.median(levels))
    quiet = levels < 0.6 * med
    runs = _merge_short(_runs(np.where(quiet, LOW, "LOUD")), min_bars)
    loud = levels[~quiet]
    ref = float(np.median(loud)) if len(loud) else med
    labels = []
    for lab, a, b in runs:
        if lab == LOW:
            labels += [LOW] * (b - a)
            continue
        for p in range(a, b, phrase):
            q = min(p + phrase, b)
            body = levels[p:q][~quiet[p:q]]  # a lone drop-out bar doesn't drag the phrase down
            mean = body.mean() if len(body) else levels[p:q].mean()
            labels += [HIGH if mean >= 0.97 * ref else MID] * (q - p)
    return [tuple(r) for r in _merge_short(_runs(labels), min_bars)]


def song_sections(scene, min_bars=2):
    """Sections of the loaded song on the current beat grid: [(label, start frame, end frame)]."""
    strip = loader.song_strip(scene)
    if strip is None:
        return []
    s = scene.cuelight
    fps = timing.fps(scene)
    x, rate = loader.samples(strip)
    visible0 = (strip.frame_final_start - strip.frame_start) / fps  # seconds into the file
    bar_frames = timing.frames_per_beat(scene, s) * s.beats_per_bar
    # First bar line at or after the strip's visible start
    k = int(np.ceil((strip.frame_final_start - s.beat_offset) / bar_frames))
    first_frame = s.beat_offset + k * bar_frames
    first_sec = visible0 + (first_frame - strip.frame_final_start) / fps
    bars = int((strip.frame_final_end - first_frame) // bar_frames)
    levels = bar_levels(x, rate, first_sec, bar_frames / fps, bars)
    out = []
    for lab, a, b in classify(levels, min_bars):
        out.append((lab, int(round(first_frame + a * bar_frames)), int(round(first_frame + b * bar_frames)) - 1))
    return out
