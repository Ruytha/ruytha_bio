"""Tempo: detection with a confidence score, candidate tempos, fitting the beat
grid to the song, and the song strip the BPM editor draws.

Confidence is the geometric mean of three checks, each 0..1:
  peak      how far the chosen tempo stands above the rest of the onset
            autocorrelation
  grid      how much of the song's onset energy lands near the fitted beats,
            above what a random grid would catch
  coverage  how many of the grid's beats have a clear hit
"""

import numpy as np

from ..engine import timing
from . import analysis, loader

KEY = "cl_tempo"
SURE = 0.5          # at or above this, detection is "Locked"
MIN_BPM, MAX_BPM = 60.0, 200.0
MULTIPLES = (1.0, 2.0, 0.5, 1.5, 2.0 / 3.0)


def onset_envelope(x, rate, hop=512, win=2048):
    """High-resolution spectral flux (rate / hop values per second)."""
    n = max(1, (len(x) - win) // hop)
    centres = np.arange(n) * hop + win // 2
    window = np.hanning(win).astype(np.float32)
    flux = np.zeros(n)
    prev = None
    for s in range(0, n, 1024):
        block = analysis._windows(x, centres[s:s + 1024], win) * window
        mag = np.log1p(np.abs(np.fft.rfft(block, axis=1)))
        before = np.vstack([mag[:1] if prev is None else prev[None, :], mag[:-1]])
        flux[s:s + len(mag)] = np.maximum(mag - before, 0).sum(axis=1)
        prev = mag[-1]
    flux -= np.convolve(flux, np.ones(16) / 16, mode="same")  # drop slow loudness swells
    return np.maximum(flux, 0), rate / hop


def _phase(env, period):
    """Offset (in samples of env) where a grid of this period catches the most onset."""
    best, best_ph = -1.0, 0.0
    steps = max(4, int(np.ceil(period * 4)))
    for ph in np.linspace(0, period, steps, endpoint=False):
        pos = np.arange(ph, len(env) - 1, period)
        i = np.floor(pos).astype(int)
        f = pos - i
        s = float(np.sum(env[i] * (1 - f) + env[np.minimum(i + 1, len(env) - 1)] * f))
        if s > best:
            best, best_ph = s, ph
    return best_ph


def _grid_share(env, period, phase):
    """Share of onset energy within 8% of a beat, rescaled so a random grid scores 0."""
    total = env.sum()
    if total <= 0:
        return 0.0
    tol = max(1.0, 0.08 * period)
    d = np.abs(((np.arange(len(env)) - phase + period / 2) % period) - period / 2)
    share = env[d <= tol].sum() / total
    chance = min(0.99, (2 * tol + 1) / period)
    return float(np.clip((share - chance) / (1 - chance) * 1.25, 0.0, 1.0))


def _coverage(env, period, phase):
    """Share of grid beats that have a clear hit: the strongest onset near the
    beat is well above the average onset away from beats. A steady pulse covers
    nearly every beat; a pad or noise covers few, even if one spike lines up."""
    tol = max(1.0, 0.08 * period)
    d = np.abs(((np.arange(len(env)) - phase + period / 2) % period) - period / 2)
    off = env[d > 2 * tol]
    floor = off.mean() if len(off) else 0.0
    beats = np.arange(phase, len(env), period)
    if len(beats) < 2:
        return 0.0
    hits = 0
    for b in beats:
        lo, hi = int(max(0, np.floor(b - tol))), int(min(len(env), np.ceil(b + tol) + 1))
        if hi > lo and env[lo:hi].max() > 4.0 * floor + 1e-12:
            hits += 1
    return hits / len(beats)


def detect_tempo(x, rate, lo=MIN_BPM, hi=MAX_BPM):
    """{bpm, first (seconds), confidence, candidates [(bpm, score)]} for a mono signal."""
    env, env_rate = onset_envelope(x, rate)
    if env.sum() <= 1e-9 or len(env) < 8:
        return {"bpm": 120.0, "first": 0.0, "confidence": 0.0, "candidates": [(120.0, 0.0)]}

    spec = np.fft.rfft(env, 2 * len(env))
    ac = np.fft.irfft(spec * np.conj(spec))[:len(env)]
    acn = ac / max(ac[0], 1e-12)
    lags = np.arange(len(acn), dtype=float)
    with np.errstate(divide="ignore"):
        bpm_at = 60.0 * env_rate / lags
    ok = (bpm_at >= lo) & (bpm_at <= hi)
    if not np.any(ok):
        return {"bpm": 120.0, "first": 0.0, "confidence": 0.0, "candidates": [(120.0, 0.0)]}

    # Prefer tempos near 120 when half/double time are nearly as strong
    prior = np.exp(-0.5 * (np.log2(np.where(ok, bpm_at, 1.0) / 120.0) / 0.9) ** 2)
    lag = int(np.argmax(np.where(ok, acn * prior, -np.inf)))
    refined = float(lag)
    if 1 <= lag < len(acn) - 1:
        a, b, c = acn[lag - 1], acn[lag], acn[lag + 1]
        denom = a - 2 * b + c
        if denom != 0:
            refined = lag + 0.5 * (a - c) / denom
    bpm = 60.0 * env_rate / refined

    phase = _phase(env, refined)
    peak = float(np.clip((acn[lag] - np.median(acn[ok])) / 0.3, 0.0, 1.0))
    grid = _grid_share(env, refined, phase)
    cover = _coverage(env, refined, phase)
    # Geometric mean: any check near zero sinks it (a pad has a "peak" but no grid)
    confidence = round(float((peak * grid * cover) ** (1.0 / 3.0)), 3)

    def strength(b):
        lg = 60.0 * env_rate / b
        i = int(np.clip(round(lg), 1, len(acn) - 1))
        return float(acn[max(1, i - 1):i + 2].max())

    best = max(strength(bpm), 1e-9)
    cands = []
    for m in MULTIPLES:
        b = bpm * m
        if lo <= b <= hi and all(abs(b - c) / c > 0.03 for c, _ in cands):
            cands.append((round(b, 2), round(confidence * min(1.0, strength(b) / best), 3)))
    cands.sort(key=lambda c: -c[1])
    return {"bpm": round(bpm, 2), "first": phase / env_rate, "confidence": confidence,
            "candidates": cands[:3]}


def _grid_strength(env, period, phase):
    """Average onset strength exactly on the grid's beats (interpolated). A grid
    that drifts even slightly over a long stretch loses its hits and scores lower."""
    pos = np.arange(phase, len(env) - 1, period)
    if len(pos) == 0:
        return 0.0
    i = np.floor(pos).astype(int)
    f = pos - i
    return float(np.mean(env[i] * (1 - f) + env[i + 1] * f))


def refine_tempo(x, rate, bpm, span=0.6, step=0.02):
    """Fine-tune a BPM estimate to within `step`. Returns (bpm, seconds to the first beat)."""
    env, env_rate = onset_envelope(x, rate)
    best = (-1.0, bpm, 0.0)
    for b in np.arange(bpm - span, bpm + span + step / 2, step):
        period = 60.0 * env_rate / b
        ph = _phase(env, period)
        g = _grid_strength(env, period, ph)
        if g > best[0]:
            best = (g, float(b), ph / env_rate)
    return round(best[1], 2), best[2]


def detect(scene, section=False):
    """Detect the song's tempo (optionally only inside the preview range).

    Stores confidence and candidates on the scene and returns the result,
    with "first" converted to the frame of the first beat.
    """
    strip = loader.song_strip(scene)
    if strip is None:
        raise RuntimeError("No song loaded")
    x, rate = loader.samples(strip)
    fps = timing.fps(scene)
    start_frame = strip.frame_final_start
    if section and scene.use_preview_range:
        start_frame = max(scene.frame_preview_start, strip.frame_final_start)
        end_frame = min(scene.frame_preview_end, strip.frame_final_end)
    else:
        end_frame = strip.frame_final_end
    s0 = int(round((start_frame - strip.frame_start) / fps * rate))
    s1 = int(round((end_frame - strip.frame_start) / fps * rate))
    r = detect_tempo(x[max(s0, 0):max(s1, s0 + 1)], rate)
    r["first"] = start_frame + r["first"] * fps
    scene[KEY] = {"bpm": r["bpm"], "confidence": r["confidence"],
                  "candidates": [list(c) for c in r["candidates"]], "section": bool(section)}
    return r


def info(scene):
    """(confidence or None, [(bpm, score)]) from the last detection."""
    d = scene.get(KEY)
    if d is None:
        return None, []
    return float(d["confidence"]), [(float(b), float(s)) for b, s in d["candidates"]]


def is_sure(scene):
    conf, _ = info(scene)
    return conf is not None and conf >= SURE


def fit_offset(scene, bpm=None):
    """Frame for beat 1 that lines the grid up with the song's hits.

    Keeps beat 1 within one beat of where it was, so it doesn't jump bars.
    Returns None without an analysed song.
    """
    start, onset = analysis.envelope(scene, 'ONSET')
    if onset is None:
        return None
    s = scene.cuelight
    bpm = bpm or s.bpm
    fpb = timing.fps(scene) * 60.0 / bpm
    ph = _phase(onset, fpb)  # frames after the song start
    first = start + ph
    # Put it on the beat nearest the current offset, so bar numbers stay put
    k = round((s.beat_offset - first) / fpb)
    return round(first + k * fpb, 2)


# ---------------------------------------------------------------- song strip

BG = (0.078, 0.078, 0.078)      # #141414
WAVE = (0.64, 0.64, 0.64)       # #a3a3a3
BEAT = (0.29, 0.29, 0.29)       # #4a4a4a
BAR = (0.98, 0.98, 0.98)        # #fafafa
HEAD = (1.0, 1.0, 1.0)


def strip_window(scene, bars=8):
    """(first frame, frames per bar, first bar index) for the strip around the playhead."""
    s = scene.cuelight
    fpb = timing.frames_per_beat(scene, s)
    bar_len = fpb * s.beats_per_bar
    cur_bar = int(np.floor((scene.frame_current - s.beat_offset) / bar_len))
    first_bar = max(0, cur_bar - bars // 2 + 1)  # never before bar 1
    return s.beat_offset + first_bar * bar_len, bar_len, first_bar


def render_tile(onset, onset_start, f0, f1, beats_per_bar, playhead=None, size=64):
    """One bar as a size x size RGBA image (rows bottom-up, as Blender stores pixels)."""
    img = np.empty((size, size, 4), dtype=np.float32)
    img[..., :3] = BG
    img[..., 3] = 1.0
    xs = f0 + (np.arange(size) + 0.5) / size * (f1 - f0)
    idx = xs - onset_start
    v = np.interp(idx, np.arange(len(onset)), onset, left=0.0, right=0.0) if onset is not None else np.zeros(size)
    v = np.maximum(v, np.maximum(np.roll(v, 1), np.roll(v, -1)))  # 3 px wide, so hits read as hits
    h = np.clip(np.round(v * (size - 6)), 0, size - 6).astype(int)
    for b in range(1, beats_per_bar):
        img[:, int(round(b / beats_per_bar * size)), :3] = BEAT
    img[:, 0:2, :3] = BAR
    # Hits draw over the grid, so a hit right on a beat line stays visible
    rows = np.arange(size)[:, None]
    mask = (rows >= 3) & (rows < 3 + h[None, :])
    img[mask, :3] = WAVE
    if playhead is not None and f0 <= playhead < f1:
        x = int((playhead - f0) / (f1 - f0) * size)
        img[:, x, :3] = HEAD
    return img


def render_strip(scene, bars=8, size=64):
    """List of bars RGBA tiles for the window around the playhead."""
    s = scene.cuelight
    start, onset = analysis.envelope(scene, 'ONSET')
    f0, bar_len, first_bar = strip_window(scene, bars)
    tiles = []
    for i in range(bars):
        a = f0 + i * bar_len
        tiles.append(render_tile(onset, start or 0, a, a + bar_len, s.beats_per_bar,
                                 scene.frame_current, size))
    return tiles, first_bar
